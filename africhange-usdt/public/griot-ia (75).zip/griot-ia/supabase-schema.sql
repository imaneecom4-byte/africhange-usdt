-- ============================================================
-- GRIOT IA — SCHÉMA SUPABASE COMPLET
-- À exécuter dans Supabase > SQL Editor AVANT de déployer le site.
-- OWNER_EMAIL déjà réglé sur imanedoc33@gmail.com — vérifie que c'est le bon avant d'exécuter.
-- ============================================================

-- EXTENSIONS
create extension if not exists "pgcrypto";

-- ============================================================
-- TABLE: profiles
-- ============================================================
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  avatar_url text,
  role text not null default 'student' check (role in ('student','admin','owner','moderator')),
  plan text not null default 'free' check (plan in ('free','formation','accompagnement')),
  plan_expires_at timestamptz,
  points integer not null default 0,
  ai_quota_used integer not null default 0,
  ai_quota_reset_at timestamptz default now(),
  referral_code text unique,
  referred_by uuid references profiles(id),
  referral_count integer not null default 0,
  onboarding_step integer not null default 0,
  is_banned boolean default false,
  banned_at timestamptz,
  ban_reason text,
  community_status text default 'not_requested' check (community_status in ('not_requested','pending','approved','rejected')),
  created_at timestamptz default now()
);

-- ============================================================
-- TABLE: resources (ressources téléchargeables)
-- ============================================================
create table if not exists resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  category text not null default 'general',
  file_url text not null,
  type text not null default 'file' check (type in ('file','link')),
  thumbnail_url text,
  is_free boolean not null default false,
  plan_required text not null default 'free' check (plan_required in ('free','formation','accompagnement')),
  guide_content text,
  order_index integer not null default 0,
  download_count integer not null default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ============================================================
-- TABLE: modules & lessons (classroom)
-- ============================================================
create table if not exists modules (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  cover_url text,
  order_index integer not null default 0,
  created_at timestamptz default now()
);

create table if not exists classroom_submodules (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references modules(id) on delete cascade,
  title text not null,
  order_index integer not null default 0,
  created_at timestamptz default now()
);

create table if not exists lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references modules(id) on delete cascade,
  submodule_id uuid references classroom_submodules(id) on delete cascade,
  title text not null,
  description text,
  video_type text check (video_type in ('youtube','vimeo','loom','drive','file')),
  video_url text,
  pdf_url text,
  content text,
  visibility text not null default 'free' check (visibility in ('free','paid','premium')),
  order_index integer not null default 0,
  duration_minutes integer default 0,
  created_at timestamptz default now()
);

create table if not exists lesson_resources (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid references lessons(id) on delete cascade,
  title text not null,
  type text not null check (type in ('link','pdf')),
  url text not null,
  order_index integer not null default 0,
  created_at timestamptz default now()
);

create table if not exists lesson_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  lesson_id uuid references lessons(id) on delete cascade,
  completed boolean default false,
  completed_at timestamptz,
  unique(user_id, lesson_id)
);

-- ============================================================
-- TABLE: community
-- ============================================================
create table if not exists community_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  emoji text default '💬',
  admin_only boolean default false,
  order_index integer not null default 0
);

create table if not exists community_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  category_id uuid references community_categories(id),
  title text,
  content text not null,
  image_url text,
  video_url text,
  post_type text default 'text' check (post_type in ('text','image','video','poll')),
  is_pinned boolean default false,
  likes_count integer not null default 0,
  comments_count integer not null default 0,
  created_at timestamptz default now()
);

create table if not exists community_poll_options (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references community_posts(id) on delete cascade,
  label text not null,
  order_index integer not null default 0
);

create table if not exists community_poll_votes (
  post_id uuid references community_posts(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  option_id uuid references community_poll_options(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (post_id, user_id)
);

create table if not exists community_likes (
  post_id uuid references community_posts(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (post_id, user_id)
);

create table if not exists community_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references community_posts(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  parent_comment_id uuid references community_comments(id) on delete cascade,
  content text not null,
  likes_count integer not null default 0,
  created_at timestamptz default now()
);

create table if not exists community_comment_likes (
  comment_id uuid references community_comments(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  primary key (comment_id, user_id)
);

create table if not exists community_reports (
  id uuid primary key default gen_random_uuid(),
  content_type text not null check (content_type in ('post','comment')),
  content_id uuid not null,
  reporter_id uuid references profiles(id) on delete cascade,
  reason text,
  status text not null default 'pending' check (status in ('pending','resolved')),
  created_at timestamptz default now()
);

create table if not exists community_membership_questions (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  order_index integer not null default 0,
  required boolean not null default true
);

create table if not exists community_membership_answers (
  user_id uuid references profiles(id) on delete cascade,
  question_id uuid references community_membership_questions(id) on delete cascade,
  answer text,
  created_at timestamptz default now(),
  primary key (user_id, question_id)
);

create table if not exists community_welcome_steps (
  step_number integer primary key check (step_number in (1,2,3)),
  label text not null,
  link text
);

create table if not exists community_welcome_progress (
  user_id uuid references profiles(id) on delete cascade,
  step_number integer not null,
  completed_at timestamptz default now(),
  primary key (user_id, step_number)
);

create table if not exists community_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  type text not null,
  message text not null,
  link text,
  is_read boolean not null default false,
  created_at timestamptz default now()
);

-- ============================================================
-- TABLE: calendar (lives / événements)
-- ============================================================
create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  starts_at timestamptz not null,
  duration_minutes integer default 60,
  meeting_url text,
  replay_url text,
  status text not null default 'scheduled' check (status in ('scheduled','live','ended')),
  created_at timestamptz default now()
);

create table if not exists live_reminders_sent (
  event_id uuid references events(id) on delete cascade,
  reminder_type text not null check (reminder_type in ('24h','1h')),
  sent_at timestamptz default now(),
  primary key (event_id, reminder_type)
);

create table if not exists event_rsvps (
  event_id uuid references events(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  attended boolean default false,
  primary key (event_id, user_id)
);

-- ============================================================
-- TABLE: checklist (accueil / onboarding)
-- ============================================================
create table if not exists checklist_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  points_reward integer default 10,
  order_index integer not null default 0,
  action_key text
);

create table if not exists checklist_progress (
  user_id uuid references profiles(id) on delete cascade,
  item_id uuid references checklist_items(id) on delete cascade,
  completed_at timestamptz default now(),
  primary key (user_id, item_id)
);

-- ============================================================
-- TABLE: messaging
-- ============================================================
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  user_a uuid references profiles(id) on delete cascade,
  user_b uuid references profiles(id) on delete cascade,
  last_message_at timestamptz default now(),
  unique(user_a, user_b)
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade,
  sender_id uuid references profiles(id) on delete cascade,
  content text,
  attachment_url text,
  attachment_type text,
  is_sale_proof boolean default false,
  sale_proof_status text default 'pending' check (sale_proof_status in ('pending','approved','rejected')),
  read_at timestamptz,
  created_at timestamptz default now()
);

-- ============================================================
-- TABLE: referrals & anti-fraude
-- ============================================================
create table if not exists referrals (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid references profiles(id) on delete cascade,
  referred_id uuid references profiles(id) on delete cascade,
  ip_address text,
  status text not null default 'pending' check (status in ('pending','verified','rejected')),
  created_at timestamptz default now(),
  unique(referred_id)
);

-- ============================================================
-- TABLE: subscriptions & payments
-- ============================================================
create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  plan text not null,
  billing text check (billing in ('unique','monthly','annual','referral')),
  amount integer,
  status text default 'active',
  starts_at timestamptz default now(),
  expires_at timestamptz,
  geniuspay_payment_id text,
  created_at timestamptz default now()
);

create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  amount integer not null,
  plan text not null,
  billing text,
  status text default 'pending' check (status in ('pending','success','failed')),
  geniuspay_checkout_url text,
  geniuspay_payment_id text unique,
  raw_webhook jsonb,
  created_at timestamptz default now()
);

-- ============================================================
-- TABLE: tracking
-- ============================================================
create table if not exists channel_clicks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  channel text check (channel in ('whatsapp','telegram')),
  utm_source text,
  created_at timestamptz default now()
);

-- ============================================================
-- TABLE: settings (clé/valeur, éditable par admin)
-- ============================================================
create table if not exists settings (
  key text primary key,
  value jsonb
);

insert into settings (key, value) values
  ('whatsapp_url', '"https://chat.whatsapp.com/COLLE_TON_LIEN"'),
  ('telegram_url', '"https://t.me/COLLE_TON_LIEN"'),
  ('contact_email', '"contact@griotia.com"'),
  ('community_rules', '"1. Respect. 2. Bienveillance. 3. Pas de spam."'),
  ('community_mp_enabled', 'true'),
  ('community_admin_dm_email_notify', 'false'),
  ('contact_whatsapp_number', '"22871777357"'),
  ('contact_whatsapp_message', '"Bonjour Griot IA, j''ai une question"'),
  ('contact_whatsapp_icon', '""'),
  ('contact_whatsapp_enabled', 'true'),
  ('chariow_formation_link', '""'),
  ('chariow_accompagnement_link', '""'),
  ('homepage_welcome_enabled', 'true'),
  ('homepage_welcome_text', '"Voici ta progression pour bien démarrer sur Griot IA."'),
  ('homepage_announcement_enabled', 'false'),
  ('homepage_announcement_text', '""'),
  ('homepage_motivation_enabled', 'false'),
  ('homepage_motivation_text', '""'),
  ('homepage_button_enabled', 'false'),
  ('homepage_button_label', '"Rejoindre le live"'),
  ('homepage_button_url', '""')
on conflict (key) do nothing;

-- ============================================================
-- TRIGGER: création auto du profil à l'inscription
-- ============================================================
create or replace function handle_new_user()
returns trigger as $$
declare
  owner_email text := 'imanedoc33@gmail.com';
  new_role text := 'student';
  new_code text;
begin
  if new.email = owner_email then
    new_role := 'owner';
  end if;

  new_code := upper(substr(md5(random()::text || new.id::text), 1, 8));

  insert into public.profiles (id, email, full_name, role, referral_code)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''), new_role, new_code);

  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ============================================================
-- RLS
-- ============================================================
alter table profiles enable row level security;
alter table resources enable row level security;
alter table modules enable row level security;
alter table lessons enable row level security;
alter table lesson_progress enable row level security;
alter table community_categories enable row level security;
alter table community_posts enable row level security;
alter table community_likes enable row level security;
alter table community_comments enable row level security;
alter table events enable row level security;
alter table event_rsvps enable row level security;
alter table checklist_items enable row level security;
alter table checklist_progress enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table referrals enable row level security;
alter table subscriptions enable row level security;
alter table payments enable row level security;
alter table channel_clicks enable row level security;
alter table settings enable row level security;

-- Helper: est admin/owner
create or replace function is_admin(uid uuid) returns boolean as $$
  select exists(select 1 from profiles where id = uid and role in ('admin','owner'));
$$ language sql security definer stable;

-- profiles
create policy "profiles: self read" on profiles for select using (auth.uid() = id or is_admin(auth.uid()));
create policy "profiles: self update" on profiles for update using (auth.uid() = id or is_admin(auth.uid()));
create policy "profiles: admin insert" on profiles for insert with check (true);

-- resources (lecture publique authentifiée, écriture admin)
create policy "resources: read auth" on resources for select using (auth.role() = 'authenticated');
create policy "resources: admin write" on resources for all using (is_admin(auth.uid()));

-- modules/lessons
create policy "modules: read auth" on modules for select using (auth.role() = 'authenticated');
create policy "modules: admin write" on modules for all using (is_admin(auth.uid()));
create policy "lessons: read auth" on lessons for select using (auth.role() = 'authenticated');
create policy "lessons: admin write" on lessons for all using (is_admin(auth.uid()));

-- lesson_progress
create policy "progress: self" on lesson_progress for all using (auth.uid() = user_id or is_admin(auth.uid()));

-- community
create policy "cat: read" on community_categories for select using (auth.role() = 'authenticated');
create policy "cat: admin write" on community_categories for all using (is_admin(auth.uid()));
create policy "posts: read" on community_posts for select using (auth.role() = 'authenticated');
create policy "posts: write own" on community_posts for insert with check (auth.uid() = user_id);
create policy "posts: update own or admin" on community_posts for update using (auth.uid() = user_id or is_admin(auth.uid()));
create policy "posts: delete own or admin" on community_posts for delete using (auth.uid() = user_id or is_admin(auth.uid()));
create policy "likes: all" on community_likes for all using (auth.role() = 'authenticated');
create policy "comments: read" on community_comments for select using (auth.role() = 'authenticated');
create policy "comments: write own" on community_comments for insert with check (auth.uid() = user_id);

-- events
create policy "events: read" on events for select using (auth.role() = 'authenticated');
create policy "events: admin write" on events for all using (is_admin(auth.uid()));
alter table live_reminders_sent enable row level security;
create policy "live reminders: admin read" on live_reminders_sent for select using (is_admin(auth.uid()));
create policy "rsvps: self" on event_rsvps for all using (auth.uid() = user_id or is_admin(auth.uid()));

-- checklist
create policy "checklist items: read" on checklist_items for select using (auth.role() = 'authenticated');
create policy "checklist items: admin write" on checklist_items for all using (is_admin(auth.uid()));
create policy "checklist progress: self" on checklist_progress for all using (auth.uid() = user_id or is_admin(auth.uid()));

-- messaging
create policy "conv: participant" on conversations for all using (auth.uid() = user_a or auth.uid() = user_b or is_admin(auth.uid()));
create policy "msg: participant" on messages for select using (
  exists(select 1 from conversations c where c.id = conversation_id and (c.user_a = auth.uid() or c.user_b = auth.uid())) or is_admin(auth.uid())
);
create policy "msg: send" on messages for insert with check (auth.uid() = sender_id);
create policy "msg: admin update" on messages for update using (is_admin(auth.uid()));

-- referrals
create policy "referrals: self read" on referrals for select using (auth.uid() = referrer_id or auth.uid() = referred_id or is_admin(auth.uid()));
create policy "referrals: insert" on referrals for insert with check (true);
create policy "referrals: admin update" on referrals for update using (is_admin(auth.uid()));

-- subscriptions / payments (lecture self, écriture via service role uniquement côté function)
create policy "subs: self read" on subscriptions for select using (auth.uid() = user_id or is_admin(auth.uid()));
create policy "payments: self read" on payments for select using (auth.uid() = user_id or is_admin(auth.uid()));

-- channel_clicks
create policy "clicks: insert" on channel_clicks for insert with check (true);
create policy "clicks: admin read" on channel_clicks for select using (is_admin(auth.uid()));

-- settings
create policy "settings: read" on settings for select using (true);
create policy "settings: admin write" on settings for all using (is_admin(auth.uid()));

-- sous-modules & ressources de leçon
alter table classroom_submodules enable row level security;
alter table lesson_resources enable row level security;
create policy "submodules: read auth" on classroom_submodules for select using (auth.role() = 'authenticated');
create policy "submodules: admin write" on classroom_submodules for all using (is_admin(auth.uid()));
create policy "lesson resources: read auth" on lesson_resources for select using (auth.role() = 'authenticated');
create policy "lesson resources: admin write" on lesson_resources for all using (is_admin(auth.uid()));

-- ventes Chariow en attente + suivi des rappels d'abonnement
create table if not exists pending_sales (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  product text not null check (product in ('formation', 'accompagnement')),
  amount integer,
  chariow_sale_id text,
  raw_payload jsonb,
  status text not null default 'pending' check (status in ('pending', 'matched')),
  matched_user_id uuid references profiles(id),
  created_at timestamptz default now()
);

create table if not exists subscription_reminders_sent (
  user_id uuid references profiles(id) on delete cascade,
  reminder_type text not null check (reminder_type in ('j-3', 'j-1', 'j0', 'j+3')),
  expires_at_snapshot timestamptz not null,
  sent_at timestamptz default now(),
  primary key (user_id, reminder_type, expires_at_snapshot)
);

alter table pending_sales enable row level security;
alter table subscription_reminders_sent enable row level security;
create policy "pending sales: admin only" on pending_sales for all using (is_admin(auth.uid()));
create policy "reminders sent: admin read" on subscription_reminders_sent for select using (is_admin(auth.uid()));

-- ============================================================
-- COMMUNAUTÉ SKOOL — tables additionnelles, RLS et seed
-- ============================================================
insert into community_welcome_steps (step_number, label, link) values
  (1, 'Présente-toi à la communauté', '/app/community.html'),
  (2, 'Rejoins notre groupe WhatsApp', '/go/whatsapp.html'),
  (3, 'Regarde ta première leçon', '/app/classroom.html')
on conflict (step_number) do nothing;

alter table community_poll_options enable row level security;
alter table community_poll_votes enable row level security;
alter table community_comment_likes enable row level security;
alter table community_reports enable row level security;
alter table community_membership_questions enable row level security;
alter table community_membership_answers enable row level security;
alter table community_welcome_steps enable row level security;
alter table community_welcome_progress enable row level security;
alter table community_notifications enable row level security;

create or replace function is_staff(uid uuid) returns boolean as $$
  select exists(select 1 from profiles where id = uid and role in ('admin','owner','moderator'));
$$ language sql security definer stable;

create policy "poll options: read" on community_poll_options for select using (auth.role() = 'authenticated');
create policy "poll options: admin write" on community_poll_options for all using (is_admin(auth.uid()));
create policy "poll votes: read own or staff" on community_poll_votes for select using (auth.uid() = user_id or is_staff(auth.uid()));
create policy "poll votes: insert own" on community_poll_votes for insert with check (auth.uid() = user_id);

create policy "comment likes: all" on community_comment_likes for all using (auth.role() = 'authenticated');

create policy "reports: insert own" on community_reports for insert with check (auth.uid() = reporter_id);
create policy "reports: staff read" on community_reports for select using (is_staff(auth.uid()));
create policy "reports: staff update" on community_reports for update using (is_staff(auth.uid()));

create policy "membership questions: read" on community_membership_questions for select using (auth.role() = 'authenticated');
create policy "membership questions: admin write" on community_membership_questions for all using (is_admin(auth.uid()));
create policy "membership answers: self" on community_membership_answers for all using (auth.uid() = user_id or is_staff(auth.uid()));

create policy "welcome steps: read" on community_welcome_steps for select using (auth.role() = 'authenticated');
create policy "welcome steps: admin write" on community_welcome_steps for all using (is_admin(auth.uid()));
create policy "welcome progress: self" on community_welcome_progress for all using (auth.uid() = user_id or is_staff(auth.uid()));

create policy "notifications: self" on community_notifications for all using (auth.uid() = user_id);
create policy "notifications: insert any authenticated" on community_notifications for insert with check (auth.role() = 'authenticated');

drop policy if exists "posts: delete own or admin" on community_posts;
create policy "posts: delete own or staff" on community_posts for delete using (auth.uid() = user_id or is_staff(auth.uid()));
drop policy if exists "posts: update own or admin" on community_posts;
create policy "posts: update own or staff" on community_posts for update using (auth.uid() = user_id or is_staff(auth.uid()));
create policy "comments: delete own or staff" on community_comments for delete using (auth.uid() = user_id or is_staff(auth.uid()));

drop policy if exists "profiles: self update" on profiles;
create policy "profiles: self update" on profiles for update using (auth.uid() = id or is_admin(auth.uid()) or is_staff(auth.uid()));

-- ============================================================
-- STORAGE BUCKETS (à créer manuellement dans Supabase > Storage)
-- - resources (public)
-- - lessons (public)
-- - avatars (public)
-- - messages (privé, signé)
-- - sale-proofs (privé, signé)
-- ============================================================
