# Griot IA 💬
**Le savoir digital, transmis comme un griot.**

SaaS communautaire qui forme les débutants africains à vendre des produits digitaux avec l'IA. Site 100% HTML + CSS + JavaScript vanilla + Supabase, sans framework, mobile-first.

## 🚀 Déploiement — étape par étape

### 1. Créer le projet Supabase
1. Va sur [supabase.com](https://supabase.com) → New Project.
2. Une fois créé, ouvre **SQL Editor** → colle le contenu de `supabase-schema.sql` → **avant d'exécuter**, remplace `TON_EMAIL@gmail.com` dans la fonction `handle_new_user()` par ton vrai email (celui qui doit avoir le rôle `owner`).
3. Exécute le script.
4. Va dans **Storage** → crée 5 buckets : `resources` (public), `lessons` (public), `avatars` (public), `messages` (privé), `sale-proofs` (privé).
5. Va dans **Project Settings > API** → note ton `Project URL` et ta clé `anon public`, et la clé `service_role` (secrète).

### 2. Remplir les clés
Deux fichiers à compléter avec tes vraies clés :

**`js/supabase-client.js`** (clés publiques, visibles côté client) :
```js
SUPABASE_URL: "https://xxxx.supabase.co",
SUPABASE_ANON_KEY: "eyJ...",
OWNER_EMAIL: "ton-email@gmail.com",
GEMINI_API_KEY: "...",
GROQ_API_KEY: "...",
```

**`.env`** (utilisé par Netlify pour les Functions, jamais exposé au client) :
```
SUPABASE_URL=...
SUPABASE_SERVICE_ROLE_KEY=...
GENIUSPAY_API_KEY=...
GENIUSPAY_API_SECRET=...
GENIUSPAY_WEBHOOK_SECRET=...
RESEND_API_KEY=...
OWNER_EMAIL=...
```

> ⚠️ `js/supabase-client.js` contient volontairement des clés publiques (anon key) : c'est normal et sans danger, la sécurité réelle est assurée par les policies RLS de Supabase. Les clés **secrètes** (service role, GeniusPay secret) ne doivent JAMAIS être mises dans un fichier `js/*` — elles restent uniquement dans les variables d'environnement Netlify.

### 3. Déployer sur Netlify
1. Va sur [netlify.com](https://netlify.com) → **Add new site > Deploy manually**.
2. Glisse-dépose le dossier complet du projet (drag & drop).
3. Une fois déployé, va dans **Site settings > Environment variables** et ajoute toutes les variables du fichier `.env`.
4. Redéploie le site (Deploys > Trigger deploy) pour que les Functions prennent en compte les nouvelles variables.

### 4. Configurer le webhook GeniusPay
Dans ton dashboard GeniusPay, configure l'URL de webhook :
```
https://griotia.online/.netlify/functions/geniuspay
```

### 5. Créer ton compte owner
Va sur `https://griotia.online/signup.html` et inscris-toi avec l'email défini comme `OWNER_EMAIL`. Ton compte aura automatiquement le rôle `owner` grâce au trigger SQL, et tu accèderas à `/admin/index.html`.

### 6. Remplir le contenu
Depuis l'admin (`/admin/`), ajoute tes ressources, modules/leçons, catégories communauté, événements calendrier, étapes checklist, et configure `whatsapp_url` / `telegram_url` / `contact_email` dans **Réglages**.

## 📁 Structure du projet
- `index.html`, `login.html`, `signup.html`, `invite.html` — pages publiques
- `go/` — pages de tracking des clics WhatsApp/Telegram
- `app/` — espace élève (protégé, nécessite une session)
- `admin/` — back-office (protégé, rôle admin/owner requis)
- `js/` — logique partagée (auth, paiement, IA, gamification, etc.)
- `api/webhooks/` — Netlify Functions (paiement GeniusPay, clés secrètes protégées)
- `supabase-schema.sql` — schéma complet à exécuter dans Supabase

## 💰 Plans
| Plan | Prix | Accès |
|---|---|---|
| Gratuit | 0 FCFA | Ressources gratuites, leçons gratuites, Coach IA (3/mois) |
| Formation | 9.900 FCFA (unique) | Toutes ressources/leçons, Coach IA (20/mois) — débloquable via 5 parrainages |
| Accompagnement | 15.000 FCFA/mois ou 150.000 FCFA/an | Tout + communauté, calendrier, membres, messagerie, Coach IA (100/mois) |

## 🔒 Sécurité
- Les clés secrètes (service role Supabase, secret GeniusPay) restent uniquement dans les variables d'environnement Netlify, jamais dans le code client.
- La création de paiement passe par une Netlify Function (`geniuspay-create.js`).
- Le webhook (`geniuspay.js`) vérifie une signature HMAC-SHA256 avant de valider un paiement.
- Row Level Security activée sur toutes les tables Supabase.

## ⚠️ Ce que tu dois encore faire manuellement
- Remplacer `icon-192.png` / `icon-512.png` par ton vrai logo (des placeholders unis sont fournis).
- Configurer les emails transactionnels Resend (bienvenue, relances, rappel live, expiration, parrainage) si tu veux les activer — les tables et hooks nécessaires existent déjà (`profiles.created_at`, `events`, `subscriptions.expires_at`), mais l'envoi automatique programmé (cron) n'est pas inclus ici et nécessiterait une Netlify Scheduled Function dédiée.
- Ajouter tes propres CGU/politique de confidentialité si nécessaire.
