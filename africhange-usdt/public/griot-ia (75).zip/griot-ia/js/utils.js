/* ============================================================
   GRIOT IA — Utilitaires
   ============================================================ */

/** Affiche une notification toast en bas de l'écran */
function showToast(message, type = "info", duration = 3500) {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transition = "opacity .3s";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/** Retourne un texte relatif du type "il y a 3h" */
function timeAgo(dateString) {
  const date = new Date(dateString);
  const seconds = Math.floor((new Date() - date) / 1000);
  const intervals = [
    { label: "an", secs: 31536000 },
    { label: "mois", secs: 2592000 },
    { label: "j", secs: 86400 },
    { label: "h", secs: 3600 },
    { label: "min", secs: 60 }
  ];
  for (const i of intervals) {
    const count = Math.floor(seconds / i.secs);
    if (count >= 1) return `il y a ${count}${i.label}`;
  }
  return "à l'instant";
}

/** Détecte le type + l'ID d'une vidéo à partir d'une URL */
function extractVideoId(url) {
  if (!url) return { type: null, id: null };
  if (url.includes("youtube.com") || url.includes("youtu.be")) {
    const match = url.match(/(?:v=|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);
    return { type: "youtube", id: match ? match[1] : null };
  }
  if (url.includes("vimeo.com")) {
    const match = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    return { type: "vimeo", id: match ? match[1] : null };
  }
  if (url.includes("loom.com")) {
    const match = url.match(/loom\.com\/share\/([a-zA-Z0-9]+)/);
    return { type: "loom", id: match ? match[1] : null };
  }
  if (url.includes("drive.google.com")) {
    const match = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
    return { type: "drive", id: match ? match[1] : null };
  }
  return { type: "file", id: url };
}

/** Retourne l'URL d'embed d'une vidéo selon son type */
function getVideoEmbed(videoType, videoId) {
  switch (videoType) {
    case "youtube":
      return `https://www.youtube.com/embed/${videoId}`;
    case "vimeo":
      return `https://player.vimeo.com/video/${videoId}?title=0&byline=0&portrait=0&color=F5A623`;
    case "loom":
      return `https://www.loom.com/embed/${videoId}`;
    case "drive":
      return `https://drive.google.com/file/d/${videoId}/preview`;
    default:
      return videoId; // fichier direct
  }
}

/** Copie du texte dans le presse-papier */
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast("Copié !", "success");
  } catch (e) {
    const el = document.createElement("textarea");
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand("copy");
    el.remove();
    showToast("Copié !", "success");
  }
}

/** Ouvre un partage WhatsApp pré-rempli */
function shareWhatsApp(text, url) {
  const message = encodeURIComponent(`${text} ${url}`);
  window.open(`https://wa.me/?text=${message}`, "_blank");
}

/** Ouvre un partage Telegram pré-rempli */
function shareTelegram(text, url) {
  const message = encodeURIComponent(text);
  window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${message}`, "_blank");
}

/** Partage natif (mobile) si disponible, sinon fallback WhatsApp */
async function shareNative(title, text, url) {
  if (navigator.share) {
    try {
      await navigator.share({ title, text, url });
      return;
    } catch (e) {
      /* utilisateur a annulé */
      return;
    }
  }
  shareWhatsApp(text, url);
}

/** Formate un nombre en FCFA */
function formatFCFA(amount) {
  return `${Number(amount).toLocaleString("fr-FR")} FCFA`;
}

/** Récupère un paramètre de l'URL */
function getUrlParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

/** Échappe le HTML pour éviter les injections dans le contenu généré par les utilisateurs */
function escapeHtml(str) {
  if (!str) return "";
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

/** Debounce simple pour les champs de recherche */
function debounce(fn, delay = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

window.GriotUtils = {
  showToast,
  timeAgo,
  extractVideoId,
  getVideoEmbed,
  copyToClipboard,
  shareWhatsApp,
  shareTelegram,
  shareNative,
  formatFCFA,
  getUrlParam,
  escapeHtml,
  debounce
};
