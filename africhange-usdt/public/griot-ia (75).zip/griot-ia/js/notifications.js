/* Griot IA — Notifications push + centre de notifications serveur */
const GriotNotifications = {
  lastSeen: {},
  ready: false,
  uid: "",

  async init() {
    if (this.ready) return;
    try { this.lastSeen = JSON.parse(localStorage.getItem("griot_notif_seen") || "{}"); } catch (e) { this.lastSeen = {}; }
    if (!("serviceWorker" in navigator) || !("Notification" in window)) return;
    try { await navigator.serviceWorker.register("/sw.js"); } catch (e) { return; }

    if (Notification.permission === "default") await Notification.requestPermission();
    if (Notification.permission !== "granted") return;

    this.ready = true;
    await this.check(true);
    setInterval(() => this.check(false), 45000);
  },

  save() {
    try { localStorage.setItem("griot_notif_seen", JSON.stringify(this.lastSeen)); } catch (e) {}
  },

  track(key, newest, silent, makeNotif, forceNotify) {
    if (this.lastSeen[key] === undefined) {
      this.lastSeen[key] = newest ? newest.id : null;
      this.save();
      if (newest && forceNotify) {
        const n = makeNotif(newest);
        this.notify(n.title, n.body, n.url);
      }
      return;
    }
    if (newest && newest.id !== this.lastSeen[key]) {
      this.lastSeen[key] = newest.id;
      this.save();
      if (!silent) {
        const n = makeNotif(newest);
        this.notify(n.title, n.body, n.url);
      }
    }
  },

  async check(silent) {
    const sb = window.sb;
    if (!sb || !window.GriotAuth) return;
    try {
      const session = await window.GriotAuth.getSession();
      this.uid = session?.user?.id || "";
    } catch (e) { return; }
    if (!this.uid) return;
    const uid = this.uid;

    const since = new Date(Date.now() - 3 * 60 * 1000).toISOString();

    // 🔔 Notifications serveur (leçons, ressources, lives, posts,
    // annonces, mot du jour, bienvenue, commentaires...) :
    // le serveur écrit pour tout le monde → on pousse les fraîches
    try {
      const { data } = await sb.from("community_notifications")
        .select("id,message,link").eq("user_id", uid)
        .gte("created_at", since).order("created_at", { ascending: false }).limit(1);
      this.track("inapp", data && data[0], false, (x) => ({ title: "🔔 Griot IA", body: x.message, url: x.link || "/app/index.html" }), true);
    } catch (e) {}

    // 💬 Messages privés reçus (push direct)
    try {
      const { data: convs } = await sb.from("conversations").select("id").or(`user_a.eq.${uid},user_b.eq.${uid}`).limit(20);
      if (convs && convs.length) {
        const ids = convs.map((c) => c.id).join(",");
        const { data } = await sb.from("messages").select("id").neq("sender_id", uid).in("conversation_id", ids).gte("created_at", since).order("created_at", { ascending: false }).limit(1);
        this.track("messages", data && data[0], silent, () => ({ title: "💬 Nouveau message", body: "Quelqu'un t'a écrit sur Griot IA", url: "/app/messages.html" }));
      } else {
        this.track("messages", null, silent, null);
      }
    } catch (e) {}

    await this.refreshBadge();
  },

  async refreshBadge() {
    try {
      const { count } = await window.sb.from("community_notifications")
        .select("id", { count: "exact", head: true })
        .eq("user_id", this.uid).eq("is_read", false);
      if (navigator.setBadge) {
        if (count && count > 0) await navigator.setBadge(count);
        else await navigator.clearBadge();
      }
    } catch (e) {}
  },

  async notify(title, body, url) {
    try {
      const reg = await navigator.serviceWorker.ready;
      await reg.showNotification(title, { body, icon: "/icon-192.png", badge: "/icon-192.png", data: { url } });
    } catch (e) {
      try { new Notification(title, { body, icon: "/icon-192.png" }); } catch (e2) {}
    }
    await this.refreshBadge();
  },

  // ---------- 🔔 CENTRE DE NOTIFICATIONS (cloche) ----------
  async openPanel() {
    const existing = document.getElementById("notif-panel-overlay");
    if (existing) { existing.remove(); return; }
    const profile = await window.GriotAuth.getProfile();
    if (!profile) return;

    const overlay = document.createElement("div");
    overlay.id = "notif-panel-overlay";
    overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:700;display:flex;align-items:flex-start;justify-content:center;padding:70px 12px 12px;";
    overlay.innerHTML = `
      <div style="width:100%;max-width:420px;max-height:70vh;overflow-y:auto;background:#fff;border-radius:16px;padding:16px;box-shadow:0 10px 40px rgba(0,0,0,.3);">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <strong>🔔 Notifications</strong>
          <button id="notif-panel-close" style="border:none;background:transparent;font-size:18px;cursor:pointer;">✕</button>
        </div>
        <div id="notif-panel-list" style="margin-top:12px;"><p style="text-align:center;">Chargement...</p></div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
    document.getElementById("notif-panel-close").addEventListener("click", () => overlay.remove());

    const { data } = await window.sb.from("community_notifications").select("*").eq("user_id", profile.id).order("created_at", { ascending: false }).limit(30);
    const list = document.getElementById("notif-panel-list");
    if (!data || !data.length) {
      list.innerHTML = `<p style="text-align:center;opacity:.6;">Aucune notification pour le moment.</p>`;
      return;
    }
    list.innerHTML = data.map((n) => `
      <div class="card" data-nid="${n.id}" data-link="${n.link || ""}" style="margin-top:8px;padding:12px;cursor:pointer;${n.is_read ? "opacity:.55;" : "border-left:3px solid #F5A623;"}">
        <div style="font-size:13px;">${window.GriotUtils.escapeHtml(n.message)}</div>
      </div>`).join("");
    list.querySelectorAll("[data-nid]").forEach((el) => {
      el.addEventListener("click", async () => {
        const id = el.getAttribute("data-nid");
        const link = el.getAttribute("data-link");
        await window.sb.from("community_notifications").update({ is_read: true }).eq("id", id);
        overlay.remove();
        if (window.GriotApp && window.GriotApp.refreshNotifBadge) window.GriotApp.refreshNotifBadge(profile);
        await this.refreshBadge();
        if (link) window.location.href = link;
      });
    });
  }
};

window.GriotNotifications = GriotNotifications;

// 🔔 La cloche ouvre le centre
document.addEventListener("click", (e) => {
  const bell = e.target && e.target.closest ? e.target.closest("#notif-bell-btn") : null;
  if (bell) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.GriotNotifications.openPanel();
  }
}, true);