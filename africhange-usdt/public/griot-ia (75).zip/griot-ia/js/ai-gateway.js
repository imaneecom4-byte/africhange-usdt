/* ============================================================
   GRIOT IA — Coach IA (4 serveurs + secours intelligent)
   + chargement automatique de la visite guidée (onboarding)
   ============================================================ */

const GriotAI = {
  QUOTAS: { free: 20, formation: 100, accompagnement: null },

  SYSTEM_PROMPT: `Tu es le Coach IA de Griot IA, une plateforme qui forme des débutants africains à vendre des produits digitaux grâce à l'IA. 
Tu réponds TOUJOURS en français, avec des mots simples, un ton chaleureux, encourageant et concret, comme un grand frère qui explique. 
Donne des conseils actionnables, évite le jargon technique inutile, et reste bref (5-8 phrases maximum sauf si on te demande un détail). 
Tu aides sur : trouver un produit digital à vendre, créer une offre, faire du marketing sur WhatsApp/Facebook/TikTok, répondre aux objections clients, utiliser l'IA pour créer du contenu.`,

  FALLBACK_RESPONSES: {
    salut: "Salut 👋 ! Trop content de te voir ici. Dis-moi : aujourd'hui tu veux avancer sur quoi ? Trouver un produit à vendre, attirer des clients, ou créer du contenu avec l'IA ?",
    merci: "Avec plaisir 🙏 ! C'est ça la famille Griot IA : on avance ensemble. Reviens me voir dès que tu as une question, je suis là 24h/24.",
    quies: "Je suis ton Coach IA 🤖, ton grand frère digital. Ma mission : t'aider à vendre des produits digitaux grâce à l'IA, avec des conseils simples et concrets. Alors, on commence par quoi ?",
    produit: "Bonne question ! Pour un premier produit digital, je te conseille un guide PDF ou un mini-cours vidéo sur un sujet que tu maîtrises. Commence simple : 20-30 pages ou 5 vidéos de 5 minutes. L'important c'est de résoudre UN problème précis pour ton client. Tu veux qu'on creuse ton idée ensemble ?",
    marketing: "Pour vendre en Afrique, WhatsApp est ton meilleur ami. 1) Crée une liste de 50 contacts intéressés, 2) Partage du contenu gratuit pendant 1 semaine, 3) Propose ton offre. Ensuite Facebook et TikTok pour élargir. La règle d'or : donner de la valeur avant de vendre ! Tu veux un plan précis pour WhatsApp ?",
    prix: "Pour fixer ton prix : regarde ce que font les autres dans ta niche, puis positionne-toi. En Afrique, 5.000 à 15.000 F CFA pour un premier produit digital fonctionne très bien. Commence bas pour avoir tes premiers clients + témoignages, puis augmente. Ton produit actuel, c'est quoi ?",
    objection: "Les objections normales : 'C'est trop cher' → montre la valeur (ce que le client va GAGNER). 'Je dois réfléchir' → propose une garantie 7 jours. 'Je n'ai pas le temps' → montre que ta formation est courte et pratique. Quelle objection te bloque le plus ?",
    ia: "L'IA peut TOUT faire pour toi : écrire tes posts, créer tes visuels, monter tes vidéos courtes, répondre à tes clients. Commence par ChatGPT (texte) et Canva IA (visuels). 30 minutes par jour avec l'IA = 3h de travail gagné. Tu veux des prompts prêts à l'emploi ?",
    defaut: "Bonne question ! Voici mon conseil : commence PETIT, teste vite, ajuste. En vente digitale, l'action bat toujours la réflexion. Je suis là 24h/24 pour t'accompagner, repose-moi ta question si tu veux plus de détails !"
  },

  /** Réponse intelligente selon les mots-clés */
  getSmartFallback(userMessage) {
    const msg = userMessage.toLowerCase().trim();
    if (/^(salut|bonjour|bonsoir|coucou|slt|hello|ça va|ca va)/.test(msg)) return this.FALLBACK_RESPONSES.salut;
    if (msg.includes("merci")) return this.FALLBACK_RESPONSES.merci;
    if (msg.includes("qui es-tu") || msg.includes("qui es tu") || msg.includes("c'est quoi") || msg.includes("tu es qui")) return this.FALLBACK_RESPONSES.quies;
    if (msg.includes("produit") || msg.includes("quoi vendre") || msg.includes("idée")) return this.FALLBACK_RESPONSES.produit;
    if (msg.includes("vendre") || msg.includes("marketing") || msg.includes("whatsapp") || msg.includes("facebook") || msg.includes("tiktok") || msg.includes("client")) return this.FALLBACK_RESPONSES.marketing;
    if (msg.includes("prix") || msg.includes("coût") || msg.includes("combien") || msg.includes("tarif")) return this.FALLBACK_RESPONSES.prix;
    if (msg.includes("cher") || msg.includes("réfléchir") || msg.includes("pas le temps") || msg.includes("objection")) return this.FALLBACK_RESPONSES.objection;
    if (msg.includes("ia") || msg.includes("chatgpt") || msg.includes("intelligence artificielle") || msg.includes("automatiser")) return this.FALLBACK_RESPONSES.ia;
    return this.FALLBACK_RESPONSES.defaut;
  },

  getQuota(plan) {
    return Object.prototype.hasOwnProperty.call(this.QUOTAS, plan) ? this.QUOTAS[plan] : this.QUOTAS.free;
  },

  async checkAndResetQuota(profile) {
    const sb = window.sb;
    const resetAt = profile.ai_quota_reset_at ? new Date(profile.ai_quota_reset_at) : new Date();
    const now = new Date();
    const oneMonthLater = new Date(resetAt);
    oneMonthLater.setMonth(oneMonthLater.getMonth() + 1);
    if (now >= oneMonthLater) {
      await sb.from("profiles").update({ ai_quota_used: 0, ai_quota_reset_at: now.toISOString() }).eq("id", profile.id);
      profile.ai_quota_used = 0;
      profile.ai_quota_reset_at = now.toISOString();
    }
    return profile;
  },

  getHistory(userId) {
    try {
      return JSON.parse(localStorage.getItem(`griot_coach_history_${userId}`) || "[]");
    } catch (e) {
      return [];
    }
  },
  saveHistory(userId, history) {
    localStorage.setItem(`griot_coach_history_${userId}`, JSON.stringify(history.slice(-30)));
  },

  /** Gemini → Groq → Pollinations → OpenRouter → secours intelligent */
  async sendMessage(profile, userMessage) {
    await this.checkAndResetQuota(profile);
    const quota = this.getQuota(profile.plan);
    if (quota !== null && profile.ai_quota_used >= quota) {
      const err = new Error(`Tu as atteint ta limite de ${quota} messages ce mois-ci avec ton plan actuel.`);
      err.quotaExceeded = true;
      throw err;
    }

    const history = this.getHistory(profile.id);
    let replyText;

    try {
      replyText = await this.callGemini(history, userMessage);
    } catch (e) {
      console.warn("Gemini KO :", e.message);
      try {
        replyText = await this.callGroq(history, userMessage);
      } catch (e2) {
        console.warn("Groq KO :", e2.message);
        try {
          replyText = await this.callPollinations(history, userMessage);
        } catch (e3) {
          console.warn("Pollinations KO :", e3.message);
          try {
            replyText = await this.callOpenRouter(history, userMessage);
          } catch (e4) {
            console.warn("OpenRouter KO → secours intelligent");
            replyText = this.getSmartFallback(userMessage);
          }
        }
      }
    }

    history.push({ role: "user", content: userMessage });
    history.push({ role: "assistant", content: replyText });
    this.saveHistory(profile.id, history);

    const newUsed = profile.ai_quota_used + 1;
    await window.sb.from("profiles").update({ ai_quota_used: newUsed }).eq("id", profile.id);
    profile.ai_quota_used = newUsed;

    return { reply: replyText, remaining: quota === null ? null : quota - newUsed };
  },

  /** Serveur 1 : Gemini */
  async callGemini(history, userMessage) {
    const apiKey = window.GRIOT_CONFIG.GEMINI_API_KEY;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    const contents = [
      ...history.map((h) => ({
        role: h.role === "assistant" ? "model" : "user",
        parts: [{ text: h.content }]
      })),
      { role: "user", parts: [{ text: userMessage }] }
    ];

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: this.SYSTEM_PROMPT }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 500 }
      })
    });
    if (!res.ok) throw new Error(`Gemini HTTP ${res.status}`);
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) throw new Error("Réponse Gemini vide");
    return text.trim();
  },

  /** Serveur 2 : Groq */
  async callGroq(history, userMessage) {
    const apiKey = window.GRIOT_CONFIG.GROQ_API_KEY;
    const url = "https://api.groq.com/openai/v1/chat/completions";

    const messages = [
      { role: "system", content: this.SYSTEM_PROMPT },
      ...history.map((h) => ({ role: h.role, content: h.content })),
      { role: "user", content: userMessage }
    ];

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages,
        temperature: 0.7,
        max_tokens: 500
      })
    });
    if (!res.ok) throw new Error(`Groq HTTP ${res.status}`);
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new Error("Réponse Groq vide");
    return text.trim();
  },

  /** Serveur 3 : Pollinations (GRATUIT, sans clé) */
  async callPollinations(history, userMessage) {
    const messages = [
      { role: "system", content: this.SYSTEM_PROMPT },
      ...history.slice(-6).map((h) => ({ role: h.role, content: h.content })),
      { role: "user", content: userMessage }
    ];
    const res = await fetch("https://text.pollinations.ai/openai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "openai", messages, temperature: 0.7, max_tokens: 500 })
    });
    if (!res.ok) throw new Error(`Pollinations HTTP ${res.status}`);
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new Error("Réponse Pollinations vide");
    return text.trim();
  },

  /** Serveur 4 : OpenRouter (si clé configurée) */
  async callOpenRouter(history, userMessage) {
    const apiKey = window.GRIOT_CONFIG.OPENROUTER_API_KEY;
    if (!apiKey) throw new Error("Pas de clé OpenRouter");
    const url = "https://openrouter.ai/api/v1/chat/completions";

    const messages = [
      { role: "system", content: this.SYSTEM_PROMPT },
      ...history.map((h) => ({ role: h.role, content: h.content })),
      { role: "user", content: userMessage }
    ];

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        "HTTP-Referer": window.location.origin,
        "X-Title": "Griot IA"
      },
      body: JSON.stringify({
        model: "meta-llama/llama-3.2-3b-instruct:free",
        messages,
        temperature: 0.7,
        max_tokens: 500
      })
    });
    if (!res.ok) throw new Error(`OpenRouter HTTP ${res.status}`);
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new Error("Réponse OpenRouter vide");
    return text.trim();
  },

  mountWidget(profile) {
    if (document.getElementById("coach-ia-btn")) return;

    const btn = document.createElement("button");
    btn.id = "coach-ia-btn";
    btn.innerHTML = "🤖";
    document.body.appendChild(btn);

    const overlay = document.createElement("div");
    overlay.id = "coach-overlay";
    document.body.appendChild(overlay);

    const panel = document.createElement("div");
    panel.id = "coach-ia-panel";
    panel.innerHTML = `
      <div class="coach-header">
        <div>
          <div style="font-weight:700;">🤖 Coach IA</div>
          <div style="font-size:11px;opacity:.8;" id="coach-quota-label"></div>
        </div>
        <button id="coach-close-btn" style="color:#fff;font-size:22px;">✕</button>
      </div>
      <div class="coach-messages" id="coach-messages"></div>
      <div class="coach-input-row">
        <input type="text" id="coach-input" class="form-control" placeholder="Pose ta question..." />
        <button id="coach-send-btn" class="btn btn-primary btn-sm">Envoyer</button>
      </div>
    `;
    document.body.appendChild(panel);

    const messagesEl = panel.querySelector("#coach-messages");
    const history = this.getHistory(profile.id);
    if (history.length === 0) {
      this.appendBubble(messagesEl, "bot", "Salut 👋 Je suis ton Coach IA. Pose-moi une question sur la vente de produits digitaux, le marketing ou l'utilisation de l'IA !");
    } else {
      history.forEach((h) => this.appendBubble(messagesEl, h.role === "user" ? "user" : "bot", h.content));
    }
    this.updateQuotaLabel(profile);

    const open = () => { panel.classList.add("open"); overlay.classList.add("open"); };
    const close = () => { panel.classList.remove("open"); overlay.classList.remove("open"); };

    btn.addEventListener("click", open);
    overlay.addEventListener("click", close);
    panel.querySelector("#coach-close-btn").addEventListener("click", close);

    const sendBtn = panel.querySelector("#coach-send-btn");
    const input = panel.querySelector("#coach-input");

    const send = async () => {
      const msg = input.value.trim();
      if (!msg) return;
      input.value = "";
      this.appendBubble(messagesEl, "user", msg);
      const loadingBubble = this.appendBubble(messagesEl, "bot", "…");
      sendBtn.disabled = true;
      try {
        const result = await this.sendMessage(profile, msg);
        loadingBubble.textContent = result.reply;
        this.updateQuotaLabel(profile);
      } catch (err) {
        if (err.quotaExceeded) {
          loadingBubble.remove();
          this.appendQuotaExceededBubble(messagesEl, profile, err.message);
        } else {
          loadingBubble.textContent = err.message;
        }
      } finally {
        sendBtn.disabled = false;
        messagesEl.scrollTop = messagesEl.scrollHeight;
      }
    };
    sendBtn.addEventListener("click", send);
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
  },

  appendBubble(container, who, text) {
    const bubble = document.createElement("div");
    bubble.className = `coach-msg ${who}`;
    bubble.textContent = text;
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
    return bubble;
  },

  appendQuotaExceededBubble(container, profile, message) {
    const bubble = document.createElement("div");
    bubble.className = "coach-msg bot";
    const upgradeUrl = profile.plan === "free" ? "/app/sales-formation.html" : "/app/sales-accompagnement.html";
    bubble.innerHTML = "";
    const textEl = document.createElement("div");
    textEl.textContent = message;
    bubble.appendChild(textEl);
    const btn = document.createElement("a");
    btn.href = upgradeUrl;
    btn.className = "btn btn-primary btn-sm mt-8";
    btn.style.display = "inline-block";
    btn.textContent = "Passer au plan supérieur";
    bubble.appendChild(btn);
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
    return bubble;
  },

  updateQuotaLabel(profile) {
    const el = document.getElementById("coach-quota-label");
    if (!el) return;
    const quota = this.getQuota(profile.plan);
    if (quota === null) {
      el.textContent = "Messages illimités ∞";
      return;
    }
    const remaining = Math.max(0, quota - profile.ai_quota_used);
    el.textContent = `${remaining} message${remaining > 1 ? "s" : ""} restant${remaining > 1 ? "s" : ""} ce mois-ci`;
  }
};

window.GriotAI = GriotAI;

// ----- Visite guidée pour les nouveaux (1 fois par page) -----
window.addEventListener("load", () => {
  const s = document.createElement("script");
  s.src = "/js/onboarding.js";
  s.onload = () => window.GriotOnboarding && window.GriotOnboarding.maybeStart();
  document.head.appendChild(s);
});