/* ============================================================
   GRIOT IA — Authentification, session, RBAC
   ============================================================ */

const GriotAuth = {
  /** Inscription email + mot de passe */
  async signup(email, password, fullName, referralCode) {
    const sb = window.sb;
    const { data, error } = await sb.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } }
    });
    if (error) throw error;

    if (referralCode && data.user) {
      await this.applyReferralCode(data.user.id, referralCode);
    }

    // 🎉 NOTIFICATION DE BIENVENUE AUTOMATIQUE
    if (data.user) {
      try {
        const firstName = (fullName || "").split(" ")[0] || "ami";
        await sb.from("community_notifications").insert({
          user_id: data.user.id,
          type: "welcome",
          message: `👋 Bienvenue ${firstName} ! Tu fais maintenant partie de la famille Griot IA. Ta première leçon t'attend dans le Classroom 🎓`,
          link: "/app/classroom.html",
          is_read: false
        });
      } catch (e) {
        console.error("Welcome notif failed:", e);
      }
    }

    return data;
  },

  async login(email, password) {
    const sb = window.sb;
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  },

  async logout() {
    await window.sb.auth.signOut();
    window.location.href = "/login.html";
  },

  async getSession() {
    const { data } = await window.sb.auth.getSession();
    return data.session;
  },

  async getProfile() {
    const session = await this.getSession();
    if (!session) return null;
    const { data, error } = await window.sb
      .from("profiles")
      .select("*")
      .eq("id", session.user.id)
      .single();
    if (error) return null;
    return data;
  },

  /** Applique un code de parrainage (avec capture IP + anti-fraude) */
  async applyReferralCode(newUserId, code) {
    const sb = window.sb;
    try {
      const { data: referrer } = await sb
        .from("profiles")
        .select("id")
        .eq("referral_code", code.toUpperCase())
        .single();
      if (!referrer || referrer.id === newUserId) return;

      await sb.from("profiles").update({ referred_by: referrer.id }).eq("id", newUserId);

      let ipAddress = null;
      try {
        const ipRes = await fetch("https://api.ipify.org?format=json");
        const ipData = await ipRes.json();
        ipAddress = ipData.ip || null;
      } catch (e) { /* silencieux */ }

      const { error } = await sb.from("referrals").insert({
        referrer_id: referrer.id,
        referred_id: newUserId,
        status: "pending",
        ip_address: ipAddress
      });

      if (error && error.code === '23505') {
        await sb.from("referrals").update({ status: "pending" }).eq("referred_id", newUserId);
      }
    } catch (e) {
      console.error("Erreur parrainage:", e);
    }
  },

  async requireStudent() {
    const session = await this.getSession();
    if (!session) {
      window.location.href = "/login.html";
      return null;
    }
    const profile = await this.getProfile();
    if (!profile) {
      window.location.href = "/login.html";
      return null;
    }
    if (profile.is_banned) {
      await this.logout();
      return null;
    }
    if (!profile.referred_by && window.GriotReferral?.getStoredReferralCode) {
      const stored = window.GriotReferral.getStoredReferralCode();
      if (stored) await this.applyReferralCode(profile.id, stored);
    }
    await this.checkPlanExpiration(profile);
    return profile;
  },

  async requireAdmin() {
    const session = await this.getSession();
    if (!session) {
      window.location.href = "/login.html";
      return null;
    }
    const profile = await this.getProfile();
    if (!profile || (profile.role !== "admin" && profile.role !== "owner")) {
      window.location.href = "/app/index.html";
      return null;
    }
    return profile;
  },

  async requireStaff() {
    const session = await this.getSession();
    if (!session) {
      window.location.href = "/login.html";
      return null;
    }
    const profile = await this.getProfile();
    if (!profile || !["admin", "owner", "moderator"].includes(profile.role)) {
      window.location.href = "/app/index.html";
      return null;
    }
    return profile;
  },

  async checkPlanExpiration(profile) {
    if (!profile.plan_expires_at) return profile;
    const expires = new Date(profile.plan_expires_at);
    if (expires < new Date() && profile.plan !== "free") {
      const formattedDate = expires.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
      await window.sb
        .from("profiles")
        .update({ plan: "free", plan_expires_at: null })
        .eq("id", profile.id);
      profile.plan = "free";
      profile.plan_expires_at = null;
      window.GriotUtils?.showToast(`Ton abonnement a expiré le ${formattedDate} — renouvelle pour retrouver tous tes accès.`, "error", 6000);
    }
    return profile;
  },

  redirectAfterLogin(profile) {
    if (profile.role === "admin" || profile.role === "owner") {
      window.location.href = "/admin/index.html";
    } else {
      window.location.href = "/app/index.html";
    }
  }
};

window.GriotAuth = GriotAuth;