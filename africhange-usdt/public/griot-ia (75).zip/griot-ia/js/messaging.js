/* ============================================================
   GRIOT IA — Messagerie privée
   ============================================================ */

const GriotMessaging = {
  MP_UNLOCK_THRESHOLD: 500,

  /** Vérifie si l'utilisateur peut envoyer des MP à d'autres élèves */
  canMessageStudents(profile) {
    // Le staff (admin/owner/moderator) peut écrire à tout le monde sans condition
    if (["admin", "owner", "moderator"].includes(profile.role)) return true;
    // Les autres doivent être en Accompagnement + 500 points
    return profile.plan === "accompagnement" && profile.points >= this.MP_UNLOCK_THRESHOLD;
  },

  /** Vérifie si l'utilisateur peut contacter l'admin (formation + accompagnement) */
  canMessageAdmin(profile) {
    return profile.plan === "formation" || profile.plan === "accompagnement";
  },

  /** Récupère ou crée une conversation entre deux utilisateurs */
  async getOrCreateConversation(userIdA, userIdB) {
    const sb = window.sb;
    const [a, b] = [userIdA, userIdB].sort();
    const { data: existing } = await sb
      .from("conversations")
      .select("*")
      .eq("user_a", a)
      .eq("user_b", b)
      .maybeSingle();
    if (existing) return existing;

    const { data: created, error } = await sb
      .from("conversations")
      .insert({ user_a: a, user_b: b })
      .select()
      .single();
    if (error) throw error;
    return created;
  },

  /** Liste les conversations de l'utilisateur courant, triées par dernier message */
  async listConversations(userId) {
    const sb = window.sb;
    const { data, error } = await sb
      .from("conversations")
      .select("*, a:user_a(id, full_name, avatar_url, role), b:user_b(id, full_name, avatar_url, role)")
      .or(`user_a.eq.${userId},user_b.eq.${userId}`)
      .order("last_message_at", { ascending: false });
    if (error) return [];
    return data.map((c) => ({
      ...c,
      otherUser: c.user_a === userId ? c.b : c.a
    }));
  },

  /** Récupère les messages d'une conversation */
  async getMessages(conversationId) {
    const sb = window.sb;
    const { data, error } = await sb
      .from("messages")
      .select("*, sender:sender_id(full_name, avatar_url)")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });
    if (error) return [];
    return data;
  },

  /** Envoie un message via la fonction sécurisée send_message */
  async sendMessage(conversationId, senderId, content, attachmentUrl = null, attachmentType = null, isSaleProof = false) {
    const sb = window.sb;
    const { error } = await sb.rpc("send_message", {
      p_conversation: conversationId,
      p_content: content,
      p_attachment_url: attachmentUrl,
      p_attachment_type: attachmentType,
      p_is_sale_proof: isSaleProof
    });
    if (error) throw error;
    return { id: null };
  },

  /** Upload un fichier (photo max 5Mo / vidéo max 25Mo) vers Supabase Storage */
  async uploadAttachment(file, userId) {
    const sb = window.sb;
    const isVideo = file.type.startsWith("video/");
    const maxSize = isVideo ? 25 * 1024 * 1024 : 5 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new Error(isVideo ? "Vidéo trop lourde (max 25Mo)" : "Photo trop lourde (max 5Mo)");
    }
    const path = `${userId}/${Date.now()}-${file.name}`;
    const { error } = await sb.storage.from("messages").upload(path, file, { upsert: false });
    if (error) throw error;
    const { data: publicUrl } = sb.storage.from("messages").getPublicUrl(path);
    return { url: publicUrl.publicUrl, type: isVideo ? "video" : "image" };
  },

  /** Admin : valide une preuve de vente → +100 points au vendeur */
  async approveSaleProof(messageId, sellerId) {
    const sb = window.sb;
    await sb.from("messages").update({ sale_proof_status: "approved" }).eq("id", messageId);
    await window.GriotGamification.addPoints(sellerId, window.GriotGamification.POINTS.sale_validated);
  },

  /** Admin : rejette une preuve de vente */
  async rejectSaleProof(messageId) {
    await window.sb.from("messages").update({ sale_proof_status: "rejected" }).eq("id", messageId);
  },

  /** Compte le nombre total de messages non lus reçus par l'utilisateur (toutes conversations) */
  async getUnreadCount(userId) {
    const sb = window.sb;
    const { data: convIds } = await sb
      .from("conversations")
      .select("id")
      .or(`user_a.eq.${userId},user_b.eq.${userId}`);
    const ids = (convIds || []).map((c) => c.id);
    if (!ids.length) return 0;
    const { count } = await sb
      .from("messages")
      .select("id", { count: "exact", head: true })
      .in("conversation_id", ids)
      .neq("sender_id", userId)
      .is("read_at", null);
    return count || 0;
  },

  /** Marque tous les messages reçus d'une conversation comme lus (fonction sécurisée) */
  async markConversationRead(conversationId, userId) {
    await window.sb.rpc("mark_conversation_read", { p_conversation: conversationId });
  },

  /** Liste TOUTES les conversations de la plateforme (réservé admin — les policies RLS l'autorisent) */
  async listAllConversations() {
    const sb = window.sb;
    const { data, error } = await sb
      .from("conversations")
      .select("*, a:user_a(id, full_name, avatar_url, role), b:user_b(id, full_name, avatar_url, role)")
      .order("last_message_at", { ascending: false });
    if (error) return [];
    return data;
  }
};

window.GriotMessaging = GriotMessaging;