/* ============================================================
   GRIOT IA — Mode nuit / mode soleil
   Le choix est enregistré dans localStorage (persiste après
   fermeture, sur toutes les pages, côté membre ET admin).
   Par défaut : mode soleil (clair).
   ============================================================ */

const GriotTheme = {
  STORAGE_KEY: "griot_theme",

  getCurrent() {
    return localStorage.getItem(this.STORAGE_KEY) === "dark" ? "dark" : "light";
  },

  apply(theme) {
    if (theme === "dark") {
      document.documentElement.setAttribute("data-theme", "dark");
    } else {
      document.documentElement.removeAttribute("data-theme");
    }
  },

  /** À appeler le plus tôt possible (avant même onSbReady) pour éviter un flash de couleur claire */
  init() {
    this.apply(this.getCurrent());
  },

  toggle() {
    const next = this.getCurrent() === "dark" ? "light" : "dark";
    localStorage.setItem(this.STORAGE_KEY, next);
    this.apply(next);
    this.updateButtonIcon();
  },

  updateButtonIcon() {
    const btn = document.getElementById("theme-toggle-btn");
    if (btn) btn.textContent = this.getCurrent() === "dark" ? "☀️" : "🌙";
  },

  /** Monte le bouton bascule 🌙/☀️ dans le conteneur donné (ou en position fixe par défaut) */
  mountToggleButton(container) {
    if (document.getElementById("theme-toggle-btn")) return;
    const btn = document.createElement("button");
    btn.id = "theme-toggle-btn";
    btn.setAttribute("aria-label", "Changer de thème");
    btn.style.cssText = "font-size:18px;line-height:1;";
    btn.textContent = this.getCurrent() === "dark" ? "☀️" : "🌙";
    btn.addEventListener("click", () => this.toggle());
    if (container) {
      container.appendChild(btn);
    } else {
      btn.style.cssText += "position:fixed;top:14px;right:14px;z-index:300;background:var(--card);border-radius:50%;width:36px;height:36px;box-shadow:var(--shadow-card);";
      document.body.appendChild(btn);
    }
  }
};

window.GriotTheme = GriotTheme;
GriotTheme.init();
