/* ============================================================
   GRIOT IA — Bouton WhatsApp flottant
   Lit les réglages (numéro, message, icône, on/off) directement
   depuis la table "settings" à chaque chargement de page : toute
   modification dans admin/settings.html est donc effective
   immédiatement, sans redéploiement du site.
   ============================================================ */

const GriotWhatsApp = {
  DEFAULTS: {
    contact_whatsapp_number: "22871777357",
    contact_whatsapp_message: "Bonjour Griot IA, j'ai une question",
    contact_whatsapp_icon: "",
    contact_whatsapp_enabled: true
  },

  /** Icône par défaut si l'admin n'a pas fourni d'URL personnalisée */
  DEFAULT_ICON_SVG: `<svg viewBox="0 0 32 32" fill="white" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.001 3C9.096 3 3.5 8.596 3.5 15.5c0 2.42.687 4.68 1.877 6.598L3.2 28.8l6.86-2.13a12.44 12.44 0 0 0 5.94 1.51h.001c6.905 0 12.5-5.596 12.5-12.5S22.906 3 16.001 3Zm0 22.727c-1.9 0-3.72-.51-5.297-1.475l-.38-.226-4.07 1.264 1.293-3.965-.247-.407a10.17 10.17 0 0 1-1.573-5.418c0-5.649 4.596-10.245 10.278-10.245 5.648 0 10.244 4.596 10.244 10.245 0 5.68-4.596 10.227-10.248 10.227Zm5.606-7.66c-.308-.154-1.816-.897-2.098-1-.281-.103-.486-.154-.69.154-.205.308-.79 1-.97 1.205-.178.205-.357.23-.665.077-.308-.154-1.3-.479-2.475-1.526-.915-.816-1.533-1.824-1.713-2.132-.18-.308-.02-.474.135-.627.138-.138.308-.36.462-.54.154-.18.205-.308.308-.513.103-.205.051-.385-.026-.539-.077-.154-.69-1.663-.945-2.278-.249-.598-.502-.517-.69-.527-.178-.008-.383-.01-.588-.01-.205 0-.539.077-.82.385-.281.308-1.075 1.05-1.075 2.56 0 1.51 1.1 2.969 1.253 3.174.154.205 2.166 3.307 5.248 4.637.734.317 1.306.506 1.752.648.736.234 1.406.201 1.936.122.59-.088 1.816-.742 2.072-1.46.256-.716.256-1.33.18-1.459-.077-.128-.282-.205-.59-.36Z"/>
  </svg>`,

  cache: null,

  async loadSettings() {
    if (this.cache) return this.cache;
    try {
      const { data } = await window.sb
        .from("settings")
        .select("*")
        .in("key", [
          "contact_whatsapp_number",
          "contact_whatsapp_message",
          "contact_whatsapp_icon",
          "contact_whatsapp_enabled"
        ]);
      const result = { ...this.DEFAULTS };
      (data || []).forEach((row) => {
        let v = row.value;
        if (typeof v === "string") {
          try { v = JSON.parse(v); } catch (e) {}
        }
        if (v !== "" && v !== null && v !== undefined) result[row.key] = v;
      });
      this.cache = result;
      return result;
    } catch (e) {
      return { ...this.DEFAULTS };
    }
  },

  /** Construit le lien wa.me à partir des réglages actuels */
  buildLink(settings) {
    const number = String(settings.contact_whatsapp_number || this.DEFAULTS.contact_whatsapp_number).replace(/[^0-9]/g, "");
    const message = settings.contact_whatsapp_message || this.DEFAULTS.contact_whatsapp_message;
    return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
  },

  /** Positionne le bouton au-dessus de la nav basse / du Coach IA s'ils existent, pour ne rien chevaucher */
  positionButton(btn) {
    const hasNav = !!document.querySelector(".bottom-nav");
    const hasCoach = !!document.getElementById("coach-ia-btn");
    let bottom = 20;
    if (hasNav) bottom = 90;
    if (hasCoach) bottom = Math.max(bottom, 150);
    btn.style.bottom = bottom + "px";
  },

  /** Monte le bouton flottant si le réglage "Afficher le bouton WhatsApp" est activé */
  async mount() {
    if (document.getElementById("whatsapp-float-btn")) return;
    const settings = await this.loadSettings();
    if (settings.contact_whatsapp_enabled === false) return;

    const btn = document.createElement("a");
    btn.id = "whatsapp-float-btn";
    btn.className = "whatsapp-float-btn";
    btn.href = this.buildLink(settings);
    btn.target = "_blank";
    btn.rel = "noopener";
    btn.setAttribute("aria-label", "Contacter Griot IA sur WhatsApp");
    btn.innerHTML = settings.contact_whatsapp_icon
      ? `<img src="${settings.contact_whatsapp_icon}" alt="WhatsApp" />`
      : this.DEFAULT_ICON_SVG;

    document.body.appendChild(btn);
    this.positionButton(btn);
    setTimeout(() => this.positionButton(btn), 800);
  }
};

window.GriotWhatsApp = GriotWhatsApp;
