/* ============================================================
   GRIOT IA — Parrainage (v2 : remontée d'erreurs)
   ============================================================ */

const GriotReferral = {
  REQUIRED_VERIFIED: 5,
  REWARD_DAYS: 30,
  MONTHLY_LIMIT: 10,

  getInviteLink(referralCode) {
    return `${window.location.origin}/invite.html?ref=${referralCode}`;
  },

  getShareMessage() {
    return "Rejoins Griot IA gratuitement 🎓 Apprends à vendre des produits digitaux avec l'IA, même en partant de zéro. Voici mon lien :";
  },

  storeReferralCode(code) {
    const payload = { code, expires: Date.now() + 7 * 24 * 60 * 60 * 1000 };
    localStorage.setItem("griot_referral", JSON.stringify(payload));
  },

  getStoredReferralCode() {
    const raw = localStorage.getItem("griot_referral");
    if (!raw) return null;
    try {
      const payload = JSON.parse(raw);
      if (payload.expires < Date.now()) {
        localStorage.removeItem("griot_referral");
        return null;
      }
      return payload.code;
    } catch (e) {
      return null;
    }
  },

  async getProgress(userId) {
    const sb = window.sb;
    const { data, error } = await sb
      .from("referrals")
      .select("id, status, created_at, referred:referred_id(full_name, email, created_at)")
      .eq("referrer_id", userId)
      .order("created_at", { ascending: false });
    if (error) return { verified: 0, pending: 0, list: [] };
    const verified = data.filter((r) => r.status === "verified").length;
    const pending = data.filter((r) => r.status === "pending").length;
    return { verified, pending, list: data };
  },

  async verifyReferral(referralId) {
    const sb = window.sb;
    const { data: ref, error: readErr } = await sb.from("referrals").select("*").eq("id", referralId).single();
    if (readErr) throw new Error("Lecture impossible : " + readErr.message);
    if (!ref) throw new Error("Parrainage introuvable");

    // 1. Écrire "verified" + récupérer l'erreur
    const { error: updateErr } = await sb.from("referrals").update({ status: "verified" }).eq("id", referralId);
    if (updateErr) throw new Error("Écriture du statut refusée : " + updateErr.message);

    const progress = await this.getProgress(ref.referrer_id);
    const isNewBatchOf5 = progress.verified > 0 && progress.verified % this.REQUIRED_VERIFIED === 0;

    if (isNewBatchOf5) {
      const { data: referrerProfile } = await sb.from("profiles").select("plan").eq("id", ref.referrer_id).single();
      if (referrerProfile?.plan !== "accompagnement") {
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + this.REWARD_DAYS);
        const expIso = expiresAt.toISOString();

        const { error: planErr } = await sb.from("profiles").update({
          plan: "formation",
          plan_expires_at: expIso
        }).eq("id", ref.referrer_id);
        if (planErr) throw new Error("Octroi Formation impossible : " + planErr.message);

        const { error: subErr } = await sb.from("subscriptions").insert({
          user_id: ref.referrer_id,
          plan: "formation",
          billing: "referral",
          amount: 0,
          expires_at: expIso
        });
        if (subErr) throw new Error("Création abonnement impossible : " + subErr.message);
      }
    }
  },

  async checkFraudSignals(referral) {
    const sb = window.sb;
    const signals = [];

    if (referral.ip_address) {
      const { data: sameIp } = await sb
        .from("channel_clicks")
        .select("id")
        .eq("user_id", referral.referrer_id);
      if (sameIp && sameIp.length === 0) signals.push("IP non trackée pour le parrain");
    }

    const { count: monthlyCount } = await sb
      .from("referrals")
      .select("id", { count: "exact", head: true })
      .eq("referrer_id", referral.referrer_id)
      .eq("status", "verified")
      .gte("created_at", new Date(new Date().setDate(1)).toISOString());
    if ((monthlyCount || 0) >= this.MONTHLY_LIMIT) {
      signals.push(`Limite mensuelle atteinte (${this.MONTHLY_LIMIT}/mois)`);
    }

    return signals;
  }
};

window.GriotReferral = GriotReferral;