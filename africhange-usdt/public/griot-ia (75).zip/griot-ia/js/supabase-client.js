/* ============================================================
   GRIOT IA — Client Supabase
   Charge le SDK via CDN et initialise le client global window.sb
   ============================================================ */

// ⚠️ Remplace ces valeurs par celles de ton projet Supabase (Project Settings > API).
// Ce sont des clés PUBLIQUES (anon key), elles peuvent être exposées côté client.
window.GRIOT_CONFIG = {
  SUPABASE_URL: "https://xvvcbwjsxstetdqfjpbd.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_uRXVaruuvA6etaDSu8zfSA_H9HHPaS7",
  OWNER_EMAIL: "imanedoc33@gmail.com",
  GEMINI_API_KEY: "AQ.Ab8RN6KVLAqbHFglhJVRDKsEVhKYIZLUK5rX2dBNoyf4efEdSQ",
  GROQ_API_KEY: "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"
};

(function loadSupabaseSDK() {
  if (window.supabase) {
    window.sb = window.supabase.createClient(
      window.GRIOT_CONFIG.SUPABASE_URL,
      window.GRIOT_CONFIG.SUPABASE_ANON_KEY,
      { auth: { persistSession: true, autoRefreshToken: true } }
    );
    document.dispatchEvent(new Event("griot:sb-ready"));
    return;
  }
  const script = document.createElement("script");
  script.src = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js";
  script.onload = function () {
    window.sb = window.supabase.createClient(
      window.GRIOT_CONFIG.SUPABASE_URL,
      window.GRIOT_CONFIG.SUPABASE_ANON_KEY,
      { auth: { persistSession: true, autoRefreshToken: true } }
    );
    document.dispatchEvent(new Event("griot:sb-ready"));
  };
  document.head.appendChild(script);
})();

/**
 * Attend que window.sb soit prêt puis exécute le callback.
 */
window.onSbReady = function (callback) {
  if (window.sb) return callback(window.sb);
  document.addEventListener("griot:sb-ready", () => callback(window.sb), { once: true });
};
