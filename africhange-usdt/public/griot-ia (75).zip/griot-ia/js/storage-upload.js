/* ============================================================
   GRIOT IA — Upload de fichiers vers Supabase Storage
   Widget réutilisable : bouton "Choisir un fichier" + glisser-déposer
   + barre de progression, upload direct vers un bucket Supabase Storage,
   puis récupération de l'URL publique.

   Utilise XMLHttpRequest (et non le SDK supabase-js) uniquement pour
   pouvoir suivre la progression de l'upload en temps réel — le SDK
   ne l'expose pas.
   ============================================================ */

const GriotUpload = {
  /** Nettoie un nom de fichier pour en faire un chemin de stockage sûr */
  sanitizeFilename(name) {
    return name.replace(/[^a-zA-Z0-9._-]/g, "-");
  },

  /**
   * Upload un fichier vers un bucket Supabase Storage avec suivi de progression.
   * Retourne l'URL publique du fichier une fois l'upload terminé.
   */
  async uploadFile({ file, bucket, folder = "", onProgress }) {
    const path = `${folder ? folder.replace(/\/+$/, "") + "/" : ""}${Date.now()}-${this.sanitizeFilename(file.name)}`;

    const { data: sessionData } = await window.sb.auth.getSession();
    const token = sessionData?.session?.access_token;
    const anonKey = window.GRIOT_CONFIG.SUPABASE_ANON_KEY;
    const uploadUrl = `${window.GRIOT_CONFIG.SUPABASE_URL}/storage/v1/object/${bucket}/${path}`;

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", uploadUrl, true);
      xhr.setRequestHeader("Authorization", `Bearer ${token || anonKey}`);
      xhr.setRequestHeader("apikey", anonKey);
      xhr.setRequestHeader("x-upsert", "false");
      xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");

      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && onProgress) {
          onProgress(Math.round((e.loaded / e.total) * 100));
        }
      };

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          const publicUrl = `${window.GRIOT_CONFIG.SUPABASE_URL}/storage/v1/object/public/${bucket}/${path}`;
          resolve(publicUrl);
        } else {
          let detail = "";
          try {
            const parsed = JSON.parse(xhr.responseText);
            detail = parsed.message || parsed.error || "";
          } catch (e) {
            detail = (xhr.responseText || "").slice(0, 200);
          }

          let message;
          if (xhr.status === 404) {
            message = `Le bucket "${bucket}" n'existe pas encore dans Supabase Storage.`;
          } else if (xhr.status === 400 || xhr.status === 401 || xhr.status === 403) {
            // Supabase renvoie souvent 400 (et non 403) quand une règle RLS bloque l'upload.
            message = `Upload refusé — vérifie les règles (policies) d'upload du bucket "${bucket}" dans Supabase Storage.`;
          } else {
            message = `Échec de l'upload (statut ${xhr.status}).`;
          }
          if (detail) message += ` Détail Supabase : "${detail}"`;
          reject(new Error(message));
        }
      };
      xhr.onerror = () => reject(new Error("Erreur réseau pendant l'upload."));
      xhr.send(file);
    });
  },

  /**
   * Monte un widget d'upload complet (zone glisser-déposer + bouton +
   * aperçu + barre de progression) dans le conteneur DOM fourni.
   *
   * options:
   *  - bucket (obligatoire) : nom du bucket Supabase Storage
   *  - folder : sous-dossier dans le bucket (ex: "covers")
   *  - accept : filtre du sélecteur de fichier (ex: "image/*", "application/pdf")
   *  - existingUrl : URL déjà enregistrée (pour afficher un aperçu au chargement)
   *  - isImage : true pour afficher un aperçu image, false pour un lien fichier générique
   *  - onUploaded(publicUrl) : callback appelé une fois l'upload terminé
   */
  mountUploader(container, { bucket, folder = "", accept = "*/*", existingUrl = "", isImage = false, onUploaded }) {
    const uid = "up_" + Math.random().toString(36).slice(2, 9);

    container.innerHTML = `
      <div class="upload-zone" id="${uid}-zone">
        <input type="file" id="${uid}-input" accept="${accept}" style="display:none;" />
        <div id="${uid}-preview">
          ${
            existingUrl
              ? isImage
                ? `<img src="${existingUrl}" class="upload-preview-img" />`
                : `<div class="upload-preview-file">📎 <a href="${existingUrl}" target="_blank" rel="noopener">Fichier actuel</a></div>`
              : `<div class="upload-placeholder">
                   <div class="upload-icon">${isImage ? "🖼️" : "📄"}</div>
                   <div class="text-sm text-secondary">Glisse un fichier ici, ou</div>
                 </div>`
          }
        </div>
        <button type="button" class="btn btn-outline btn-sm mt-8" id="${uid}-btn">Choisir un fichier</button>
        <div class="upload-progress-track" id="${uid}-progress-track" style="display:none;">
          <div class="upload-progress-fill" id="${uid}-progress-fill"></div>
        </div>
        <div class="text-sm mt-8" id="${uid}-status"></div>
      </div>
    `;

    const zone = document.getElementById(`${uid}-zone`);
    const input = document.getElementById(`${uid}-input`);
    const btn = document.getElementById(`${uid}-btn`);
    const preview = document.getElementById(`${uid}-preview`);
    const status = document.getElementById(`${uid}-status`);
    const progressTrack = document.getElementById(`${uid}-progress-track`);
    const progressFill = document.getElementById(`${uid}-progress-fill`);

    btn.addEventListener("click", () => input.click());

    zone.addEventListener("dragover", (e) => {
      e.preventDefault();
      zone.classList.add("dragover");
    });
    zone.addEventListener("dragleave", () => zone.classList.remove("dragover"));
    zone.addEventListener("drop", (e) => {
      e.preventDefault();
      zone.classList.remove("dragover");
      if (e.dataTransfer.files && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
    });
    input.addEventListener("change", () => {
      if (input.files && input.files[0]) handleFile(input.files[0]);
    });

    async function handleFile(file) {
      status.textContent = `Envoi de "${file.name}"…`;
      status.style.color = "var(--text-secondary)";
      progressTrack.style.display = "block";
      progressFill.style.width = "0%";
      btn.disabled = true;

      try {
        const publicUrl = await GriotUpload.uploadFile({
          file,
          bucket,
          folder,
          onProgress: (pct) => {
            progressFill.style.width = pct + "%";
          }
        });

        status.textContent = "✅ Fichier envoyé";
        status.style.color = "var(--success)";

        preview.innerHTML = isImage
          ? `<img src="${publicUrl}" class="upload-preview-img" />`
          : `<div class="upload-preview-file">📎 <a href="${publicUrl}" target="_blank" rel="noopener">${window.GriotUtils.escapeHtml(file.name)}</a></div>`;

        onUploaded(publicUrl);
      } catch (err) {
        console.error("Erreur upload:", err);
        status.textContent = "❌ " + err.message;
        status.style.color = "var(--error)";
      } finally {
        btn.disabled = false;
        setTimeout(() => {
          progressTrack.style.display = "none";
        }, 1200);
      }
    }
  }
};

window.GriotUpload = GriotUpload;
