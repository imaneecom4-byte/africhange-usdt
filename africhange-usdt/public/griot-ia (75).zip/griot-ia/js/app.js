/* ============================================================
   GRIOT IA — Logique élève partagée (app.js)
   Chaque page /app/*.html appelle une des fonctions ci-dessous
   après avoir vérifié la session via GriotAuth.requireStudent().
   ============================================================ */

const GriotApp = {
  NAV_ITEMS: [
    { key: "accueil", label: "Accueil", icon: "🏠", href: "/app/index.html" },
    { key: "ressources", label: "Ressources", icon: "📚", href: "/app/ressources.html" },
    { key: "classroom", label: "Classroom", icon: "🎓", href: "/app/classroom.html" },
    { key: "community", label: "Communauté", icon: "🏘️", href: "/app/community.html" },
    { key: "messages", label: "Messages", icon: "💬", href: "/app/messages.html", badge: true },
    { key: "calendar", label: "Live", icon: "📅", href: "/app/calendar.html" },
    { key: "leaderboards", label: "Classement", icon: "🏆", href: "/app/leaderboards.html" },
    { key: "profil", label: "Profil", icon: "👤", href: "/app/profil.html" }
  ],

  renderBottomNav(activeKey) {
    const nav = document.createElement("nav");
    nav.className = "bottom-nav";
    nav.innerHTML = this.NAV_ITEMS.map(
      (item) => `
      <a href="${item.href}" class="${item.key === activeKey ? "active" : ""}" style="position:relative;">
        <span class="icon">${item.icon}</span>
        ${item.badge ? `<span id="nav-badge-${item.key}" style="display:none;position:absolute;top:2px;right:18%;background:var(--error);color:#fff;font-size:9px;border-radius:10px;padding:1px 5px;">0</span>` : ""}
        <span>${item.label}</span>
      </a>`
    ).join("");
    document.body.appendChild(nav);
    this.refreshNavBadges();
  },

  async refreshNavBadges() {
    try {
      const session = await window.GriotAuth.getSession();
      if (!session) return;
      const unread = await window.GriotMessaging?.getUnreadCount?.(session.user.id);
      const badge = document.getElementById("nav-badge-messages");
      if (badge) {
        badge.style.display = unread > 0 ? "block" : "none";
        badge.textContent = unread > 9 ? "9+" : unread;
      }
    } catch (e) {}
  },

  renderHeader(profile, title) {
    const header = document.createElement("header");
    header.className = "site-header";
    const planLabels = { free: "Gratuit", formation: "Formation", accompagnement: "Accompagnement" };
    header.innerHTML = `
      <div class="container">
        <a href="/app/index.html" class="logo">Griot<span class="dot">IA</span> 💬</a>
        <div class="flex items-center gap-12">
          <button id="notif-bell-btn" style="position:relative;font-size:19px;">🔔<span id="notif-bell-badge" style="display:none;position:absolute;top:-4px;right:-6px;background:var(--error);color:#fff;font-size:9px;border-radius:10px;padding:1px 5px;"></span></button>
          <a href="/app/profil.html" id="header-profile-btn" style="width:28px;height:28px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0;overflow:hidden;">
            ${profile.avatar_url ? `<img src="${profile.avatar_url}" style="width:100%;height:100%;object-fit:cover;" />` : (profile.full_name || profile.email || "?")[0].toUpperCase()}
          </a>
          <span class="badge badge-gold">${planLabels[profile.plan] || "Gratuit"}</span>
        </div>
      </div>`;
    document.body.prepend(header);
    if (title) document.title = `${title} — Griot IA`;

    (function () {
      const slot = header.querySelector(".flex.items-center.gap-12");
      const mount = () => window.GriotTheme.mountToggleButton(slot);
      if (window.GriotTheme) { window.GriotTheme.init(); mount(); }
      else {
        const s = document.createElement("script");
        s.src = "/js/theme.js";
        s.onload = mount;
        document.head.appendChild(s);
      }
    })();

    document.getElementById("notif-bell-btn").addEventListener("click", () => {
      window.location.href = "/app/community.html";
    });
    this.refreshNotifBadge(profile);
  },

  async refreshNotifBadge(profile) {
    try {
      const { count } = await window.sb.from("community_notifications").select("id", { count: "exact", head: true }).eq("user_id", profile.id).eq("is_read", false);
      const badge = document.getElementById("notif-bell-badge");
      if (badge) {
        badge.style.display = count > 0 ? "block" : "none";
        badge.textContent = count > 9 ? "9+" : count;
      }
    } catch (e) {}
  },

  renderFomoLock(container, message) {
    container.innerHTML = `
      <div class="fomo-wrap">
        <div class="fomo-blur">
          <div class="card mt-16" style="height:120px;"></div>
          <div class="card mt-16" style="height:120px;"></div>
          <div class="card mt-16" style="height:120px;"></div>
        </div>
        <div class="fomo-overlay">
          <div class="lock">🔒</div>
          <h3>Réservé au plan Accompagnement</h3>
          <p class="text-secondary text-sm">${message}</p>
          <a href="/app/sales-accompagnement.html" class="btn btn-primary">Débloquer l'Accompagnement</a>
        </div>
      </div>`;
  },

  getLessonKind(lesson) {
    if (lesson.content) return "text";
    if (lesson.video_url) return "video";
    if (lesson.pdf_url) return "pdf";
    return "video";
  },

  async getClassroomProgress(profile) {
    const sb = window.sb;
    const { data: modules } = await sb
      .from("modules")
      .select("*, lessons(*), classroom_submodules(*, lessons(*))")
      .order("order_index");
    const { data: progressRows } = await sb.from("lesson_progress").select("lesson_id, completed").eq("user_id", profile.id);
    const doneSet = new Set((progressRows || []).filter((p) => p.completed).map((p) => p.lesson_id));
    const allowedVisibility = profile.plan === "accompagnement" ? ["free", "paid", "premium"] : profile.plan === "formation" ? ["free", "paid"] : ["free"];

    const flatLessons = [];
    (modules || [])
      .sort((a, b) => a.order_index - b.order_index)
      .forEach((mod) => {
        (mod.lessons || []).sort((a, b) => a.order_index - b.order_index).forEach((l) => flatLessons.push(l));
        (mod.classroom_submodules || [])
          .sort((a, b) => a.order_index - b.order_index)
          .forEach((sub) => {
            (sub.lessons || []).sort((a, b) => a.order_index - b.order_index).forEach((l) => flatLessons.push(l));
          });
      });

    const accessible = flatLessons.filter((l) => allowedVisibility.includes(l.visibility));
    const completed = accessible.filter((l) => doneSet.has(l.id));
    const percent = accessible.length ? Math.round((completed.length / accessible.length) * 100) : 0;
    const nextLesson = accessible.find((l) => !doneSet.has(l.id));

    return {
      percent,
      completedCount: completed.length,
      totalCount: accessible.length,
      nextLessonId: nextLesson ? nextLesson.id : null
    };
  },

  // ---------------------------------------------------------
  // ACCUEIL (MODIFIÉ : bouton installer ajouté)
  // ---------------------------------------------------------
  async initHomePage(profile) {
    this.renderHeader(profile, "Accueil");
    this.renderBottomNav("accueil");
    const root = document.getElementById("page-root");
    root.innerHTML = `<div class="text-center" style="padding-top:40px;"><span class="loader loader-dark"></span></div>`;

    const sb = window.sb;
    const firstName = (profile.full_name || "").split(" ")[0] || "";

    const { data: settingsRows } = await sb
      .from("settings")
      .select("*")
      .in("key", [
        "homepage_welcome_enabled", "homepage_welcome_text",
        "homepage_announcement_enabled", "homepage_announcement_text",
        "homepage_motivation_enabled", "homepage_motivation_text",
        "homepage_button_enabled", "homepage_button_label", "homepage_button_url"
      ]);
    const settings = {};
    (settingsRows || []).forEach((r) => {
      let v = r.value;
      if (typeof v === "string") { try { v = JSON.parse(v); } catch (e) {} }
      settings[r.key] = v;
    });

    const progress = await this.getClassroomProgress(profile);

    // 📲 BOUTON INSTALLER L'APPLICATION (MODIFICATION)
    const showInstallBtn = !window.isAppInstalled || !window.isAppInstalled();
    const installButtonHtml = showInstallBtn ? `
      <div class="card mt-16" style="background:linear-gradient(135deg,#F5A623,#E67E22);color:#fff;text-align:center;">
        <div style="font-size:32px;">📲</div>
        <strong style="font-size:16px;">Installe Griot IA sur ton téléphone</strong>
        <p style="font-size:13px;margin-top:8px;opacity:.9;">Accès rapide + notifications en temps réel</p>
        <button id="manual-install-btn" class="btn btn-dark mt-16" style="font-weight:700;">📲 Installer l'application</button>
      </div>` : "";

    let subscriptionBannerHtml = "";
    if (profile.plan === "accompagnement" && profile.plan_expires_at) {
      const expiresDate = new Date(profile.plan_expires_at);
      const daysLeft = Math.ceil((expiresDate - new Date()) / (1000 * 60 * 60 * 24));
      const formattedDate = expiresDate.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
      if (daysLeft <= 7) {
        subscriptionBannerHtml = `
          <div class="card mt-16" style="border-left:4px solid var(--accent);background:#FFF8EC;">
            <strong>⚠️ Ton abonnement expire ${daysLeft <= 0 ? "aujourd'hui" : `dans ${daysLeft} jour${daysLeft > 1 ? "s" : ""}`} (${formattedDate})</strong>
            <a href="/app/sales-accompagnement.html" class="btn btn-primary btn-block mt-16">Renouveler maintenant — 15.000 F</a>
          </div>`;
      } else {
        subscriptionBannerHtml = `
          <p class="text-secondary text-sm mt-8">✅ Ton abonnement Accompagnement est actif jusqu'au ${formattedDate}.</p>`;
      }
    }

    let endOfPlanCardHtml = "";
    if (progress.totalCount > 0 && progress.percent === 100) {
      if (profile.plan === "free") {
        endOfPlanCardHtml = `
          <div class="card mt-16 text-center" style="background:#F0FFF4;border:2px solid var(--success);">
            <div style="font-size:32px;">🎉</div>
            <strong>Tu as terminé les leçons gratuites !</strong>
            <p class="text-secondary text-sm mt-8">Prêt à aller plus loin ?</p>
            <a href="/app/sales-formation.html" class="btn btn-primary mt-8">Débloquer la Formation</a>
          </div>`;
      } else if (profile.plan === "formation") {
        endOfPlanCardHtml = `
          <div class="card mt-16 text-center" style="background:#FFF8EC;border:2px solid var(--accent);">
            <div style="font-size:32px;">🎉</div>
            <strong>Tu as terminé la Formation !</strong>
            <p class="text-secondary text-sm mt-8">Envie d'être accompagné ? Lives, communauté, suivi</p>
            <a href="/app/sales-accompagnement.html" class="btn btn-primary mt-8">Passer à l'Accompagnement</a>
          </div>`;
      } else {
        endOfPlanCardHtml = `
          <div class="card mt-16 text-center" style="background:#F0FFF4;border:2px solid var(--success);">
            <div style="font-size:32px;">🎥</div>
            <strong>Rendez-vous au prochain live !</strong>
            <p class="text-secondary text-sm mt-8">Tu as terminé toutes les leçons accessibles.</p>
          </div>`;
      }
    }

    root.innerHTML = `
      <h2>Salut ${window.GriotUtils.escapeHtml(firstName)} 👋</h2>
      ${installButtonHtml}
      ${subscriptionBannerHtml}

      ${settings.homepage_welcome_enabled !== false ? `<p class="text-secondary mt-8">${window.GriotUtils.escapeHtml(settings.homepage_welcome_text || "")}</p>` : ""}

      <div class="card mt-16">
        <div class="flex justify-between items-center">
          <strong>Ta progression</strong><span>${progress.percent}%</span>
        </div>
        <div style="height:8px;background:#eee;border-radius:10px;margin-top:10px;overflow:hidden;">
          <div style="height:100%;width:${progress.percent}%;background:var(--accent);"></div>
        </div>
        ${
          progress.nextLessonId
            ? `<a href="/app/lesson.html?id=${progress.nextLessonId}" class="btn btn-primary btn-block mt-16">▶️ ${progress.percent === 0 ? "Commencer" : "Continuer"} la formation</a>`
            : endOfPlanCardHtml
        }
      </div>

      ${
        settings.homepage_announcement_enabled && settings.homepage_announcement_text
          ? `<div class="card mt-16" style="border-left:4px solid var(--accent);">
              <strong>📣 Annonce du jour</strong>
              <p class="mt-8 text-sm">${window.GriotUtils.escapeHtml(settings.homepage_announcement_text)}</p>
            </div>`
          : ""
      }

      ${
        settings.homepage_motivation_enabled && settings.homepage_motivation_text
          ? `<div class="card mt-16 text-center" style="background:var(--primary);color:#fff;">
              <p style="font-style:italic;">"${window.GriotUtils.escapeHtml(settings.homepage_motivation_text)}"</p>
            </div>`
          : ""
      }

      ${
        settings.homepage_button_enabled && settings.homepage_button_url
          ? `<a href="${settings.homepage_button_url}" target="_blank" rel="noopener" class="btn btn-primary btn-block mt-16">${window.GriotUtils.escapeHtml(settings.homepage_button_label || "En savoir plus")}</a>`
          : ""
      }

      <h3 class="mt-24" style="font-size:16px;">Accès rapides</h3>
      <div class="flex gap-12 mt-16" style="flex-wrap:wrap;">
        <a href="/app/classroom.html" class="btn btn-outline btn-sm">🎓 Classroom</a>
        <a href="/app/community.html" class="btn btn-outline btn-sm">🏘️ Communauté</a>
        <a href="/app/calendar.html" class="btn btn-outline btn-sm">📅 Live</a>
      </div>
    `;

    // 📲 EVENT LISTENER BOUTON INSTALLER (MODIFICATION)
    const installBtn = document.getElementById("manual-install-btn");
    if (installBtn && window.manualInstallApp) {
      installBtn.addEventListener("click", () => window.manualInstallApp());
    }

    window.GriotAI.mountWidget(profile);
  },

  async initResourcesPage(profile) {
    this.renderHeader(profile, "Ressources");
    this.renderBottomNav("ressources");
    const root = document.getElementById("page-root");
    root.innerHTML = `
      <h2>Ressources</h2>
      <input type="text" id="res-search" class="form-control mt-16" placeholder="Rechercher une ressource..." />
      <div id="res-categories" class="carousel" style="padding-left:0;"></div>
      <div id="res-list" class="mt-16"></div>
    `;

    const sb = window.sb;
    const { data: resources } = await sb.from("resources").select("*").order("order_index", { ascending: true });

    const PLAN_LEVEL = { free: 0, formation: 1, accompagnement: 2 };
    const myLevel = PLAN_LEVEL[profile.plan] ?? 0;
    const isLocked = (r) => (PLAN_LEVEL[r.plan_required] ?? 0) > myLevel;

    const categories = ["Tous", ...new Set((resources || []).map((r) => (r.category || "").trim()).filter(Boolean))];
    const catEl = document.getElementById("res-categories");
    catEl.style.display = "flex";
    catEl.style.gap = "8px";
    catEl.style.overflowX = "auto";
    let activeCategory = "Tous";

    const listEl = document.getElementById("res-list");
    const render = () => {
      const search = document.getElementById("res-search").value.toLowerCase();
      const filtered = (resources || []).filter((r) => {
        const matchCat = activeCategory === "Tous" || r.category === activeCategory;
        const matchSearch = r.title.toLowerCase().includes(search);
        return matchCat && matchSearch;
      });
      if (!filtered.length) {
        listEl.innerHTML = `<p class="text-secondary text-center mt-24">Aucune ressource trouvée.</p>`;
        return;
      }
      listEl.innerHTML = filtered
        .map((r) => {
          const locked = isLocked(r);
          const badgeLabel = (r.category || "").trim() || (r.type === "link" ? "Lien" : "PDF");
          const hasGuide = !!(r.guide_content && r.guide_content.trim());
          return `
        <div class="card mt-16 ${locked ? "resource-card-locked" : ""}">
          <div style="font-weight:700;">${window.GriotUtils.escapeHtml(r.title)}</div>
          <p class="text-secondary text-sm mt-8">${window.GriotUtils.escapeHtml(r.description || "")}</p>
          <div class="flex justify-between items-center mt-16">
            <span class="badge badge-dark">${window.GriotUtils.escapeHtml(badgeLabel)}</span>
          </div>
          ${
            locked
              ? `<div class="resource-link-row mt-8">
                  <span class="resource-link-icon">🔒</span>
                  <span class="resource-link-label">Réservé au plan ${r.plan_required === "accompagnement" ? "Accompagnement" : "Formation"}</span>
                </div>
                <a href="${r.plan_required === "accompagnement" ? "/app/sales-accompagnement.html" : "/app/sales-formation.html"}" class="btn btn-primary btn-sm btn-block mt-8">Passer au plan supérieur</a>`
              : `<a href="${hasGuide ? `/app/resource-detail.html?id=${r.id}` : r.file_url}" ${hasGuide ? "" : `target="_blank" rel="noopener"`} class="resource-link-row mt-8" data-download="${r.id}">
                  <span class="resource-link-icon">${r.type === "link" ? "🔗" : "📄"}</span>
                  <span class="resource-link-label">${hasGuide ? "Voir le guide" : r.type === "link" ? "Ouvrir le lien" : "Télécharger le fichier"}</span>
                </a>`
          }
        </div>`;
        })
        .join("");

      listEl.querySelectorAll("[data-download]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-download");
          const resource = resources.find((r) => r.id === id);
          sb.from("resources").update({ download_count: (resource?.download_count || 0) + 1 }).eq("id", id);
        });
      });
    };

    catEl.innerHTML = categories
      .map((c) => `<button class="btn ${c === "Tous" ? "btn-primary" : "btn-outline"} btn-sm" data-cat="${window.GriotUtils.escapeHtml(c)}" style="flex:0 0 auto;">${window.GriotUtils.escapeHtml(c)}</button>`)
      .join("");
    catEl.querySelectorAll("[data-cat]").forEach((btn) => {
      btn.addEventListener("click", () => {
        activeCategory = btn.getAttribute("data-cat");
        catEl.querySelectorAll("button").forEach((b) => {
          b.classList.remove("btn-primary");
          b.classList.add("btn-outline");
        });
        btn.classList.remove("btn-outline");
        btn.classList.add("btn-primary");
        render();
      });
    });
    document.getElementById("res-search").addEventListener("input", window.GriotUtils.debounce(render, 250));
    render();

    window.GriotAI.mountWidget(profile);
  },

  async initClassroomPage(profile) {
    this.renderHeader(profile, "Classroom");
    this.renderBottomNav("classroom");
    const root = document.getElementById("page-root");

    const sb = window.sb;
    const { data: modules } = await sb
      .from("modules")
      .select("*, lessons(*), classroom_submodules(*, lessons(*))")
      .order("order_index");
    const { data: progressRows } = await sb.from("lesson_progress").select("lesson_id, completed").eq("user_id", profile.id);
    const doneSet = new Set((progressRows || []).filter((p) => p.completed).map((p) => p.lesson_id));
    const allowedVisibility = profile.plan === "accompagnement" ? ["free", "paid", "premium"] : profile.plan === "formation" ? ["free", "paid"] : ["free"];

    let referralBadgeHtml = "";
    if (profile.plan === "formation" && profile.plan_expires_at) {
      const { data: latestSub } = await sb
        .from("subscriptions")
        .select("*")
        .eq("user_id", profile.id)
        .eq("billing", "referral")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (latestSub && latestSub.expires_at) {
        const daysLeft = Math.max(0, Math.ceil((new Date(latestSub.expires_at) - new Date()) / (1000 * 60 * 60 * 24)));
        if (daysLeft > 0) {
          referralBadgeHtml = `<span class="badge badge-green mt-8" style="display:inline-block;">🎁 Accès gratuit : ${daysLeft} jour${daysLeft > 1 ? "s" : ""} restant${daysLeft > 1 ? "s" : ""}</span>`;
        }
      }
    }

    const KIND_ICON = { video: "▶️", pdf: "📄", text: "📝" };
    const KIND_LABEL = { video: "Vidéo", pdf: "PDF", text: "Texte" };
    const getLessonKind = this.getLessonKind;

    function allLessonsOfModule(mod) {
      const direct = (mod.lessons || []).sort((a, b) => a.order_index - b.order_index);
      const subLessons = (mod.classroom_submodules || [])
        .sort((a, b) => a.order_index - b.order_index)
        .flatMap((sub) => (sub.lessons || []).sort((a, b) => a.order_index - b.order_index));
      return [...direct, ...subLessons];
    }

    function renderModuleGrid() {
      window.GriotAI.mountWidget(profile);
      root.innerHTML = `<h2>Classroom</h2>${referralBadgeHtml}<div class="module-grid mt-16" id="module-grid"></div>`;
      const grid = document.getElementById("module-grid");

      if (!modules || !modules.length) {
        grid.innerHTML = `<p class="text-secondary">Aucun module disponible pour le moment.</p>`;
        return;
      }

      grid.innerHTML = modules
        .map((mod) => {
          const allLessons = allLessonsOfModule(mod);
          const accessible = allLessons.filter((l) => allowedVisibility.includes(l.visibility));
          const completed = accessible.filter((l) => doneSet.has(l.id));
          const pct = accessible.length ? Math.round((completed.length / accessible.length) * 100) : 0;
          const coverStyle = mod.cover_url ? `style="background-image:url('${mod.cover_url}');"` : "";
          return `
          <div class="module-card" data-module="${mod.id}">
            <div class="cover" ${coverStyle}>${mod.cover_url ? "" : "🎓"}</div>
            <div class="body">
              <div class="title">${window.GriotUtils.escapeHtml(mod.title)}</div>
              <div class="desc">${window.GriotUtils.escapeHtml(mod.description || "")}</div>
              <div class="progress-row">
                <div class="progress-bar-track"><div class="progress-bar-fill" style="width:${pct}%;"></div></div>
                <span class="progress-pct">${pct}%</span>
              </div>
              <div class="text-secondary text-sm mt-8">${allLessons.length} leçon${allLessons.length > 1 ? "s" : ""}</div>
            </div>
          </div>`;
        })
        .join("");

      grid.querySelectorAll("[data-module]").forEach((card) => {
        card.addEventListener("click", () => renderModuleContent(card.getAttribute("data-module")));
      });
    }

    function lessonRowHtml(l) {
      const locked = !allowedVisibility.includes(l.visibility);
      const done = doneSet.has(l.id);
      const kind = getLessonKind(l);
      return `
        <div class="lesson-row ${locked ? "locked" : ""} ${done ? "done" : ""}" data-lesson="${l.id}" data-locked="${locked}">
          <span class="icon">${done ? "✅" : locked ? "🔒" : KIND_ICON[kind]}</span>
          <div class="info">
            <div class="title">${window.GriotUtils.escapeHtml(l.title)}</div>
            <div class="meta">
              <span class="lesson-type-badge ${kind}">${KIND_LABEL[kind]}</span>
              ${l.duration_minutes ? ` · ${l.duration_minutes}min` : ""}
            </div>
          </div>
        </div>`;
    }

    function wireLessonRows(container) {
      container.querySelectorAll("[data-lesson]").forEach((row) => {
        row.addEventListener("click", () => {
          window.location.href = `/app/lesson.html?id=${row.getAttribute("data-lesson")}`;
        });
      });
    }

    function renderModuleContent(moduleId) {
      const mod = modules.find((m) => m.id === moduleId);
      if (!mod) { renderModuleGrid(); return; }

      const lessonItems = (mod.lessons || []).map((l) => ({ type: "lesson", order_index: l.order_index || 0, data: l }));
      const subItems = (mod.classroom_submodules || []).map((s) => ({ type: "submodule", order_index: s.order_index || 0, data: s }));
      const children = [...lessonItems, ...subItems].sort((a, b) => a.order_index - b.order_index || (a.type === b.type ? 0 : a.type === "submodule" ? -1 : 1));

      root.innerHTML = `
        <button id="back-to-modules" class="btn btn-outline btn-sm">← Tous les modules</button>
        <h2 class="mt-16">${window.GriotUtils.escapeHtml(mod.title)}</h2>
        <p class="text-secondary text-sm">${window.GriotUtils.escapeHtml(mod.description || "")}</p>
        <div class="mt-16" id="module-children-list"></div>
      `;
      document.getElementById("back-to-modules").addEventListener("click", renderModuleGrid);

      const list = document.getElementById("module-children-list");
      if (!children.length) {
        list.innerHTML = `<p class="text-secondary">Aucune leçon dans ce module pour le moment.</p>`;
      } else {
        list.innerHTML = children
          .map((child) => {
            if (child.type === "lesson") return lessonRowHtml(child.data);
            const sub = child.data;
            const subLessons = (sub.lessons || []).sort((a, b) => a.order_index - b.order_index);
            const accessible = subLessons.filter((l) => allowedVisibility.includes(l.visibility));
            const completed = accessible.filter((l) => doneSet.has(l.id));
            const pct = accessible.length ? Math.round((completed.length / accessible.length) * 100) : 0;
            return `
            <div class="lesson-row" data-submodule="${sub.id}">
              <span class="icon">📁</span>
              <div class="info">
                <div class="title">${window.GriotUtils.escapeHtml(sub.title)}</div>
                <div class="meta">${subLessons.length} leçon${subLessons.length > 1 ? "s" : ""} · ${pct}% terminé</div>
              </div>
            </div>`;
          })
          .join("");

        wireLessonRows(list);
        list.querySelectorAll("[data-submodule]").forEach((row) => {
          row.addEventListener("click", () => renderSubmoduleContent(moduleId, row.getAttribute("data-submodule")));
        });
      }

      window.GriotAI.mountWidget(profile);
    }

    function renderSubmoduleContent(moduleId, submoduleId) {
      const mod = modules.find((m) => m.id === moduleId);
      const sub = (mod?.classroom_submodules || []).find((s) => s.id === submoduleId);
      if (!mod || !sub) { renderModuleGrid(); return; }
      const lessons = (sub.lessons || []).sort((a, b) => a.order_index - b.order_index);

      root.innerHTML = `
        <button id="back-to-module" class="btn btn-outline btn-sm">← ${window.GriotUtils.escapeHtml(mod.title)}</button>
        <h2 class="mt-16">📁 ${window.GriotUtils.escapeHtml(sub.title)}</h2>
        <div class="mt-16" id="sub-lesson-list"></div>
      `;
      document.getElementById("back-to-module").addEventListener("click", () => renderModuleContent(moduleId));

      const list = document.getElementById("sub-lesson-list");
      list.innerHTML = lessons.length ? lessons.map(lessonRowHtml).join("") : `<p class="text-secondary">Aucune leçon dans ce sous-module pour le moment.</p>`;
      wireLessonRows(list);

      window.GriotAI.mountWidget(profile);
    }

    renderModuleGrid();
  },

  async initCommunityPage(profile) {
    await window.GriotCommunity.mount(profile);
  },

  async initCalendarPage(profile) {
    this.renderHeader(profile, "Calendrier");
    this.renderBottomNav("calendar");
    const root = document.getElementById("page-root");
    root.innerHTML = `<h2>Prochains lives</h2>`;

    if (profile.plan !== "accompagnement") {
      const wrap = document.createElement("div");
      wrap.className = "mt-16";
      root.appendChild(wrap);
      this.renderFomoLock(wrap, "Assiste aux lives coaching et accède aux replays exclusifs.");
      window.GriotAI.mountWidget(profile);
      return;
    }

    const sb = window.sb;
    const { data: events } = await sb.from("events").select("*").order("starts_at", { ascending: true });
    const { data: rsvps } = await sb.from("event_rsvps").select("event_id").eq("user_id", profile.id);
    const rsvpSet = new Set((rsvps || []).map((r) => r.event_id));

    const list = document.createElement("div");
    list.className = "mt-16";
    list.innerHTML = (events || [])
      .map((e) => {
        const isPast = new Date(e.starts_at) < new Date();
        return `
        <div class="card mt-16">
          <strong>${window.GriotUtils.escapeHtml(e.title)}</strong>
          <p class="text-secondary text-sm mt-8">${new Date(e.starts_at).toLocaleString("fr-FR")}</p>
          <p class="text-sm mt-8">${window.GriotUtils.escapeHtml(e.description || "")}</p>
          ${
            isPast
              ? e.replay_url
                ? `<a href="${e.replay_url}" target="_blank" class="btn btn-outline btn-sm mt-8">Voir le replay</a>`
                : `<span class="text-secondary text-sm">Replay bientôt disponible</span>`
              : `<button class="btn ${rsvpSet.has(e.id) ? "btn-success" : "btn-primary"} btn-sm mt-8" data-rsvp="${e.id}">${rsvpSet.has(e.id) ? "✅ Inscrit" : "S'inscrire"}</button>`
          }
        </div>`;
      })
      .join("");
    root.appendChild(list);

    list.querySelectorAll("[data-rsvp]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const eventId = btn.getAttribute("data-rsvp");
        await sb.from("event_rsvps").upsert({ event_id: eventId, user_id: profile.id });
        btn.textContent = "✅ Inscrit";
        btn.classList.remove("btn-primary");
        btn.classList.add("btn-success");
        window.GriotUtils.showToast("Inscription confirmée !", "success");
      });
    });

    window.GriotAI.mountWidget(profile);
  },

  async initMembersPage(profile) {
    this.renderHeader(profile, "Membres");
    this.renderBottomNav("members");
    const root = document.getElementById("page-root");
    root.innerHTML = `<h2>Annuaire des membres</h2>`;

    if (profile.plan !== "accompagnement") {
      const wrap = document.createElement("div");
      wrap.className = "mt-16";
      root.appendChild(wrap);
      this.renderFomoLock(wrap, "Découvre et échange avec les autres membres de l'Accompagnement.");
      window.GriotAI.mountWidget(profile);
      return;
    }

    const sb = window.sb;
    const { data: members } = await sb.from("profiles").select("id, full_name, avatar_url, points").eq("plan", "accompagnement").order("points", { ascending: false });
    const list = document.createElement("div");
    list.className = "mt-16";
    list.innerHTML = (members || [])
      .map(
        (m) => `
      <div class="card mt-16 flex items-center justify-between">
        <div>
          <strong>${window.GriotUtils.escapeHtml(m.full_name || "Membre")}</strong>
          <div class="text-secondary text-sm">${m.points} points</div>
        </div>
        <button class="btn btn-outline btn-sm" data-write="${m.id}">Écrire</button>
      </div>`
      )
      .join("");
    root.appendChild(list);

    list.querySelectorAll("[data-write]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const targetId = btn.getAttribute("data-write");
        if (targetId === profile.id) return;
        if (!window.GriotMessaging.canMessageStudents(profile)) {
          window.GriotUtils.showToast(`Il te faut ${window.GriotMessaging.MP_UNLOCK_THRESHOLD} points pour écrire aux membres (tu en as ${profile.points}).`, "error", 5000);
          return;
        }
        const conv = await window.GriotMessaging.getOrCreateConversation(profile.id, targetId);
        window.location.href = `/app/conversation.html?id=${conv.id}`;
      });
    });

    window.GriotAI.mountWidget(profile);
  },

  async initLeaderboardPage(profile) {
    this.renderHeader(profile, "Classement");
    this.renderBottomNav("leaderboards");
    const root = document.getElementById("page-root");

    const leaderboard = await window.GriotGamification.getLeaderboard();
    const rank = await window.GriotGamification.getUserRank(profile.id, profile.points);

    root.innerHTML = `
      <h2>🏆 Classement</h2>
      <div class="card mt-16 text-center">
        <div class="text-secondary text-sm">Ta position</div>
        <div style="font-size:28px;font-weight:800;color:var(--accent);">#${rank}</div>
        <div class="text-sm">${profile.points} points</div>
      </div>
      <div class="card mt-16">
        <strong>Barème des points</strong>
        <ul class="mt-8 text-sm text-secondary">
          <li>Leçon terminée : +10 pts</li>
          <li>Commentaire / like : +5 pts</li>
          <li>Post communauté : +20 pts</li>
          <li>Présence live : +30 pts</li>
          <li>Vente validée : +100 pts</li>
        </ul>
      </div>
      <div class="mt-16" id="lb-list"></div>
    `;
    document.getElementById("lb-list").innerHTML = leaderboard
      .map(
        (u, i) => `
      <div class="card mt-16 flex items-center justify-between ${u.id === profile.id ? "" : ""}">
        <div class="flex items-center gap-12">
          <strong>#${i + 1}</strong>
          <span>${window.GriotUtils.escapeHtml(u.full_name || "Membre")}</span>
        </div>
        <span class="badge badge-gold">${u.points} pts</span>
      </div>`
      )
      .join("");

    window.GriotAI.mountWidget(profile);
  },

  async initAboutPage(profile) {
    this.renderHeader(profile, "À propos");
    this.renderBottomNav("profil");
    const root = document.getElementById("page-root");

    const sb = window.sb;
    const { data: settingsRows } = await sb.from("settings").select("*");
    const settings = {};
    (settingsRows || []).forEach((s) => (settings[s.key] = typeof s.value === "string" ? JSON.parse(s.value) : s.value));

    root.innerHTML = `
      <h2>À propos de Griot IA</h2>
      <div class="card mt-16">
        <p>J'ai vu trop de débutants africains se faire arnaquer par de fausses formations en ligne. Des promesses vides, des groupes WhatsApp abandonnés, des coachs qui disparaissent après le paiement.</p>
        <p class="mt-8">J'ai créé Griot IA parce qu'en Afrique, le griot a toujours été celui qui transmet le vrai savoir, gratuitement, avec patience. Griot IA, c'est ça : un endroit honnête où tu apprends vraiment, avec une communauté qui te soutient, et un coach IA disponible 24h/24.</p>
        <p class="mt-8" style="font-weight:700;">Pas de fausses promesses. Juste des résultats.</p>
      </div>
      <div class="card mt-16">
        <strong>Règles de la communauté</strong>
        <p class="text-secondary text-sm mt-8">${window.GriotUtils.escapeHtml(settings.community_rules || "")}</p>
      </div>
      <div class="card mt-16">
        <strong>Rejoins nos canaux officiels</strong>
        <div class="flex gap-12 mt-16">
          <a href="/go/whatsapp.html" class="btn btn-success btn-sm">WhatsApp</a>
          <a href="/go/telegram.html" class="btn btn-outline btn-sm">Telegram</a>
        </div>
      </div>
      <div class="card mt-16">
        <strong>Contact</strong>
        <p class="text-secondary text-sm mt-8">${window.GriotUtils.escapeHtml(settings.contact_email || "")}</p>
      </div>
    `;
    window.GriotAI.mountWidget(profile);
  },

  async initProfilePage(profile) {
    this.renderHeader(profile, "Profil");
    this.renderBottomNav("profil");
    const root = document.getElementById("page-root");

    const progress = await window.GriotReferral.getProgress(profile.id);
    const link = window.GriotReferral.getInviteLink(profile.referral_code);

    let referralsListHtml = "";
    if (progress.list && progress.list.length > 0) {
      referralsListHtml = `
        <div class="mt-16" style="max-height:220px;overflow-y:auto;">
          <strong class="text-sm">Mes invitations (${progress.list.length})</strong>
          ${progress.list
            .map((r) => {
              const name = r.referred?.full_name || r.referred?.email || "Inconnu";
              const statusColor = r.status === "verified" ? "var(--success)" : "#E67E22";
              const statusLabel = r.status === "verified" ? "✅ Validé" : "⏳ En attente";
              const date = new Date(r.created_at).toLocaleDateString("fr-FR");
              return `
              <div class="card mt-8" style="padding:10px;display:flex;justify-content:space-between;align-items:center;">
                <div>
                  <div style="font-weight:600;font-size:13px;">${window.GriotUtils.escapeHtml(name)}</div>
                  <div class="text-secondary text-sm">${date}</div>
                </div>
                <span class="badge" style="background:${statusColor};color:#fff;font-size:11px;">${statusLabel}</span>
              </div>`;
            })
            .join("")}
        </div>`;
    }

    const avatarHtml = profile.avatar_url
      ? `<img src="${profile.avatar_url}" style="width:64px;height:64px;border-radius:50%;object-fit:cover;margin:0 auto;display:block;" />`
      : `<div style="width:64px;height:64px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:800;margin:0 auto;">${(profile.full_name || profile.email || "?")[0].toUpperCase()}</div>`;

    root.innerHTML = `
      <h2>Mon profil</h2>
      <div class="card mt-16 text-center">
        ${avatarHtml}
        <div style="font-weight:700;margin-top:10px;">${window.GriotUtils.escapeHtml(profile.full_name || profile.email)}</div>
        <span class="badge badge-gold mt-8">${profile.plan}</span>
        <div class="text-secondary text-sm mt-8">${profile.points} points</div>
        <button id="toggle-edit-btn" class="btn btn-outline btn-sm mt-16">✏️ Modifier mon profil</button>
      </div>

      <div class="card mt-16" id="edit-profile-card" style="display:none;">
        <strong>✏️ Modifier mon profil</strong>
        <div class="form-group mt-8">
          <label>Nom complet</label>
          <input id="edit-fullname" class="form-control" value="${window.GriotUtils.escapeHtml(profile.full_name || "")}" placeholder="Ton nom" />
        </div>
        <div class="form-group">
          <label>Photo de profil</label>
          <div id="avatar-uploader"></div>
          <img id="avatar-preview" src="${profile.avatar_url || ""}" style="${profile.avatar_url ? "" : "display:none;"}width:56px;height:56px;border-radius:50%;object-fit:cover;margin-top:8px;" />
        </div>
        <button id="save-profile-btn" class="btn btn-primary btn-block">Enregistrer</button>
      </div>

      <div class="card mt-16">
        <strong>🎁 Parrainage — ${progress.verified}/5 amis vérifiés</strong>
        ${progress.pending > 0 ? `<p class="text-sm mt-8" style="color:#E67E22;">⏳ ${progress.pending} ami${progress.pending > 1 ? "s" : ""} inscrit${progress.pending > 1 ? "s" : ""} en attente de validation</p>` : ""}
        <div style="height:8px;background:#eee;border-radius:10px;margin-top:10px;overflow:hidden;">
          <div style="height:100%;width:${Math.min((progress.verified / 5) * 100, 100)}%;background:var(--success);"></div>
        </div>
        <p class="text-secondary text-sm mt-8">Invite 5 amis vérifiés pour débloquer la Formation gratuitement pendant 30 jours.</p>
        <div class="form-control mt-16" style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;word-break:break-all;">${link}</span>
        </div>
        <div class="flex gap-8 mt-8" style="flex-wrap:wrap;">
          <button id="copy-link-btn" class="btn btn-outline btn-sm">Copier le lien</button>
          <button id="share-wa-btn" class="btn btn-success btn-sm">WhatsApp</button>
          <button id="share-tg-btn" class="btn btn-dark btn-sm">Telegram</button>
        </div>
        ${referralsListHtml}
      </div>

      <div class="card mt-16">
        <strong>Canaux officiels</strong>
        <div class="flex gap-12 mt-16">
          <a href="/go/whatsapp.html" class="btn btn-success btn-sm">WhatsApp</a>
          <a href="/go/telegram.html" class="btn btn-outline btn-sm">Telegram</a>
        </div>
      </div>

      <button id="logout-btn" class="btn btn-danger btn-block mt-24">Se déconnecter</button>
    `;

    document.getElementById("toggle-edit-btn").addEventListener("click", () => {
      const editCard = document.getElementById("edit-profile-card");
      const isOpen = editCard.style.display !== "none";
      editCard.style.display = isOpen ? "none" : "block";
      document.getElementById("toggle-edit-btn").textContent = isOpen ? "✏️ Modifier mon profil" : "Fermer";
      if (!isOpen) editCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
    });

    let avatarUrl = profile.avatar_url || "";
    window.GriotUpload.mountUploader(document.getElementById("avatar-uploader"), {
      bucket: "avatars",
      folder: "members",
      accept: "image/*",
      isImage: true,
      onUploaded: (url) => {
        avatarUrl = url;
        const prev = document.getElementById("avatar-preview");
        prev.src = url;
        prev.style.display = "block";
      }
    });

    document.getElementById("save-profile-btn").addEventListener("click", async () => {
      const fullName = document.getElementById("edit-fullname").value.trim();
      if (!fullName) {
        window.GriotUtils.showToast("Ton nom ne peut pas être vide.", "error");
        return;
      }
      const { error } = await window.sb
        .from("profiles")
        .update({ full_name: fullName, avatar_url: avatarUrl || null })
        .eq("id", profile.id);
      if (error) {
        window.GriotUtils.showToast("Erreur lors de l'enregistrement.", "error");
        return;
      }
      window.GriotUtils.showToast("Profil mis à jour ! ✅", "success");
      setTimeout(() => window.location.reload(), 800);
    });

    document.getElementById("copy-link-btn").addEventListener("click", () => window.GriotUtils.copyToClipboard(link));
    document.getElementById("share-wa-btn").addEventListener("click", () => window.GriotUtils.shareWhatsApp(window.GriotReferral.getShareMessage(), link));
    document.getElementById("share-tg-btn").addEventListener("click", () => window.GriotUtils.shareTelegram(window.GriotReferral.getShareMessage(), link));
    document.getElementById("logout-btn").addEventListener("click", () => window.GriotAuth.logout());

    window.GriotAI.mountWidget(profile);
  }
};

window.GriotApp = GriotApp;