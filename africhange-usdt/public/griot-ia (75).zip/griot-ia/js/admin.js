/* ============================================================
   GRIOT IA — Logique admin partagée (admin.js)
   ============================================================ */

const GriotAdmin = {
  NAV_ITEMS: [
    { key: "index", label: "Dashboard", icon: "📊", href: "/admin/index.html" },
    { key: "ressources", label: "Ressources", icon: "📚", href: "/admin/ressources.html" },
    { key: "classroom", label: "Classroom", icon: "🎓", href: "/admin/classroom.html" },
    { key: "community", label: "Communauté", icon: "🏘️", href: "/admin/community.html" },
    { key: "calendar", label: "Calendrier", icon: "📅", href: "/admin/calendar.html" },
    { key: "checklist", label: "Checklist", icon: "✅", href: "/admin/checklist.html" },
    { key: "members", label: "Membres", icon: "👥", href: "/admin/members.html" },
    { key: "messages", label: "Messages", icon: "💬", href: "/admin/messages.html" },
    { key: "inbox", label: "Preuves de vente", icon: "📥", href: "/admin/inbox.html" },
    { key: "payments", label: "Paiements", icon: "💳", href: "/admin/payments.html" },
    { key: "subscriptions", label: "Abonnements", icon: "🔄", href: "/admin/subscriptions.html" },
    { key: "referrals", label: "Parrainages", icon: "🎁", href: "/admin/referrals.html" },
    { key: "settings", label: "Réglages", icon: "⚙️", href: "/admin/settings.html" }
  ],

  // Sidebar réduite pour les modérateurs : uniquement la modération communauté.
  MODERATOR_NAV_ITEMS: [
    { key: "community", label: "Communauté", icon: "🏘️", href: "/admin/community.html" }
  ],

  /**
   * Construit le layout complet sidebar + zone de contenu, retourne le conteneur #admin-page-root.
   * `profile` est optionnel : s'il est fourni et que profile.role === "moderator", la sidebar
   * est réduite aux pages de modération. Rétro-compatible avec les appels à 2 arguments.
   */
  renderLayout(activeKey, title, profile) {
    document.title = `${title} — Admin Griot IA`;
    const navItems = profile && profile.role === "moderator" ? this.MODERATOR_NAV_ITEMS : this.NAV_ITEMS;
    const layout = document.createElement("div");
    layout.className = "admin-layout";
    layout.innerHTML = `
      <aside class="admin-sidebar">
        <div class="logo">Griot<span class="dot">IA</span> 💬</div>
        <nav class="admin-nav">
          ${navItems.map(
            (item) => `<a href="${item.href}" class="${item.key === activeKey ? "active" : ""}">${item.icon} ${item.label}</a>`
          ).join("")}
          <a href="#" id="admin-logout">🚪 Déconnexion</a>
        </nav>
      </aside>
      <main class="admin-content">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
          <h1 style="font-size:22px;margin:0;">${title}</h1>
          <div id="admin-theme-slot"></div>
        </div>
        <div id="admin-page-root"></div>
      </main>
    `;
    document.body.appendChild(layout);
    document.getElementById("admin-logout").addEventListener("click", (e) => {
      e.preventDefault();
      window.GriotAuth.logout();
    });

    // ----- BLOC 9 : bouton mode nuit / soleil côté admin -----
    (function () {
      const slot = document.getElementById("admin-theme-slot");
      const mount = () => window.GriotTheme.mountToggleButton(slot);
      if (window.GriotTheme) { window.GriotTheme.init(); mount(); }
      else {
        const s = document.createElement("script");
        s.src = "/js/theme.js";
        s.onload = mount;
        document.head.appendChild(s);
      }
    })();

    return document.getElementById("admin-page-root");
  },

  /** Génère un formulaire simple en cartes à partir d'une config champs (pour CRUD rapide) */
  renderForm(fields, values = {}) {
    return fields
      .map((f) => {
        const val = values[f.name] ?? "";
        if (f.type === "textarea") {
          return `<div class="form-group"><label>${f.label}</label><textarea class="form-control" name="${f.name}" rows="3">${window.GriotUtils.escapeHtml(val)}</textarea></div>`;
        }
        if (f.type === "select") {
          return `<div class="form-group"><label>${f.label}</label><select class="form-control" name="${f.name}">
            ${f.options.map((o) => `<option value="${o.value}" ${o.value === val ? "selected" : ""}>${o.label}</option>`).join("")}
          </select></div>`;
        }
        if (f.type === "checkbox") {
          return `<div class="form-group"><label><input type="checkbox" name="${f.name}" ${val ? "checked" : ""}/> ${f.label}</label></div>`;
        }
        return `<div class="form-group"><label>${f.label}</label><input class="form-control" type="${f.type || "text"}" name="${f.name}" value="${window.GriotUtils.escapeHtml(val)}"/></div>`;
      })
      .join("");
  },

  /** Lit les valeurs d'un formulaire généré par renderForm */
  readForm(formEl, fields) {
    const values = {};
    fields.forEach((f) => {
      const el = formEl.querySelector(`[name="${f.name}"]`);
      if (f.type === "checkbox") values[f.name] = el.checked;
      else if (f.type === "number") values[f.name] = el.value ? Number(el.value) : null;
      else values[f.name] = el.value;
    });
    return values;
  },

  /** Statistiques du dashboard */
  async getDashboardStats() {
    const sb = window.sb;
    const [{ count: totalMembers }, { count: freeCount }, { count: formationCount }, { count: accompCount }, { data: payments }] = await Promise.all([
      sb.from("profiles").select("id", { count: "exact", head: true }),
      sb.from("profiles").select("id", { count: "exact", head: true }).eq("plan", "free"),
      sb.from("profiles").select("id", { count: "exact", head: true }).eq("plan", "formation"),
      sb.from("profiles").select("id", { count: "exact", head: true }).eq("plan", "accompagnement"),
      sb.from("payments").select("amount, status, created_at").eq("status", "success")
    ]);

    const totalRevenue = (payments || []).reduce((sum, p) => sum + (p.amount || 0), 0);

    const { count: pendingProofs } = await sb
      .from("messages")
      .select("id", { count: "exact", head: true })
      .eq("is_sale_proof", true)
      .eq("sale_proof_status", "pending");

    const { count: pendingReferrals } = await sb
      .from("referrals")
      .select("id", { count: "exact", head: true })
      .eq("status", "pending");

    return {
      totalMembers: totalMembers || 0,
      freeCount: freeCount || 0,
      formationCount: formationCount || 0,
      accompCount: accompCount || 0,
      totalRevenue,
      paymentsCount: (payments || []).length,
      pendingProofs: pendingProofs || 0,
      pendingReferrals: pendingReferrals || 0
    };
  },

  /** Récupère les clics par canal (UTM) des 30 derniers jours */
  async getChannelStats() {
    const sb = window.sb;
    const since = new Date();
    since.setDate(since.getDate() - 30);
    const { data } = await sb.from("channel_clicks").select("channel, utm_source, created_at").gte("created_at", since.toISOString());
    const byChannel = { whatsapp: 0, telegram: 0 };
    (data || []).forEach((c) => { if (byChannel[c.channel] !== undefined) byChannel[c.channel]++; });
    return byChannel;
  }
};

window.GriotAdmin = GriotAdmin;