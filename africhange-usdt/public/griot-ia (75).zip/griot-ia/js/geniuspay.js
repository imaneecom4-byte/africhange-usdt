/* ============================================================
   GRIOT IA — Paiement GeniusPay (côté client)
   Toutes les clés secrètes restent dans la Netlify Function.
   ============================================================ */

const GriotPay = {
  PRICES: {
    formation: { amount: 9900, billing: "unique", label: "Formation Griot IA" },
    accompagnement_monthly: { amount: 15000, billing: "monthly", label: "Accompagnement Griot IA — Mensuel" },
    accompagnement_annual: { amount: 150000, billing: "annual", label: "Accompagnement Griot IA — Annuel" }
  },

  /**
   * Lance un paiement : appelle la Netlify Function qui crée la transaction
   * GeniusPay et retourne une checkout_url vers laquelle on redirige l'utilisateur.
   */
  async startCheckout(planKey, profile) {
    const priceInfo = this.PRICES[planKey];
    if (!priceInfo) throw new Error("Offre inconnue");

    const res = await fetch("/api/webhooks/geniuspay-create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: priceInfo.amount,
        description: priceInfo.label,
        customer: { email: profile.email, name: profile.full_name || profile.email },
        metadata: {
          user_id: profile.id,
          plan: planKey.startsWith("accompagnement") ? "accompagnement" : "formation",
          billing: priceInfo.billing
        },
        success_url: `${window.location.origin}/app/index.html?payment=success`,
        error_url: `${window.location.origin}/app/index.html?payment=error`
      })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || "Impossible de créer le paiement. Réessaie.");
    }
    const data = await res.json();
    if (!data.checkout_url) throw new Error("Réponse de paiement invalide.");
    window.location.href = data.checkout_url;
  }
};

window.GriotPay = GriotPay;
