/* ============================================================
   GRIOT IA — Gamification (points & leaderboard)
   ============================================================ */

const GriotGamification = {
  POINTS: {
    lesson_completed: 10,
    comment_posted: 5,
    post_created: 20,
    live_attended: 30,
    sale_validated: 100
  },
  MP_UNLOCK_THRESHOLD: 500,

  /** Ajoute des points à l'utilisateur courant (ou un utilisateur précis) */
  async addPoints(userId, amount) {
    const sb = window.sb;
    const { data: profile } = await sb.from("profiles").select("points").eq("id", userId).single();
    if (!profile) return;
    const newTotal = (profile.points || 0) + amount;
    await sb.from("profiles").update({ points: newTotal }).eq("id", userId);
    return newTotal;
  },

  /** Récupère le TOP 20 du leaderboard */
  async getLeaderboard() {
    const sb = window.sb;
    const { data, error } = await sb
      .from("profiles")
      .select("id, full_name, avatar_url, points, plan")
      .order("points", { ascending: false })
      .limit(20);
    if (error) return [];
    return data;
  },

  /** Récupère le rang exact de l'utilisateur courant (même hors TOP 20) */
  async getUserRank(userId, userPoints) {
    const sb = window.sb;
    const { count } = await sb
      .from("profiles")
      .select("id", { count: "exact", head: true })
      .gt("points", userPoints || 0);
    return (count || 0) + 1;
  }
};

window.GriotGamification = GriotGamification;
