/* ============================================================
   GRIOT IA — LE GUIDE SUPRÊME (toutes les pages)
   Bouton "?" à gauche → visite complète de chaque zone.
   🆕 Au tout premier arrivée : la visite se lance seule.
   ============================================================ */

const GriotOnboarding = {
  TOURS: {
    "/app/index.html": [
      { sel: "#notif-bell-btn", text: "🔔 LA CLOCHE : toutes tes notifications (réponses, annonces, messages). Clique pour voir." },
      { sel: "#theme-toggle, #theme-btn", text: "🌙 MODE JOUR / NUIT : change l'ambiance du site selon ton goût." },
      { sel: "text:continuer la formation", text: "▶️ TA PROGRESSION : ce bouton te ramène exactement à la leçon où tu t'étais arrêté." },
      { sel: "text:rejoindre le live", text: "🎥 LE LIVE : clique pour rejoindre le prochain live coaching (plan Accompagnement)." },
      { sel: "text:classroom", text: "🎓 CLASSROOM : ta formation complète, module par module, leçon par leçon." },
      { sel: "text:communauté", text: "🏘️ COMMUNAUTÉ : le groupe privé pour poser tes questions et gagner des points." },
      { sel: ".bottom-nav", text: "🧭 LA BARRE DE NAVIGATION : Accueil, Ressources, Classroom, Communauté, Messages, Live, Classement. Tout le site dans ton pouce." },
      { sel: "#coach-ia-btn", text: "🤖 TON COACH IA : disponible 24h/24 pour toutes tes questions sur la vente et l'IA." },
      { sel: "#ob-help-btn", text: "❓ CE BOUTON : ton guide suprême. Reclique dessus quand tu veux. Bienvenue chez toi ! 🏠" }
    ],
    "/app/classroom.html": [
      { sel: "#module-grid, .module-grid", text: "🎓 TES MODULES : chaque carte = un module. Clique pour ouvrir ses leçons (vidéos, PDF, textes)." },
      { sel: ".bottom-nav", text: "🧭 Navigue librement : tout est connecté." }
    ],
    "/app/lesson.html": [
      { sel: ".video-frame, .lesson-content-text, .pdf-frame", text: "📖 LE CONTENU DE TA LEÇON : vidéo, texte riche ou PDF, tout est là." },
      { sel: ".resource-link-row", text: "📎 LES RESSOURCES : fichiers et liens bonus de la leçon." },
      { sel: "#complete-btn", text: "✅ MARQUER TERMINÉ : clique pour valider la leçon et gagner +10 points !" }
    ],
    "/app/ressources.html": [
      { sel: "#res-search", text: "🔍 RECHERCHE : tape un mot ('vente', 'WhatsApp'...) pour trouver la ressource en 2 secondes." },
      { sel: "#res-list", text: "📚 TES RESSOURCES : guides, modèles et outils à télécharger selon ton plan." }
    ],
    "/app/community.html": [
      { sel: "#composer-card", text: "✍️ PRÉSENTE-TOI : écris ton premier post, la famille va t'accueillir !" },
      { sel: "#cat-pills", text: "🏷️ CATÉGORIES : filtre les posts par sujet." },
      { sel: "#posts-list", text: "👍 LES POSTS : like, commente, gagne des points. Clique sur le nom d'un membre pour voir sa carte profil et lui écrire." }
    ],
    "/app/messages.html": [
      { sel: "#msg-search", text: "🔍 CHERCHE UN MEMBRE : tape son nom pour démarrer une discussion privée." },
      { sel: "#conv-list", text: "💬 TES CONVERSATIONS : aperçu du dernier message + pastille rouge = messages non lus." }
    ],
    "/app/conversation.html": [
      { sel: "label:has(#file-input)", text: "📎 PIÈCE JOINTE : envoie une photo ou une vidéo dans la discussion." },
      { sel: "#msg-input", text: "✍️ Écris ton message ici, comme sur WhatsApp." },
      { sel: "label:has(#sale-proof-check)", text: "🧾 PREUVE DE VENTE : coche cette case quand tu envoies une preuve de vente → +100 points après validation du coach !" },
      { sel: "#send-btn", text: "📨 ENVOYER : ton message part instantanément." }
    ],
    "/app/calendar.html": [
      { sel: "#cal-grid", text: "📅 LE CALENDRIER : points bleus = jours de live, rond rouge = aujourd'hui." },
      { sel: "#day-events", text: "👆 LES LIVES DU JOUR : clique sur un jour puis sur le live pour voir l'image, l'heure et rejoindre." }
    ],
    "/app/classement.html": [
      { sel: "#page-root .card", text: "🏆 LE CLASSEMENT : les membres les plus actifs de la communauté. Like, commente, termine des leçons pour monter !" }
    ],
    "/app/profil.html": [
      { sel: "text:modifier", text: "✏️ MODIFIER MON PROFIL : change ton nom, ta photo de profil, tes infos." },
      { sel: "text:points", text: "⭐ TES POINTS & TON NIVEAU : plus tu es actif, plus tu montes. Les points débloquent des avantages !" },
      { sel: "text:déconnexion", text: "🚪 DÉCONNEXION : pour changer de compte ou te déconnecter en sécurité." }
    ],
    "/app/invite-friends.html": [
      { sel: "#page-root .card", text: "🎁 PARRAINAGE : invite 5 amis avec ton lien → débloque la Formation GRATUITEMENT. Tout le monde gagne !" }
    ]
  },

  /** Trouve l'élément : sélecteur CSS ou par texte ("text:xxx") */
  findTarget(sel) {
    try {
      if (sel.startsWith("text:")) {
        const t = sel.slice(5).toLowerCase();
        const els = Array.from(document.querySelectorAll("button, a, label"));
        return els.find((el) => (el.textContent || "").toLowerCase().includes(t)) || null;
      }
      return document.querySelector(sel);
    } catch (e) {
      return null;
    }
  },

  /** Bouton "?" flottant à GAUCHE sur chaque page */
  maybeStart() {
    if (document.getElementById("ob-help-btn")) return;
    const key = window.location.pathname;
    const steps = this.TOURS[key];
    if (!steps) return;

    setTimeout(() => {
      const valid = steps.filter((s) => this.findTarget(s.sel));
      if (!valid.length) return;

      const btn = document.createElement("button");
      btn.id = "ob-help-btn";
      btn.textContent = "?";
      btn.style.cssText = "position:fixed;bottom:90px;left:16px;z-index:500;width:40px;height:40px;border-radius:50%;background:#F2994A;color:#fff;font-size:20px;font-weight:800;border:none;box-shadow:0 4px 12px rgba(0,0,0,.25);cursor:pointer;";
      btn.addEventListener("click", () => this.run(valid));
      document.body.appendChild(btn);

      // 🆕 AU TOUT PREMIER ARRIVAGE : la visite se lance toute seule
      try {
        if (!localStorage.getItem("griot_tour_done")) {
          localStorage.setItem("griot_tour_done", "1");
          setTimeout(() => this.run(valid), 800);
        }
      } catch (e) {}
    }, 1200);
  },

  run(steps) {
    if (document.getElementById("ob-dim")) return;
    let i = 0;

    const dim = document.createElement("div");
    dim.id = "ob-dim";
    dim.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:900;";

    const ring = document.createElement("div");
    ring.style.cssText = "position:fixed;z-index:901;border:3px solid #F2994A;border-radius:14px;pointer-events:none;transition:top .25s,left .25s,width .25s,height .25s;";

    const card = document.createElement("div");
    card.style.cssText = "position:fixed;z-index:902;background:#fff;border-radius:16px;padding:16px;left:16px;right:16px;max-width:340px;margin:0 auto;box-shadow:0 12px 32px rgba(0,0,0,.35);";

    document.body.appendChild(dim);
    document.body.appendChild(ring);
    document.body.appendChild(card);

    const finish = () => { dim.remove(); ring.remove(); card.remove(); };

    const place = () => {
      const el = this.findTarget(steps[i].sel);
      el.scrollIntoView({ block: "center", behavior: "auto" });
      const r = el.getBoundingClientRect();
      ring.style.top = (r.top - 6) + "px";
      ring.style.left = Math.max(4, r.left - 6) + "px";
      ring.style.width = (r.width + 12) + "px";
      ring.style.height = (r.height + 12) + "px";

      const spaceBelow = window.innerHeight - r.bottom;
      card.style.top = (spaceBelow > 220 ? Math.min(r.bottom + 14, window.innerHeight - 210) : Math.max(12, r.top - 215)) + "px";

      card.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="background:#FFF3E6;color:#B26A00;font-size:12px;font-weight:700;border-radius:10px;padding:3px 10px;">${i + 1} / ${steps.length}</span>
          <button id="ob-quit" style="font-size:12px;opacity:.6;cursor:pointer;">Quitter</button>
        </div>
        <p style="margin:12px 0 14px;font-size:14px;line-height:1.5;color:#222;">${steps[i].text}</p>
        <div style="display:flex;justify-content:flex-end;gap:8px;">
          ${i > 0 ? `<button id="ob-prev" style="font-size:14px;font-weight:600;opacity:.7;padding:8px 12px;cursor:pointer;">Précédent</button>` : ""}
          <button id="ob-next" style="background:#F2994A;color:#1A1A2E;font-weight:700;border-radius:10px;padding:9px 18px;font-size:14px;cursor:pointer;">${i === steps.length - 1 ? "Terminer ✅" : "Suivant"}</button>
        </div>`;
      card.querySelector("#ob-quit").addEventListener("click", finish);
      card.querySelector("#ob-next").addEventListener("click", () => {
        if (i === steps.length - 1) finish();
        else { i++; place(); }
      });
      const prev = card.querySelector("#ob-prev");
      if (prev) prev.addEventListener("click", () => { i--; place(); });
    };

    place();
  }
};

window.GriotOnboarding = GriotOnboarding;