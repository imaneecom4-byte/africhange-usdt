/* ============================================================
   GRIOT IA — PWA install banner + notifications push
   ============================================================ */

let deferredInstallPrompt = null;

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  showInstallBanner();
});

function showInstallBanner() {
  if (localStorage.getItem("griot_pwa_dismissed") === "1") return;
  if (document.getElementById("pwa-install-banner")) return;

  const banner = document.createElement("div");
  banner.id = "pwa-install-banner";
  banner.style.cssText = `
    position:fixed;left:16px;right:16px;bottom:76px;z-index:500;
    background:#1A1A2E;color:#fff;border-radius:16px;padding:14px 16px;
    display:flex;align-items:center;gap:12px;box-shadow:0 6px 20px rgba(0,0,0,.3);
  `;
  banner.innerHTML = `
    <div style="font-size:26px;">📲</div>
    <div style="flex:1;">
      <div style="font-weight:700;font-size:14px;">Installer Griot IA</div>
      <div style="font-size:12px;opacity:.8;">Accès rapide + notifications</div>
    </div>
    <button id="pwa-install-btn" style="background:#F5A623;color:#1A1A2E;border-radius:50px;padding:8px 14px;font-weight:700;font-size:12px;">Installer</button>
    <button id="pwa-dismiss-btn" style="color:rgba(255,255,255,.6);font-size:20px;padding:0 4px;">✕</button>
  `;
  document.body.appendChild(banner);

  document.getElementById("pwa-install-btn").addEventListener("click", async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    banner.remove();
  });
  document.getElementById("pwa-dismiss-btn").addEventListener("click", () => {
    localStorage.setItem("griot_pwa_dismissed", "1");
    banner.remove();
  });
}

/* ============================================================
   🔔 NOTIFICATIONS PUSH — lance le service worker après connexion
   ============================================================ */
window.initPushNotifications = async function() {
  if (!("serviceWorker" in navigator)) return;
  if (!("Notification" in window)) return;

  const profile = window.GriotAuth && window.GriotAuth.getProfile 
    ? await window.GriotAuth.getProfile() : null;
  if (!profile) return;

  window.GriotNotifications.init();
};

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    setTimeout(() => {
      if (window.initPushNotifications) window.initPushNotifications();
    }, 2000);
  });
}

/* ============================================================
   📲 INSTALL MANUEL — pour iPhone + retardataires
   ============================================================ */
window.manualInstallApp = function() {
  if (deferredInstallPrompt) {
    deferredInstallPrompt.prompt();
    deferredInstallPrompt.userChoice.then((choice) => {
      deferredInstallPrompt = null;
    });
  } else {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    if (isIOS) {
      alert("Pour installer Griot IA sur ton iPhone :\n\n1️⃣ Appuie sur le bouton Partager ⬆️ en bas de Safari\n2️⃣ Choisis 'Sur l'écran d'accueil'\n3️⃣ Appuie sur 'Ajouter'");
    } else {
      alert("Pour installer Griot IA :\n\n1️⃣ Appuie sur le menu ⋮ en haut à droite de Chrome\n2️⃣ Choisis 'Installer l'application' ou 'Ajouter à l'écran d'accueil'\n3️⃣ Confirme");
    }
  }
};

window.isAppInstalled = function() {
  return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
};