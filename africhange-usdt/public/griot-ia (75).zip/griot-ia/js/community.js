/* ============================================================
   GRIOT IA — Communauté façon Skool
   ============================================================ */

const GriotCommunity = {
  LEVEL_THRESHOLDS: [0, 100, 300, 600, 1000, 1500, 2500, 4000],

  getLevel(points) {
    let level = 1;
    for (let i = 1; i < this.LEVEL_THRESHOLDS.length; i++) {
      if (points >= this.LEVEL_THRESHOLDS[i]) level = i + 1;
    }
    return level;
  },

  // ---------------------------------------------------------
  // POINT D'ENTRÉE
  // ---------------------------------------------------------
  async mount(profile) {
    window.GriotApp.renderHeader(profile, "Communauté");
    window.GriotApp.renderBottomNav("community");
    const root = document.getElementById("page-root");
    root.innerHTML = `<h2>Communauté</h2>`;

    if (profile.plan !== "accompagnement") {
      const wrap = document.createElement("div");
      wrap.className = "mt-16";
      root.appendChild(wrap);
      window.GriotApp.renderFomoLock(wrap, "Rejoins la communauté privée, pose tes questions et échange avec les autres membres motivés.");
      window.GriotAI.mountWidget(profile);
      return;
    }

    const isStaff = ["admin", "owner", "moderator"].includes(profile.role);
    if (!isStaff) {
      const gate = await this.checkMembershipGate(profile);
      if (gate === "blocked") return;
    }

    const { data: mpSetting } = await window.sb.from("settings").select("value").eq("key", "community_mp_enabled").maybeSingle();
    this.mpEnabled = mpSetting ? JSON.parse(typeof mpSetting.value === "string" ? mpSetting.value : JSON.stringify(mpSetting.value)) !== false : true;

    await this.renderFeed(profile);
  },

  // ---------------------------------------------------------
  // ADHÉSION
  // ---------------------------------------------------------
  async checkMembershipGate(profile) {
    const sb = window.sb;
    const root = document.getElementById("page-root");

    if (profile.community_status === "approved") return "ok";

    if (profile.community_status === "pending") {
      root.innerHTML = `<h2>Communauté</h2>
        <div class="card mt-16 text-center">
          <div style="font-size:36px;">⏳</div>
          <h3 class="mt-8">Ta demande est en attente</h3>
          <p class="text-secondary text-sm mt-8">Un modérateur va examiner ta demande d'adhésion sous peu.</p>
        </div>`;
      return "blocked";
    }

    if (profile.community_status === "rejected") {
      root.innerHTML = `<h2>Communauté</h2>
        <div class="card mt-16 text-center">
          <div style="font-size:36px;">🚫</div>
          <h3 class="mt-8">Demande refusée</h3>
          <p class="text-secondary text-sm mt-8">Contacte le support si tu penses qu'il s'agit d'une erreur.</p>
        </div>`;
      return "blocked";
    }

    const { data: questions } = await sb.from("community_membership_questions").select("*").order("order_index");
    if (!questions || !questions.length) {
      await sb.from("profiles").update({ community_status: "approved" }).eq("id", profile.id);
      profile.community_status = "approved";
      return "ok";
    }

    root.innerHTML = `<h2>Rejoindre la communauté</h2>
      <div class="card mt-16">
        <p class="text-secondary text-sm mb-16">Réponds à ces quelques questions pour rejoindre la communauté Griot IA.</p>
        <form id="membership-form">
          ${questions
            .map(
              (q, i) => `
            <div class="form-group">
              <label>${window.GriotUtils.escapeHtml(q.question)}${q.required ? " *" : ""}</label>
              <textarea class="form-control" name="q_${q.id}" rows="2" ${q.required ? "required" : ""}></textarea>
            </div>`
            )
            .join("")}
          <button type="submit" class="btn btn-primary btn-block">Envoyer ma demande</button>
        </form>
      </div>`;

    document.getElementById("membership-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      const answers = questions.map((q) => ({
        user_id: profile.id,
        question_id: q.id,
        answer: formData.get(`q_${q.id}`) || ""
      }));
      await sb.from("community_membership_answers").upsert(answers);
      await sb.from("profiles").update({ community_status: "pending" }).eq("id", profile.id);
      window.GriotUtils.showToast("Demande envoyée !", "success");
      profile.community_status = "pending";
      this.checkMembershipGate(profile);
    });

    return "blocked";
  },

  // ---------------------------------------------------------
  // CARTE DE BIENVENUE
  // ---------------------------------------------------------
  async renderWelcomeCard(profile, container) {
    const sb = window.sb;
    const { data: steps } = await sb.from("community_welcome_steps").select("*").order("step_number");
    if (!steps || !steps.length) return;
    const { data: progress } = await sb.from("community_welcome_progress").select("step_number").eq("user_id", profile.id);
    const doneSteps = new Set((progress || []).map((p) => p.step_number));

    if (doneSteps.size >= steps.length) return;

    const card = document.createElement("div");
    card.className = "card mt-16";
    card.style.border = "2px solid var(--accent)";
    card.innerHTML = `
      <strong>👋 Bienvenue ! Commence ici</strong>
      <div class="mt-16" id="welcome-steps-list"></div>
    `;
    container.appendChild(card);

    const list = card.querySelector("#welcome-steps-list");
    list.innerHTML = steps
      .map(
        (s) => `
      <div class="flex items-center justify-between mt-8" style="padding:8px 0;border-top:1px solid #f5f5f5;">
        <label class="flex items-center gap-8" style="cursor:pointer;">
          <input type="checkbox" data-step="${s.step_number}" ${doneSteps.has(s.step_number) ? "checked disabled" : ""} />
          <span>${window.GriotUtils.escapeHtml(s.label)}</span>
        </label>
        ${s.link ? `<a href="${s.link}" class="btn btn-outline btn-sm">Aller →</a>` : ""}
      </div>`
      )
      .join("");

    list.querySelectorAll("[data-step]").forEach((cb) => {
      cb.addEventListener("change", async () => {
        const stepNumber = Number(cb.getAttribute("data-step"));
        await sb.from("community_welcome_progress").upsert({ user_id: profile.id, step_number: stepNumber });
        cb.disabled = true;
        window.GriotUtils.showToast("Étape validée !", "success");
      });
    });
  },

  // ---------------------------------------------------------
  // FEED PRINCIPAL
  // ---------------------------------------------------------
  async renderFeed(profile) {
    const sb = window.sb;
    const isStaff = ["admin", "owner", "moderator"].includes(profile.role);
    const root = document.getElementById("page-root");

    const { data: categories } = await sb.from("community_categories").select("*").order("order_index");
    const visibleCategories = (categories || []).filter((c) => !c.admin_only || isStaff);

    root.innerHTML = `
      <div id="welcome-card-slot"></div>
      <div class="card mt-16" id="composer-card"></div>
      <div class="carousel" id="cat-pills" style="padding-left:0;overflow-x:auto;display:flex;gap:8px;"></div>
      <div class="mt-16" id="posts-list"></div>
    `;

    await this.renderWelcomeCard(profile, document.getElementById("welcome-card-slot"));
    this.renderComposer(profile, visibleCategories);

    let activeCategory = "all";
    const pillsEl = document.getElementById("cat-pills");
    pillsEl.innerHTML =
      `<button class="btn btn-primary btn-sm" data-cat="all" style="flex:0 0 auto;">Tous</button>` +
      visibleCategories
        .map((c) => `<button class="btn btn-outline btn-sm" data-cat="${c.id}" style="flex:0 0 auto;">${c.emoji || "💬"} ${window.GriotUtils.escapeHtml(c.name)}</button>`)
        .join("");

    pillsEl.querySelectorAll("[data-cat]").forEach((btn) => {
      btn.addEventListener("click", () => {
        activeCategory = btn.getAttribute("data-cat");
        pillsEl.querySelectorAll("button").forEach((b) => {
          b.classList.remove("btn-primary");
          b.classList.add("btn-outline");
        });
        btn.classList.remove("btn-outline");
        btn.classList.add("btn-primary");
        this.loadPosts(profile, activeCategory, isStaff);
      });
    });

    await this.loadPosts(profile, activeCategory, isStaff);
    window.GriotAI.mountWidget(profile);
  },

  // ---------------------------------------------------------
  // COMPOSER
  // ---------------------------------------------------------
  renderComposer(profile, categories) {
    const card = document.getElementById("composer-card");

    card.innerHTML = `
      <div class="flex gap-12">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0;overflow:hidden;">
          ${profile.avatar_url ? `<img src="${profile.avatar_url}" style="width:100%;height:100%;object-fit:cover;" />` : (profile.full_name || profile.email || "?")[0].toUpperCase()}
        </div>
        <button id="open-composer-btn" class="form-control text-secondary" style="text-align:left;">Écrire quelque chose...</button>
      </div>
      <div id="composer-form-wrap"></div>
    `;

    document.getElementById("open-composer-btn").addEventListener("click", () => {
      this.openComposerForm(profile, categories);
    });
  },

  openComposerForm(profile, categories) {
    const isStaff = ["admin", "owner", "moderator"].includes(profile.role);
    const wrap = document.getElementById("composer-form-wrap");
    if (wrap.innerHTML) {
      wrap.innerHTML = "";
      return;
    }

    wrap.innerHTML = `
      <form id="new-post-form" class="mt-16">
        <div class="form-group">
          <label>Catégorie *</label>
          <select class="form-control" name="category_id" required>
            <option value="">— Choisir une catégorie —</option>
            ${categories.map((c) => `<option value="${c.id}">${c.emoji || "💬"} ${window.GriotUtils.escapeHtml(c.name)}</option>`).join("")}
          </select>
        </div>
        ${
          isStaff
            ? `<div class="form-group">
                <label>Type de publication</label>
                <select class="form-control" id="post-type-select">
                  <option value="text">📝 Texte</option>
                  <option value="image">🖼️ Image</option>
                  <option value="video">🎬 Vidéo</option>
                  <option value="poll">📊 Sondage</option>
                </select>
              </div>`
            : ""
        }
        <div class="form-group">
          <label>Titre (optionnel)</label>
          <input class="form-control" name="title" placeholder="Titre du post..." />
        </div>
        <div class="form-group">
          <label>Message</label>
          <textarea class="form-control" name="content" rows="3" placeholder="Texte et émojis 😀..." required></textarea>
        </div>
        <div id="post-type-extra"></div>
        <button type="submit" class="btn btn-primary">Publier</button>
        <button type="button" id="cancel-post-btn" class="btn btn-outline">Annuler</button>
      </form>
    `;

    document.getElementById("cancel-post-btn").addEventListener("click", () => (wrap.innerHTML = ""));

    let mediaUrl = "";
    let pollOptions = [];

    if (isStaff) {
      const typeSelect = document.getElementById("post-type-select");
      const extra = document.getElementById("post-type-extra");

      const renderExtra = (type) => {
        mediaUrl = "";
        pollOptions = [];
        if (type === "image") {
          extra.innerHTML = `<div class="form-group"><label>Image</label><div id="post-image-uploader"></div></div>`;
          window.GriotUpload.mountUploader(document.getElementById("post-image-uploader"), {
            bucket: "resources",
            folder: "community",
            accept: "image/*",
            isImage: true,
            onUploaded: (url) => { mediaUrl = url; }
          });
        } else if (type === "video") {
          extra.innerHTML = `
            <div class="form-group"><label>Lien vidéo (YouTube/Vimeo)</label><input class="form-control" id="post-video-url" placeholder="https://..." /></div>
            <div class="text-center text-secondary text-sm">— ou —</div>
            <div class="form-group"><label>Uploader un fichier vidéo</label><div id="post-video-uploader"></div></div>`;
          window.GriotUpload.mountUploader(document.getElementById("post-video-uploader"), {
            bucket: "lessons",
            folder: "community-videos",
            accept: "video/*",
            isImage: false,
            onUploaded: (url) => { mediaUrl = url; }
          });
        } else if (type === "poll") {
          extra.innerHTML = `
            <div class="form-group">
              <label>Options du sondage (une par ligne, 2 à 6)</label>
              <textarea class="form-control" id="poll-options-input" rows="4" placeholder="Option 1
Option 2
Option 3"></textarea>
            </div>`;
        } else {
          extra.innerHTML = "";
        }
      };
      renderExtra("text");
      typeSelect.addEventListener("change", (e) => renderExtra(e.target.value));
    }

    document.getElementById("new-post-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const sb = window.sb;
      const formData = new FormData(e.target);
      const categoryId = formData.get("category_id");
      if (!categoryId) {
        window.GriotUtils.showToast("Choisis une catégorie pour publier.", "error");
        return;
      }

      const postType = isStaff ? document.getElementById("post-type-select").value : "text";
      const payload = {
        user_id: profile.id,
        category_id: categoryId,
        title: formData.get("title") || null,
        content: formData.get("content"),
        post_type: postType,
        image_url: postType === "image" ? mediaUrl || null : null,
        video_url: postType === "video" ? (document.getElementById("post-video-url")?.value || mediaUrl || null) : null
      };

      const { data: newPost, error } = await sb.from("community_posts").insert(payload).select().single();
      if (error) {
        window.GriotUtils.showToast("Erreur lors de la publication.", "error");
        return;
      }

      if (postType === "poll") {
        const rawOptions = (document.getElementById("poll-options-input").value || "")
          .split("\n")
          .map((o) => o.trim())
          .filter(Boolean)
          .slice(0, 6);
        if (rawOptions.length >= 2) {
          const rows = rawOptions.map((label, i) => ({ post_id: newPost.id, label, order_index: i }));
          await sb.from("community_poll_options").insert(rows);
        }
      }

      if (!isStaff) {
        await window.GriotGamification.addPoints(profile.id, window.GriotGamification.POINTS.post_created);
        window.GriotUtils.showToast("Post publié ! +20 points", "success");
        window.GriotChecklist?.completeItem?.(profile.id, "post_created").catch?.(() => {});
      } else {
        window.GriotUtils.showToast("Post publié", "success");
      }

      wrap.innerHTML = "";
      this.loadPosts(profile, "all", isStaff);
    });
  },

  // ---------------------------------------------------------
  // CHARGEMENT + RENDU DES POSTS
  // ---------------------------------------------------------
  async loadPosts(profile, categoryId, isStaff) {
    const sb = window.sb;
    let query = sb
      .from("community_posts")
      .select("*, author:user_id(id, full_name, avatar_url, points), category:category_id(name, emoji)")
      .order("is_pinned", { ascending: false })
      .order("created_at", { ascending: false })
      .limit(50);
    if (categoryId && categoryId !== "all") query = query.eq("category_id", categoryId);

    const { data: posts } = await query;
    const list = document.getElementById("posts-list");
    if (!posts || !posts.length) {
      list.innerHTML = `<p class="text-secondary text-center mt-24">Aucun post pour le moment.</p>`;
      return;
    }

    const { data: myLikes } = await sb.from("community_likes").select("post_id").eq("user_id", profile.id);
    const likedSet = new Set((myLikes || []).map((l) => l.post_id));

    list.innerHTML = "";
    for (const post of posts) {
      const el = await this.buildPostCard(post, profile, isStaff, likedSet.has(post.id));
      list.appendChild(el);
    }
  },

  async buildPostCard(post, profile, isStaff, liked) {
    const sb = window.sb;
    const level = this.getLevel(post.author?.points || 0);
    const card = document.createElement("div");
    card.className = "card mt-16";

    let mediaHtml = "";
    if (post.post_type === "image" && post.image_url) {
      mediaHtml = `<img src="${post.image_url}" style="width:100%;border-radius:12px;margin-top:10px;" />`;
    } else if (post.post_type === "video" && post.video_url) {
      const extracted = window.GriotUtils.extractVideoId(post.video_url);
      if (extracted.type === "youtube" || extracted.type === "vimeo") {
        mediaHtml = `<div class="video-frame mt-16"><iframe src="${window.GriotUtils.getVideoEmbed(extracted.type, extracted.id)}" allowfullscreen></iframe></div>`;
      } else {
        mediaHtml = `<video src="${post.video_url}" controls style="width:100%;border-radius:12px;margin-top:10px;"></video>`;
      }
    }

    card.innerHTML = `
      <div class="flex items-center gap-12">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0;cursor:pointer;overflow:hidden;" data-author="${post.author?.id}">
          ${post.author?.avatar_url ? `<img src="${post.author.avatar_url}" style="width:100%;height:100%;object-fit:cover;" />` : (post.author?.full_name || "?")[0].toUpperCase()}
        </div>
        <div style="flex:1;">
          <div class="flex items-center gap-8">
            <strong style="cursor:pointer;" data-author="${post.author?.id}">${window.GriotUtils.escapeHtml(post.author?.full_name || "Membre")}</strong>
            <span class="badge badge-gold" style="font-size:10px;">Niv. ${level}</span>
          </div>
          <div class="text-secondary text-sm">${window.GriotUtils.timeAgo(post.created_at)} · ${post.category?.emoji || "💬"} ${window.GriotUtils.escapeHtml(post.category?.name || "")}${post.is_pinned ? ' · <span style="color:var(--accent);">📌 Épinglé</span>' : ""}</div>
        </div>
        ${isStaff ? `<button class="btn btn-outline btn-sm" data-pin="${post.id}" data-pinned="${post.is_pinned}">${post.is_pinned ? "Désépingler" : "📌"}</button>` : ""}
        <button class="btn btn-outline btn-sm" data-delete-post="${post.id}" data-owner="${post.user_id}">🗑️</button>
        <button class="btn btn-outline btn-sm" data-report-post="${post.id}">⚠️</button>
      </div>
      ${post.title ? `<div style="font-weight:700;font-size:16px;margin-top:12px;">${window.GriotUtils.escapeHtml(post.title)}</div>` : ""}
      <p class="mt-8" style="white-space:pre-wrap;">${window.GriotUtils.escapeHtml(post.content)}</p>
      ${mediaHtml}
      <div id="poll-slot-${post.id}"></div>
      <div class="flex gap-16 mt-16">
        <button class="text-sm" data-like-post="${post.id}">${liked ? "❤️" : "🤍"} <span data-like-count="${post.id}">${post.likes_count || 0}</span></button>
        <button class="text-sm" data-toggle-comments="${post.id}">💬 <span data-comment-count="${post.id}">${post.comments_count || 0}</span></button>
      </div>
      <div class="mt-16" id="comments-${post.id}" style="display:none;"></div>
    `;

    const deleteBtn = card.querySelector(`[data-delete-post="${post.id}"]`);
    const canDelete = isStaff || post.user_id === profile.id;
    if (!canDelete) deleteBtn.remove();
    else deleteBtn.addEventListener("click", async () => {
      if (!confirm("Supprimer ce post ?")) return;
      await sb.from("community_posts").delete().eq("id", post.id);
      card.remove();
    });

    if (isStaff) {
      card.querySelector(`[data-pin="${post.id}"]`).addEventListener("click", async () => {
        if (!post.is_pinned) {
          const { count } = await sb.from("community_posts").select("id", { count: "exact", head: true }).eq("is_pinned", true);
          if ((count || 0) >= 3) {
            window.GriotUtils.showToast("Maximum 3 posts épinglés — désépingle-en un d'abord.", "error");
            return;
          }
        }
        await sb.from("community_posts").update({ is_pinned: !post.is_pinned }).eq("id", post.id);
        this.loadPosts(profile, "all", isStaff);
      });
    }

    card.querySelector(`[data-report-post="${post.id}"]`).addEventListener("click", async () => {
      const reason = prompt("Pourquoi signales-tu ce post ? (optionnel)") || "";
      await sb.from("community_reports").insert({ content_type: "post", content_id: post.id, reporter_id: profile.id, reason });
      window.GriotUtils.showToast("Post signalé, merci.", "success");
    });

    card.querySelectorAll("[data-author]").forEach((el) => {
      el.addEventListener("click", () => this.handleAuthorClick(post.author, profile));
    });

    card.querySelector(`[data-like-post="${post.id}"]`).addEventListener("click", async (e) => {
      await this.toggleLike(post, profile, e.currentTarget);
    });

    const toggleBtn = card.querySelector(`[data-toggle-comments="${post.id}"]`);
    const commentsSlot = card.querySelector(`#comments-${post.id}`);
    let commentsLoaded = false;
    toggleBtn.addEventListener("click", async () => {
      const isHidden = commentsSlot.style.display === "none";
      commentsSlot.style.display = isHidden ? "block" : "none";
      if (isHidden && !commentsLoaded) {
        commentsLoaded = true;
        await this.renderComments(post, profile, commentsSlot);
      }
    });

    if (post.post_type === "poll") {
      await this.renderPoll(post, profile, card.querySelector(`#poll-slot-${post.id}`));
    }

    return card;
  },

  // ---------------------------------------------------------
  // CARTE PROFIL FAÇON SKOOL
  // ---------------------------------------------------------
  async handleAuthorClick(author, profile) {
    if (!author || author.id === profile.id) return;
    const { data: full } = await window.sb
      .from("profiles")
      .select("id, full_name, avatar_url, points, created_at")
      .eq("id", author.id)
      .maybeSingle();
    this.openMemberProfile(full || author, profile);
  },

  openMemberProfile(member, profile) {
    document.getElementById("member-profile-overlay")?.remove();
    const level = this.getLevel(member.points || 0);
    const joined = member.created_at
      ? new Date(member.created_at).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })
      : "";
    const avatarInner = member.avatar_url
      ? `<img src="${member.avatar_url}" style="width:100%;height:100%;object-fit:cover;" />`
      : (member.full_name || "?")[0].toUpperCase();

    const overlay = document.createElement("div");
    overlay.id = "member-profile-overlay";
    overlay.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:600;display:flex;align-items:center;justify-content:center;padding:16px;";
    overlay.innerHTML = `
      <div class="card" style="max-width:340px;width:100%;text-align:center;padding:24px 20px;position:relative;">
        <button id="close-member-profile" style="position:absolute;top:10px;right:12px;font-size:16px;opacity:.6;">✖️</button>
        <div style="width:76px;height:76px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:800;margin:0 auto;overflow:hidden;">
          ${avatarInner}
        </div>
        <div style="font-weight:800;font-size:17px;margin-top:12px;">${window.GriotUtils.escapeHtml(member.full_name || "Membre")}</div>
        <span class="badge badge-gold mt-8">Niv. ${level}</span>
        <div class="text-secondary text-sm mt-8">⭐ ${member.points || 0} points</div>
        ${joined ? `<div class="text-secondary text-sm mt-4">📅 Inscrit le ${joined}</div>` : ""}
        <button id="write-to-member-btn" class="btn btn-primary btn-block mt-16">💬 Écrire</button>
      </div>`;
    document.body.appendChild(overlay);

    overlay.querySelector("#close-member-profile").addEventListener("click", () => overlay.remove());
    overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector("#write-to-member-btn").addEventListener("click", async () => {
      if (this.mpEnabled === false) {
        window.GriotUtils.showToast("La messagerie entre membres est désactivée pour le moment.", "error");
        return;
      }
      if (!window.GriotMessaging.canMessageStudents(profile)) {
        window.GriotUtils.showToast(`🔒 Débloqué à ${window.GriotMessaging.MP_UNLOCK_THRESHOLD} points (tu as ${profile.points} points)`, "error", 5000);
        return;
      }
      const conv = await window.GriotMessaging.getOrCreateConversation(profile.id, member.id);
      window.location.href = `/app/conversation.html?id=${conv.id}`;
    });
  },

  async toggleLike(post, profile, btn) {
    const sb = window.sb;
    const { data: existing } = await sb.from("community_likes").select("*").eq("post_id", post.id).eq("user_id", profile.id).maybeSingle();
    if (existing) {
      await sb.from("community_likes").delete().eq("post_id", post.id).eq("user_id", profile.id);
      await sb.from("community_posts").update({ likes_count: Math.max((post.likes_count || 1) - 1, 0) }).eq("id", post.id);
      post.likes_count = Math.max((post.likes_count || 1) - 1, 0);
      if (post.user_id !== profile.id) await window.GriotGamification.addPoints(post.user_id, -1);
      btn.innerHTML = `🤍 <span data-like-count="${post.id}">${post.likes_count}</span>`;
    } else {
      await sb.from("community_likes").insert({ post_id: post.id, user_id: profile.id });
      await sb.from("community_posts").update({ likes_count: (post.likes_count || 0) + 1 }).eq("id", post.id);
      post.likes_count = (post.likes_count || 0) + 1;
      if (post.user_id !== profile.id) await window.GriotGamification.addPoints(post.user_id, 1);
      btn.innerHTML = `❤️ <span data-like-count="${post.id}">${post.likes_count}</span>`;
    }
  },

  // ---------------------------------------------------------
  // SONDAGES
  // ---------------------------------------------------------
  async renderPoll(post, profile, slot) {
    const sb = window.sb;
    const { data: options } = await sb.from("community_poll_options").select("*").eq("post_id", post.id).order("order_index");
    if (!options || !options.length) return;
    const { data: votes } = await sb.from("community_poll_votes").select("option_id, user_id").eq("post_id", post.id);
    const myVote = (votes || []).find((v) => v.user_id === profile.id);
    const totalVotes = (votes || []).length;

    const countByOption = {};
    (votes || []).forEach((v) => { countByOption[v.option_id] = (countByOption[v.option_id] || 0) + 1; });

    slot.innerHTML = `<div class="mt-16">` +
      options
        .map((o) => {
          const count = countByOption[o.id] || 0;
          const pct = totalVotes ? Math.round((count / totalVotes) * 100) : 0;
          if (myVote) {
            return `<div class="mt-8">
              <div class="flex justify-between text-sm"><span>${window.GriotUtils.escapeHtml(o.label)} ${myVote.option_id === o.id ? "✅" : ""}</span><span>${pct}%</span></div>
              <div style="height:8px;background:#eee;border-radius:10px;overflow:hidden;margin-top:4px;"><div style="height:100%;width:${pct}%;background:var(--accent);"></div></div>
            </div>`;
          }
          return `<button class="btn btn-outline btn-sm btn-block mt-8" data-vote="${o.id}">${window.GriotUtils.escapeHtml(o.label)}</button>`;
        })
        .join("") +
      `<div class="text-secondary text-sm mt-8">${totalVotes} vote${totalVotes > 1 ? "s" : ""}</div></div>`;

    if (!myVote) {
      slot.querySelectorAll("[data-vote]").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await sb.from("community_poll_votes").insert({ post_id: post.id, user_id: profile.id, option_id: btn.getAttribute("data-vote") });
          this.renderPoll(post, profile, slot);
        });
      });
    }
  },

  // ---------------------------------------------------------
  // COMMENTAIRES (photo + nom cliquable + likes + suppression)
  // ---------------------------------------------------------
  async renderComments(post, profile, slot) {
    const sb = window.sb;
    const isStaff = ["admin", "owner", "moderator"].includes(profile.role);
    const { data: comments } = await sb
      .from("community_comments")
      .select("*, author:user_id(id, full_name, points, avatar_url)")
      .eq("post_id", post.id)
      .order("created_at", { ascending: true });
    const { data: myLikes } = await sb.from("community_comment_likes").select("comment_id").eq("user_id", profile.id);
    const likedSet = new Set((myLikes || []).map((l) => l.comment_id));

    const topLevel = (comments || []).filter((c) => !c.parent_comment_id);
    const repliesOf = (parentId) => (comments || []).filter((c) => c.parent_comment_id === parentId);

    const renderComment = (c, depth) => {
      const canDeleteComment = isStaff || c.user_id === profile.id;
      const deleteBtnHtml = canDeleteComment ? `<button class="text-sm" data-delete-comment="${c.id}">🗑️</button>` : "";
      const avatarInner = c.author?.avatar_url
        ? `<img src="${c.author.avatar_url}" style="width:100%;height:100%;object-fit:cover;" />`
        : (c.author?.full_name || "?")[0].toUpperCase();

      return `
      <div class="mt-8" style="margin-left:${depth * 24}px;" data-comment-id="${c.id}">
        <div class="flex gap-8">
          <div style="width:28px;height:28px;border-radius:50%;background:var(--primary);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;cursor:pointer;overflow:hidden;" data-author="${c.author?.id}">
            ${avatarInner}
          </div>
          <div style="flex:1;">
            <div class="text-sm"><strong style="cursor:pointer;" data-author="${c.author?.id}">${window.GriotUtils.escapeHtml(c.author?.full_name || "Membre")}</strong> <span class="badge badge-gold" style="font-size:9px;">Niv. ${this.getLevel(c.author?.points || 0)}</span></div>
            <div class="text-sm">${window.GriotUtils.escapeHtml(c.content)}</div>
            <div class="flex gap-12 mt-8">
              <button class="text-sm" data-like-comment="${c.id}">${likedSet.has(c.id) ? "❤️" : "🤍"} <span data-comment-like-count="${c.id}">${c.likes_count || 0}</span></button>
              <button class="text-sm" data-reply-to="${c.id}">Répondre</button>
              ${deleteBtnHtml}
              <button class="text-sm" data-report-comment="${c.id}">⚠️</button>
            </div>
            <div id="reply-form-${c.id}"></div>
          </div>
        </div>
        ${repliesOf(c.id).map((r) => renderComment(r, depth + 1)).join("")}
      </div>
    `;
    };

    slot.innerHTML = `
      <div id="comments-tree">${topLevel.map((c) => renderComment(c, 0)).join("")}</div>
      <form id="new-comment-form-${post.id}" class="flex gap-8 mt-16">
        <input type="text" class="form-control" placeholder="Écrire un commentaire..." required />
        <button type="submit" class="btn btn-primary btn-sm">Envoyer</button>
      </form>
    `;

    // Clic sur un auteur de commentaire → carte profil
    slot.querySelectorAll("[data-author]").forEach((el) => {
      el.addEventListener("click", () => {
        const authorId = el.getAttribute("data-author");
        if (authorId) this.handleAuthorClick({ id: authorId }, profile);
      });
    });

    // Suppression de commentaires
    slot.querySelectorAll("[data-delete-comment]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const commentId = btn.getAttribute("data-delete-comment");
        if (!confirm("Supprimer ce commentaire ?")) return;

        await sb.from("community_comments").delete().eq("id", commentId);

        const { count } = await sb.from("community_comments").select("id", { count: "exact", head: true }).eq("post_id", post.id);
        const newCount = count || 0;
        await sb.from("community_posts").update({ comments_count: newCount }).eq("id", post.id);
        post.comments_count = newCount;
        const countEl = document.querySelector(`[data-comment-count="${post.id}"]`);
        if (countEl) countEl.textContent = newCount;

        window.GriotUtils.showToast("Commentaire supprimé", "success");
        this.renderComments(post, profile, slot);
      });
    });

    // Likes des commentaires
    slot.querySelectorAll("[data-like-comment]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const commentId = btn.getAttribute("data-like-comment");
        const comment = comments.find((c) => c.id === commentId);
        if (!comment) return;
        const { data: existing } = await sb.from("community_comment_likes").select("*").eq("comment_id", commentId).eq("user_id", profile.id).maybeSingle();
        if (existing) {
          await sb.from("community_comment_likes").delete().eq("comment_id", commentId).eq("user_id", profile.id);
          await sb.from("community_comments").update({ likes_count: Math.max((comment.likes_count || 1) - 1, 0) }).eq("id", commentId);
          if (comment.user_id !== profile.id) await window.GriotGamification.addPoints(comment.user_id, -1);
        } else {
          await sb.from("community_comment_likes").insert({ comment_id: commentId, user_id: profile.id });
          await sb.from("community_comments").update({ likes_count: (comment.likes_count || 0) + 1 }).eq("id", commentId);
          if (comment.user_id !== profile.id) await window.GriotGamification.addPoints(comment.user_id, 1);
        }
        this.renderComments(post, profile, slot);
      });
    });

    // Réponses imbriquées
    slot.querySelectorAll("[data-reply-to]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const parentId = btn.getAttribute("data-reply-to");
        const formSlot = document.getElementById(`reply-form-${parentId}`);
        if (formSlot.innerHTML) { formSlot.innerHTML = ""; return; }
        formSlot.innerHTML = `
          <form class="flex gap-8 mt-8 reply-form">
            <input type="text" class="form-control" placeholder="Répondre..." required />
            <button type="submit" class="btn btn-primary btn-sm">OK</button>
          </form>`;
        formSlot.querySelector(".reply-form").addEventListener("submit", async (e) => {
          e.preventDefault();
          const input = e.target.querySelector("input");
          const content = input.value.trim();
          if (!content) return;
          await sb.from("community_comments").insert({ post_id: post.id, user_id: profile.id, parent_comment_id: parentId, content });
          await sb.from("community_posts").update({ comments_count: (post.comments_count || 0) + 1 }).eq("id", post.id);
          post.comments_count = (post.comments_count || 0) + 1;
          document.querySelector(`[data-comment-count="${post.id}"]`).textContent = post.comments_count;
          await window.GriotGamification.addPoints(profile.id, window.GriotGamification.POINTS.comment_posted);
          this.notifyReply(parentId, profile, post.id);
          this.renderComments(post, profile, slot);
        });
      });
    });

    // Signalement de commentaire
    slot.querySelectorAll("[data-report-comment]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const reason = prompt("Pourquoi signales-tu ce commentaire ? (optionnel)") || "";
        await sb.from("community_reports").insert({ content_type: "comment", content_id: btn.getAttribute("data-report-comment"), reporter_id: profile.id, reason });
        window.GriotUtils.showToast("Commentaire signalé, merci.", "success");
      });
    });

    // Nouveau commentaire top-level
    const newForm = document.getElementById(`new-comment-form-${post.id}`);
    newForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const input = newForm.querySelector("input");
      const content = input.value.trim();
      if (!content) return;
      await sb.from("community_comments").insert({ post_id: post.id, user_id: profile.id, content });
      await sb.from("community_posts").update({ comments_count: (post.comments_count || 0) + 1 }).eq("id", post.id);
      post.comments_count = (post.comments_count || 0) + 1;
      document.querySelector(`[data-comment-count="${post.id}"]`).textContent = post.comments_count;
      await window.GriotGamification.addPoints(profile.id, window.GriotGamification.POINTS.comment_posted);
      this.notifyPostComment(post, profile);
      this.renderComments(post, profile, slot);
    });
  },

  // ---------------------------------------------------------
  // NOTIFICATIONS (cloche)
  // ---------------------------------------------------------
  async notifyPostComment(post, commenter) {
    if (post.user_id === commenter.id) return;
    await window.sb.from("community_notifications").insert({
      user_id: post.user_id,
      type: "comment",
      message: `${commenter.full_name || "Un membre"} a commenté ton post`,
      link: "/app/community.html"
    });
  },

  async notifyReply(parentCommentId, replier, postId) {
    const { data: parent } = await window.sb.from("community_comments").select("user_id").eq("id", parentCommentId).single();
    if (!parent || parent.user_id === replier.id) return;
    await window.sb.from("community_notifications").insert({
      user_id: parent.user_id,
      type: "reply",
      message: `${replier.full_name || "Un membre"} a répondu à ton commentaire`,
      link: "/app/community.html"
    });
  },

  /** Monte le panneau complet de notifications */
  async mountNotificationBell(profile) {
    const sb = window.sb;
    const existingBtn = document.getElementById("notif-bell-btn");
    if (!existingBtn || document.getElementById("notif-bell-panel")) return;

    const btn = existingBtn.cloneNode(true);
    existingBtn.replaceWith(btn);

    const panel = document.createElement("div");
    panel.id = "notif-bell-panel";
    panel.style.cssText = "display:none;position:fixed;top:60px;right:16px;left:16px;max-width:360px;margin-left:auto;background:#fff;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.2);z-index:500;max-height:60vh;overflow-y:auto;";
    document.body.appendChild(panel);

    async function refresh() {
      const { data: notifs } = await sb.from("community_notifications").select("*").eq("user_id", profile.id).order("created_at", { ascending: false }).limit(20);
      const unread = (notifs || []).filter((n) => !n.is_read).length;
      const badge = document.getElementById("notif-bell-badge");
      if (badge) {
        badge.style.display = unread > 0 ? "block" : "none";
        badge.textContent = unread > 9 ? "9+" : unread;
      }
      panel.innerHTML = (notifs || []).length
        ? notifs.map((n) => `<a href="${n.link || "#"}" data-notif="${n.id}" style="display:block;padding:12px 16px;border-bottom:1px solid #f0f0f0;${n.is_read ? "" : "background:#FFF8EC;"}"><div class="text-sm">${window.GriotUtils.escapeHtml(n.message)}</div><div class="text-secondary text-sm">${window.GriotUtils.timeAgo(n.created_at)}</div></a>`).join("")
        : `<div class="text-secondary text-sm" style="padding:16px;">Aucune notification.</div>`;
    }

    btn.addEventListener("click", async () => {
      panel.style.display = panel.style.display === "none" ? "block" : "none";
      if (panel.style.display === "block") {
        await sb.from("community_notifications").update({ is_read: true }).eq("user_id", profile.id).eq("is_read", false);
        await refresh();
      }
    });

    await refresh();
  }
};

window.GriotCommunity = GriotCommunity;