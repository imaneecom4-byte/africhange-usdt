/* ============================================================
   GRIOT IA — Checklist d'accueil / onboarding
   ============================================================ */

const GriotChecklist = {
  /** Liste toutes les étapes + statut de complétion pour l'utilisateur courant */
  async getItemsWithProgress(userId) {
    const sb = window.sb;
    const { data: items } = await sb
      .from("checklist_items")
      .select("*")
      .order("order_index", { ascending: true });
    const { data: progress } = await sb
      .from("checklist_progress")
      .select("item_id")
      .eq("user_id", userId);
    const doneIds = new Set((progress || []).map((p) => p.item_id));
    return (items || []).map((item) => ({ ...item, done: doneIds.has(item.id) }));
  },

  /** Marque une étape comme terminée et attribue les points de récompense */
  async completeItem(userId, itemId) {
    const sb = window.sb;
    const { data: existing } = await sb
      .from("checklist_progress")
      .select("*")
      .eq("user_id", userId)
      .eq("item_id", itemId)
      .maybeSingle();
    if (existing) return; // déjà fait

    const { data: item } = await sb.from("checklist_items").select("points_reward").eq("id", itemId).single();
    await sb.from("checklist_progress").insert({ user_id: userId, item_id: itemId });
    if (item?.points_reward) {
      await window.GriotGamification.addPoints(userId, item.points_reward);
    }
  },

  /** Calcule le pourcentage de progression global */
  getPercentage(itemsWithProgress) {
    if (!itemsWithProgress.length) return 0;
    const done = itemsWithProgress.filter((i) => i.done).length;
    return Math.round((done / itemsWithProgress.length) * 100);
  }
};

window.GriotChecklist = GriotChecklist;
