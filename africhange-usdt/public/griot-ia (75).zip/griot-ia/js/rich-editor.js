/* ============================================================
   GRIOT IA — Éditeur de texte riche partagé (basé sur Quill.js)
   Utilisé dans tous les champs "description" de l'admin :
   leçons, modules, ressources, événements, posts staff.
   Charge Quill depuis un CDN (comme le SDK Supabase) et fournit
   une API simple : mount() / getHTML() / setHTML().
   ============================================================ */

const GriotRichEditor = {
  _loaded: false,
  _loadingPromise: null,

  /** Charge le CSS + JS de Quill une seule fois, même si mount() est appelé plusieurs fois */
  loadQuill() {
    if (this._loaded) return Promise.resolve();
    if (this._loadingPromise) return this._loadingPromise;

    this._loadingPromise = new Promise((resolve) => {
      const css = document.createElement("link");
      css.rel = "stylesheet";
      css.href = "https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.snow.css";
      document.head.appendChild(css);

      const script = document.createElement("script");
      script.src = "https://cdn.jsdelivr.net/npm/quill@1.3.7/dist/quill.min.js";
      script.onload = () => {
        this._loaded = true;
        resolve();
      };
      document.head.appendChild(script);
    });
    return this._loadingPromise;
  },

  /**
   * Monte un éditeur riche dans le conteneur donné.
   * containerId : id d'un <div> vide où l'éditeur sera injecté.
   * initialHTML : contenu HTML initial (vide si nouveau).
   * uploadFolder : sous-dossier du bucket "resources" pour les images insérées.
   * Retourne { getHTML(): string } une fois prêt (via callback onReady).
   */
  async mount(containerId, initialHTML, onReady, uploadFolder = "rich-content") {
    await this.loadQuill();
    const container = document.getElementById(containerId);
    if (!container) return;

    // Zone d'édition + toolbar Quill dans un wrapper pour un style cohérent avec le reste du site.
    container.innerHTML = `<div class="rich-editor-wrap"><div id="${containerId}-quill"></div></div>`;

    const toolbarOptions = [
      [{ header: [false, 2, 3] }],
      ["bold", "italic", "underline", "strike"],
      ["blockquote"],
      [{ color: [] }, { background: [] }],
      [{ list: "ordered" }, { list: "bullet" }],
      [{ align: [] }],
      ["link", "image", "video"],
      ["clean"]
    ];

    const quill = new Quill(`#${containerId}-quill`, {
      theme: "snow",
      modules: { toolbar: toolbarOptions },
      placeholder: "Écris ici..."
    });

    if (initialHTML) quill.root.innerHTML = initialHTML;

    // Remplace le handler d'image par défaut de Quill (base64 inline, très lourd en base)
    // par un vrai upload vers Supabase Storage via le widget déjà existant.
    const toolbar = quill.getModule("toolbar");
    toolbar.addHandler("image", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = async () => {
        const file = input.files[0];
        if (!file) return;
        try {
          const url = await window.GriotUpload.uploadFile({ file, bucket: "resources", folder: uploadFolder });
          const range = quill.getSelection(true);
          quill.insertEmbed(range.index, "image", url);
          quill.setSelection(range.index + 1);
        } catch (err) {
          window.GriotUtils?.showToast?.(err.message || "Erreur d'upload de l'image.", "error");
        }
      };
      input.click();
    });

    if (onReady) onReady({ getHTML: () => quill.root.innerHTML, quill });
  }
};

window.GriotRichEditor = GriotRichEditor;
