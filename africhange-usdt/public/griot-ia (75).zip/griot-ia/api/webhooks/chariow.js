/* ============================================================
   GRIOT IA — Netlify Function : webhook Chariow (Pulses)
   Route : /api/chariow-webhook → /.netlify/functions/chariow
   Reçoit les notifications de vente Chariow, retrouve le membre
   par email dans Supabase, met à jour son plan automatiquement.
   Si aucun compte ne correspond : stocke la vente "en attente"
   pour traitement manuel dans l'admin.

   Nom d'événement CONFIRMÉ en conditions réelles (onglet "Livraisons"
   du Pulse dans le dashboard Chariow) : "successful.sale" — et non
   "sale.completed" comme le laissait penser la doc publique
   chariow.dev/guides/use-cases. Format du payload :
   { "event": "successful.sale", "data": { "id", "customer": { "email", ... },
     "product": { "id", "name", ... }, "amount": {...}, "status" } }

   ⚠️ Le nom exact du header de signature n'est pas confirmé
   publiquement par la doc Chariow au moment de l'écriture de ce
   code. Cette fonction vérifie plusieurs noms de header courants
   si un secret est configuré (CHARIOW_WEBHOOK_SECRET) ; vérifie
   le nom exact affiché dans ton dashboard Chariow au moment de la
   création du Pulse et ajuste WEBHOOK_SIGNATURE_HEADERS ci-dessous
   si besoin.
   ============================================================ */

const crypto = require("crypto");

const WEBHOOK_SIGNATURE_HEADERS = [
  "x-chariow-signature",
  "x-webhook-signature",
  "x-signature"
];

function supabaseHeaders() {
  return {
    apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
    Prefer: "return=representation"
  };
}

/** Vérifie la signature si un secret est configuré ET qu'un header connu est présent.
 *  Si aucun secret n'est configuré, ou qu'aucun header de signature n'est trouvé,
 *  la vérification est ignorée (log d'avertissement) plutôt que de bloquer toutes
 *  les ventes — à activer strictement dès que le nom exact du header est confirmé. */
function verifySignatureIfPresent(rawBody, headers, secret) {
  if (!secret) return { checked: false, valid: true };
  const headerName = WEBHOOK_SIGNATURE_HEADERS.find((h) => headers[h]);
  if (!headerName) return { checked: false, valid: true };
  const received = headers[headerName];
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  let valid = false;
  try {
    valid = crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(received.replace(/^sha256=/, "")));
  } catch (e) {
    valid = false;
  }
  return { checked: true, valid };
}

/**
 * Vérification "Svix-style" (format standard associé aux secrets préfixés whsec_,
 * utilisé par de nombreux fournisseurs). NON BLOQUANTE pour l'instant : elle logue
 * seulement si la signature correspond ou non, sans jamais rejeter la requête —
 * le temps de confirmer via les logs Netlify que le calcul correspond bien à ce que
 * Chariow envoie réellement, avant de la rendre stricte.
 */
function checkSvixStyleSignature(rawBody, headers, secret) {
  if (!secret || !secret.startsWith("whsec_")) return;
  const svixId = headers["svix-id"];
  const svixTimestamp = headers["svix-timestamp"];
  const svixSignature = headers["svix-signature"];
  if (!svixId || !svixTimestamp || !svixSignature) return;

  try {
    const key = Buffer.from(secret.replace(/^whsec_/, ""), "base64");
    const signedContent = `${svixId}.${svixTimestamp}.${rawBody}`;
    const expected = crypto.createHmac("sha256", key).update(signedContent).digest("base64");
    const candidates = svixSignature.split(" ").map((s) => s.split(",")[1]).filter(Boolean);
    const match = candidates.includes(expected);
    console.log(match ? "✅ Signature Svix-style valide (vérification informative, non bloquante)." : "⚠️ Signature Svix-style NE correspond PAS (vérification informative, non bloquante) — payload potentiellement modifié ou schéma différent.");
  } catch (e) {
    console.warn("Impossible de calculer la signature Svix-style :", e.message);
  }
}

/** Détermine si un produit Chariow correspond à Formation ou Accompagnement,
 *  en cherchant le nom/slug du produit (insensible à la casse). */
function identifyProduct(productData) {
  const label = `${productData?.name || ""} ${productData?.slug || ""} ${productData?.id || ""}`.toLowerCase();
  if (label.includes("accompagn")) return "accompagnement";
  if (label.includes("formation")) return "formation";
  return null;
}

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Méthode non autorisée" };
  }

  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    console.error("Variables Supabase manquantes sur le serveur.");
    return { statusCode: 500, body: "Configuration serveur incomplète" };
  }

  const sigResult = verifySignatureIfPresent(event.body, event.headers, process.env.CHARIOW_WEBHOOK_SECRET);
  if (sigResult.checked && !sigResult.valid) {
    console.error("Signature Chariow invalide.");
    return { statusCode: 401, body: "Signature invalide" };
  }
  if (!sigResult.checked) {
    console.warn("Signature Chariow non vérifiée par le schéma générique (header inconnu) — vente traitée quand même.");
  }
  checkSvixStyleSignature(event.body, event.headers, process.env.CHARIOW_WEBHOOK_SECRET);


  try {
    const payload = JSON.parse(event.body);
    const eventType = payload.event || payload.type;
    const data = payload.data || payload;

    console.log("Webhook Chariow reçu — event:", eventType);

    // On ne traite que les ventes complétées. Adapte ce nom d'événement si Chariow
    // Confirmé en conditions réelles (capture d'écran "Livraisons" du Pulse) : Chariow envoie
    // "successful.sale". On garde "sale.completed"/"sale.paid" en repli au cas où ce nom
    // varierait selon le type d'événement Chariow sélectionné.
    if (eventType !== "successful.sale" && eventType !== "sale.completed" && eventType !== "sale.paid") {
      return { statusCode: 200, body: JSON.stringify({ received: true, ignored: eventType }) };
    }

    const customerEmail = (data.customer?.email || data.email || "").trim().toLowerCase();
    const amount = data.amount?.value || data.amount || null;
    const chariowSaleId = data.id || data.sale_id || null;
    const product = identifyProduct(data.product || {});

    if (!customerEmail || !product) {
      console.error("Email ou produit non identifiable dans le payload Chariow:", { customerEmail, product });
      return { statusCode: 400, body: "Email ou produit non identifiable" };
    }

    // Cherche un compte existant avec cet email
    const profileRes = await fetch(
      `${process.env.SUPABASE_URL}/rest/v1/profiles?email=eq.${encodeURIComponent(customerEmail)}&select=id,plan,plan_expires_at`,
      { headers: supabaseHeaders() }
    );
    const profiles = await profileRes.json();
    const matchedProfile = Array.isArray(profiles) && profiles.length ? profiles[0] : null;

    if (!matchedProfile) {
      // Aucun compte trouvé : on stocke la vente en attente pour traitement manuel/email d'invitation
      await fetch(`${process.env.SUPABASE_URL}/rest/v1/pending_sales`, {
        method: "POST",
        headers: supabaseHeaders(),
        body: JSON.stringify({
          email: customerEmail,
          product,
          amount,
          chariow_sale_id: chariowSaleId,
          raw_payload: payload,
          status: "pending"
        })
      });
      console.log(`Vente Chariow enregistrée en attente pour ${customerEmail} (aucun compte Griot IA trouvé).`);
      return { statusCode: 200, body: JSON.stringify({ received: true, matched: false }) };
    }

    // Calcule le nouveau plan + date d'expiration
    let newPlan = product;
    let expiresAt = null;
    if (product === "accompagnement") {
      // Renouvellement : si un abonnement Accompagnement est encore actif, on prolonge
      // à partir de la date d'expiration actuelle plutôt que depuis aujourd'hui, pour ne
      // jamais faire perdre de jours déjà payés en cas de renouvellement en avance.
      const currentExpiry = matchedProfile.plan === "accompagnement" && matchedProfile.plan_expires_at
        ? new Date(matchedProfile.plan_expires_at)
        : null;
      const base = currentExpiry && currentExpiry > new Date() ? currentExpiry : new Date();
      base.setDate(base.getDate() + 30);
      expiresAt = base.toISOString();
    }
    // La Formation reste un accès à vie (comme avec GeniusPay) : pas d'expiration.

    await fetch(`${process.env.SUPABASE_URL}/rest/v1/profiles?id=eq.${matchedProfile.id}`, {
      method: "PATCH",
      headers: supabaseHeaders(),
      body: JSON.stringify({ plan: newPlan, plan_expires_at: expiresAt })
    });

    await fetch(`${process.env.SUPABASE_URL}/rest/v1/subscriptions`, {
      method: "POST",
      headers: supabaseHeaders(),
      body: JSON.stringify({
        user_id: matchedProfile.id,
        plan: newPlan,
        billing: product === "accompagnement" ? "monthly" : "unique",
        amount,
        status: "active",
        expires_at: expiresAt,
        geniuspay_payment_id: chariowSaleId // colonne réutilisée pour stocker l'identifiant Chariow
      })
    });

    console.log(`Plan mis à jour via Chariow pour ${customerEmail} → ${newPlan}${expiresAt ? " (expire " + expiresAt + ")" : ""}`);
    return { statusCode: 200, body: JSON.stringify({ received: true, matched: true, plan: newPlan }) };
  } catch (err) {
    console.error("Erreur webhook Chariow:", err);
    return { statusCode: 500, body: "Erreur serveur" };
  }
};
