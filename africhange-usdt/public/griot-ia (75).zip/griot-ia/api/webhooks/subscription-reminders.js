/* ============================================================
   GRIOT IA — Netlify Scheduled Function : rappels d'abonnement
   S'exécute chaque jour à 8h (heure UTC — voir config dans
   netlify.toml) pour repérer les membres Accompagnement dont
   l'abonnement expire bientôt ou vient d'expirer, et leur
   envoyer un email de rappel via Resend.

   Chaque rappel n'est envoyé qu'une seule fois par échéance
   (table subscription_reminders_sent), donc un renouvellement
   qui change plan_expires_at permet naturellement de recevoir
   à nouveau les rappels au prochain cycle.
   ============================================================ */

function supabaseHeaders() {
  return {
    apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
    Prefer: "return=representation"
  };
}

const REMINDERS = [
  { type: "j-3", daysOffset: 3, subject: "Ton abonnement Griot IA expire dans 3 jours", body: (name) => `Salut ${name},\n\nTon abonnement Accompagnement Griot IA expire dans 3 jours. Renouvelle dès maintenant pour ne perdre aucun accès.` },
  { type: "j-1", daysOffset: 1, subject: "Dernier jour pour renouveler ton abonnement Griot IA", body: (name) => `Salut ${name},\n\nC'est ton dernier jour avant l'expiration de ton abonnement Accompagnement. Renouvelle maintenant pour garder tous tes accès.` },
  { type: "j0", daysOffset: 0, subject: "Ton abonnement Griot IA a expiré", body: (name) => `Salut ${name},\n\nTon abonnement Accompagnement vient d'expirer. Renouvelle pour retrouver l'accès à la communauté, aux lives et à tout le contenu Accompagnement.` },
  { type: "j+3", daysOffset: -3, subject: "Tu nous manques sur Griot IA 👋", body: (name) => `Salut ${name},\n\nÇa fait 3 jours que ton abonnement Accompagnement a expiré. Reviens quand tu veux — ta place t'attend.` }
];

async function sendReminderEmail(to, name, reminder) {
  if (!process.env.RESEND_API_KEY) {
    console.warn("RESEND_API_KEY absente — email de rappel non envoyé (log uniquement) pour", to);
    return false;
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: "Griot IA <contact@griotia.online>",
        to: [to],
        subject: reminder.subject,
        text: reminder.body(name)
      })
    });
    return res.ok;
  } catch (e) {
    console.error("Erreur envoi email Resend:", e.message);
    return false;
  }
}

exports.handler = async function () {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    console.error("Variables Supabase manquantes.");
    return { statusCode: 500, body: "Configuration incomplète" };
  }

  // Récupère tous les membres actuellement en plan Accompagnement avec une date d'expiration
  const res = await fetch(
    `${process.env.SUPABASE_URL}/rest/v1/profiles?plan=eq.accompagnement&plan_expires_at=not.is.null&select=id,email,full_name,plan_expires_at`,
    { headers: supabaseHeaders() }
  );
  const members = await res.json();
  if (!Array.isArray(members)) {
    console.error("Réponse inattendue lors de la récupération des membres:", members);
    return { statusCode: 500, body: "Erreur lecture membres" };
  }

  const now = new Date();
  let sentCount = 0;

  for (const member of members) {
    const expiresAt = new Date(member.plan_expires_at);
    const daysUntilExpiry = Math.round((expiresAt - now) / (1000 * 60 * 60 * 24));

    const matchingReminder = REMINDERS.find((r) => r.daysOffset === daysUntilExpiry);
    if (!matchingReminder) continue;

    // Vérifie si ce rappel a déjà été envoyé pour CETTE échéance précise
    const checkRes = await fetch(
      `${process.env.SUPABASE_URL}/rest/v1/subscription_reminders_sent?user_id=eq.${member.id}&reminder_type=eq.${matchingReminder.type}&expires_at_snapshot=eq.${encodeURIComponent(member.plan_expires_at)}`,
      { headers: supabaseHeaders() }
    );
    const existing = await checkRes.json();
    if (Array.isArray(existing) && existing.length > 0) continue; // déjà envoyé pour cette échéance

    const sent = await sendReminderEmail(member.email, member.full_name || "membre Griot IA", matchingReminder);

    await fetch(`${process.env.SUPABASE_URL}/rest/v1/subscription_reminders_sent`, {
      method: "POST",
      headers: supabaseHeaders(),
      body: JSON.stringify({
        user_id: member.id,
        reminder_type: matchingReminder.type,
        expires_at_snapshot: member.plan_expires_at
      })
    });

    if (sent) sentCount++;
  }

  console.log(`Rappels d'abonnement traités : ${sentCount} email(s) envoyé(s) sur ${members.length} membre(s) Accompagnement.`);
  return { statusCode: 200, body: JSON.stringify({ processed: members.length, sent: sentCount }) };
};
