/* ============================================================
   GRIOT IA — Netlify Function : création d'un paiement GeniusPay
   Route : /api/webhooks/geniuspay-create → /.netlify/functions/geniuspay-create
   Garde les clés secrètes côté serveur (jamais exposées au client).
   N'utilise AUCUNE dépendance npm externe (appels fetch natifs vers
   l'API REST de Supabase) — fonctionne même avec un déploiement
   par glisser-déposer (sans étape "npm install").
   ============================================================ */

function supabaseHeaders() {
  return {
    apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
    Prefer: "return=representation"
  };
}

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ message: "Méthode non autorisée" }) };
  }

  try {
    const body = JSON.parse(event.body);
    const { amount, description, customer, metadata, success_url, error_url } = body;

    if (!amount || !description || !customer?.email || !metadata?.user_id || !metadata?.plan) {
      return { statusCode: 400, body: JSON.stringify({ message: "Paramètres de paiement invalides." }) };
    }

    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      console.error("Variables Supabase manquantes sur le serveur.");
      return { statusCode: 500, body: JSON.stringify({ message: "Configuration serveur incomplète (Supabase)." }) };
    }
    if (!process.env.GENIUSPAY_API_KEY || !process.env.GENIUSPAY_API_SECRET) {
      console.error("Variables GeniusPay manquantes sur le serveur.");
      return { statusCode: 500, body: JSON.stringify({ message: "Configuration serveur incomplète (GeniusPay)." }) };
    }

    // 1. Crée un enregistrement "pending" en base pour traçabilité
    let paymentRow = null;
    try {
      const insertRes = await fetch(`${process.env.SUPABASE_URL}/rest/v1/payments`, {
        method: "POST",
        headers: supabaseHeaders(),
        body: JSON.stringify({
          user_id: metadata.user_id,
          amount,
          plan: metadata.plan,
          billing: metadata.billing,
          status: "pending"
        })
      });
      if (insertRes.ok) {
        const rows = await insertRes.json();
        paymentRow = rows[0];
      } else {
        console.error("Erreur insertion payment row:", await insertRes.text());
      }
    } catch (e) {
      console.error("Exception insertion payment row:", e.message);
    }

    // 2. Appel à l'API GeniusPay pour créer la transaction
    const geniusRes = await fetch("https://pay.genius.ci/api/v1/merchant/payments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-API-Key": process.env.GENIUSPAY_API_KEY,
        "X-API-Secret": process.env.GENIUSPAY_API_SECRET
      },
      body: JSON.stringify({
        amount,
        description,
        customer,
        metadata: { ...metadata, payment_row_id: paymentRow?.id },
        success_url,
        error_url
      })
    });

    const rawGeniusText = await geniusRes.text();
    console.log("Réponse brute GeniusPay (statut " + geniusRes.status + "):", rawGeniusText);

    if (!geniusRes.ok) {
      console.error("Erreur GeniusPay:", geniusRes.status, rawGeniusText);
      return {
        statusCode: 502,
        body: JSON.stringify({
          message: `GeniusPay a refusé la demande (statut ${geniusRes.status}). Vérifie tes clés GENIUSPAY_API_KEY / GENIUSPAY_API_SECRET.`,
          debug: rawGeniusText.slice(0, 500)
        })
      };
    }

    let geniusData;
    try {
      geniusData = JSON.parse(rawGeniusText);
    } catch (e) {
      console.error("Réponse GeniusPay non JSON:", rawGeniusText);
      return {
        statusCode: 502,
        body: JSON.stringify({ message: "GeniusPay a renvoyé une réponse inattendue (pas du JSON).", debug: rawGeniusText.slice(0, 500) })
      };
    }

    // GeniusPay peut nommer le champ différemment selon la version de leur API :
    // on essaie plusieurs noms possibles avant d'abandonner.
    const checkoutUrl =
      geniusData.checkout_url ||
      geniusData.payment_url ||
      geniusData.url ||
      geniusData?.data?.checkout_url ||
      geniusData?.data?.payment_url ||
      geniusData?.data?.url ||
      geniusData?.payment?.checkout_url;

    const paymentId =
      geniusData.payment_id || geniusData.id || geniusData?.data?.payment_id || geniusData?.data?.id || null;

    if (!checkoutUrl) {
      console.error("Pas de checkout_url trouvé dans la réponse GeniusPay:", JSON.stringify(geniusData));
      return {
        statusCode: 502,
        body: JSON.stringify({
          message: "GeniusPay a répondu avec succès mais sans lien de paiement exploitable.",
          debug: JSON.stringify(geniusData).slice(0, 500)
        })
      };
    }

    // 3. Met à jour l'enregistrement avec l'URL de paiement
    if (paymentRow) {
      try {
        await fetch(`${process.env.SUPABASE_URL}/rest/v1/payments?id=eq.${paymentRow.id}`, {
          method: "PATCH",
          headers: supabaseHeaders(),
          body: JSON.stringify({
            geniuspay_checkout_url: checkoutUrl,
            geniuspay_payment_id: paymentId
          })
        });
      } catch (e) {
        console.error("Exception mise à jour payment row:", e.message);
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ checkout_url: checkoutUrl })
    };
  } catch (err) {
    console.error("Erreur geniuspay-create:", err);
    return { statusCode: 500, body: JSON.stringify({ message: "Erreur serveur lors de la création du paiement." }) };
  }
};
