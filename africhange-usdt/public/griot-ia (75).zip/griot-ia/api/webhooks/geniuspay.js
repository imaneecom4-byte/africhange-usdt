/* ============================================================
   GRIOT IA — Netlify Function : webhook GeniusPay
   Route : /api/webhooks/geniuspay → /.netlify/functions/geniuspay
   Vérifie la signature HMAC-SHA256, met à jour le paiement,
   crée la subscription et met à jour le plan de l'utilisateur.
   N'utilise AUCUNE dépendance npm externe (appels fetch natifs vers
   l'API REST de Supabase + module natif "crypto") — fonctionne même
   avec un déploiement par glisser-déposer.
   URL à configurer dans le dashboard GeniusPay :
   https://griotia.online/.netlify/functions/geniuspay
   ============================================================ */

const crypto = require("crypto");

function supabaseHeaders() {
  return {
    apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
    Prefer: "return=representation"
  };
}

function verifySignature(rawBody, timestamp, signatureHeader, secret) {
  if (!signatureHeader || !timestamp) return false;
  const expected = crypto.createHmac("sha256", secret).update(`${timestamp}.${rawBody}`).digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
  } catch (e) {
    return false;
  }
}

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Méthode non autorisée" };
  }

  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    console.error("Variables Supabase manquantes sur le serveur.");
    return { statusCode: 500, body: "Configuration serveur incomplète" };
  }

  // GeniusPay envoie 3 headers : X-Webhook-Signature, X-Webhook-Timestamp, X-Webhook-Event
  // Netlify met les noms de headers en minuscules dans event.headers.
  const signature = event.headers["x-webhook-signature"];
  const timestamp = event.headers["x-webhook-timestamp"];
  const webhookEventType = event.headers["x-webhook-event"];

  const isValid = verifySignature(event.body, timestamp, signature, process.env.GENIUSPAY_WEBHOOK_SECRET);
  if (!isValid) {
    console.error("Signature webhook GeniusPay invalide.");
    return { statusCode: 401, body: "Signature invalide" };
  }

  try {
    const payload = JSON.parse(event.body);
    // Priorité au header X-Webhook-Event (documenté par GeniusPay), avec repli sur le payload au cas où.
    const eventType = webhookEventType || payload.event || payload.type;
    console.log("Webhook GeniusPay reçu — event:", eventType, "payload:", event.body.slice(0, 500));
    const data = payload.data || payload;
    const metadata = data.metadata || {};
    const geniuspayPaymentId = data.payment_id || data.id;

    // Sauvegarde brute du webhook pour audit
    if (geniuspayPaymentId) {
      await fetch(`${process.env.SUPABASE_URL}/rest/v1/payments?geniuspay_payment_id=eq.${geniuspayPaymentId}`, {
        method: "PATCH",
        headers: supabaseHeaders(),
        body: JSON.stringify({ raw_webhook: payload })
      }).catch((e) => console.error("Erreur sauvegarde raw_webhook:", e.message));
    }

    if (eventType !== "payment.success") {
      if (eventType === "payment.failed" && geniuspayPaymentId) {
        await fetch(`${process.env.SUPABASE_URL}/rest/v1/payments?geniuspay_payment_id=eq.${geniuspayPaymentId}`, {
          method: "PATCH",
          headers: supabaseHeaders(),
          body: JSON.stringify({ status: "failed" })
        }).catch((e) => console.error("Erreur update payment failed:", e.message));
      }
      return { statusCode: 200, body: JSON.stringify({ received: true }) };
    }

    const userId = metadata.user_id;
    const plan = metadata.plan; // "formation" | "accompagnement"
    const billing = metadata.billing; // "unique" | "monthly" | "annual"
    const amount = data.amount;

    if (!userId || !plan) {
      console.error("Métadonnées manquantes dans le webhook GeniusPay:", metadata);
      return { statusCode: 400, body: "Métadonnées manquantes" };
    }

    // Met à jour le paiement en succès
    if (geniuspayPaymentId) {
      await fetch(`${process.env.SUPABASE_URL}/rest/v1/payments?geniuspay_payment_id=eq.${geniuspayPaymentId}`, {
        method: "PATCH",
        headers: supabaseHeaders(),
        body: JSON.stringify({ status: "success" })
      }).catch((e) => console.error("Erreur update payment success:", e.message));
    }

    // Calcule l'expiration selon le type de facturation
    let expiresAt = null;
    if (billing === "monthly") {
      const d = new Date();
      d.setMonth(d.getMonth() + 1);
      expiresAt = d.toISOString();
    } else if (billing === "annual") {
      const d = new Date();
      d.setFullYear(d.getFullYear() + 1);
      expiresAt = d.toISOString();
    } else if (billing === "unique") {
      expiresAt = null; // Formation = accès à vie
    }

    // Crée la subscription
    await fetch(`${process.env.SUPABASE_URL}/rest/v1/subscriptions`, {
      method: "POST",
      headers: supabaseHeaders(),
      body: JSON.stringify({
        user_id: userId,
        plan,
        billing,
        amount,
        status: "active",
        expires_at: expiresAt,
        geniuspay_payment_id: geniuspayPaymentId
      })
    }).catch((e) => console.error("Erreur création subscription:", e.message));

    // Met à jour le profil de l'utilisateur
    await fetch(`${process.env.SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
      method: "PATCH",
      headers: supabaseHeaders(),
      body: JSON.stringify({ plan, plan_expires_at: expiresAt })
    }).catch((e) => console.error("Erreur update profile plan:", e.message));

    return { statusCode: 200, body: JSON.stringify({ received: true }) };
  } catch (err) {
    console.error("Erreur webhook GeniusPay:", err);
    return { statusCode: 500, body: "Erreur serveur" };
  }
};
