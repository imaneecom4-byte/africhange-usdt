/* ============================================================
   GRIOT IA — Netlify Function : envoi manuel d'un rappel d'abonnement
   Appelée depuis admin/subscriptions.html (bouton "Envoyer un rappel").
   Envoie immédiatement un email via Resend, sans attendre le cron
   quotidien. Ne modifie pas subscription_reminders_sent (un envoi
   manuel n'empêche pas les rappels automatiques prévus).
   ============================================================ */

function supabaseHeaders() {
  return {
    apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json"
  };
}

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ message: "Méthode non autorisée" }) };
  }
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return { statusCode: 500, body: JSON.stringify({ message: "Configuration serveur incomplète" }) };
  }
  if (!process.env.RESEND_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ message: "RESEND_API_KEY absente — impossible d'envoyer l'email." }) };
  }

  try {
    const { user_id } = JSON.parse(event.body || "{}");
    if (!user_id) {
      return { statusCode: 400, body: JSON.stringify({ message: "user_id manquant" }) };
    }

    const profileRes = await fetch(`${process.env.SUPABASE_URL}/rest/v1/profiles?id=eq.${user_id}&select=email,full_name,plan_expires_at`, {
      headers: supabaseHeaders()
    });
    const profiles = await profileRes.json();
    const member = Array.isArray(profiles) && profiles.length ? profiles[0] : null;
    if (!member) {
      return { statusCode: 404, body: JSON.stringify({ message: "Membre introuvable" }) };
    }

    const formattedDate = member.plan_expires_at
      ? new Date(member.plan_expires_at).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })
      : "bientôt";

    const emailRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: "Griot IA <contact@griotia.online>",
        to: [member.email],
        subject: "Rappel — ton abonnement Griot IA",
        text: `Salut ${member.full_name || "membre Griot IA"},\n\nPetit rappel : ton abonnement Accompagnement expire le ${formattedDate}. Renouvelle dès que possible pour garder tous tes accès.\n\nL'équipe Griot IA`
      })
    });

    if (!emailRes.ok) {
      const errText = await emailRes.text();
      console.error("Erreur Resend:", errText);
      return { statusCode: 502, body: JSON.stringify({ message: "Échec de l'envoi de l'email." }) };
    }

    return { statusCode: 200, body: JSON.stringify({ sent: true }) };
  } catch (err) {
    console.error("Erreur send-manual-reminder:", err);
    return { statusCode: 500, body: JSON.stringify({ message: "Erreur serveur" }) };
  }
};
